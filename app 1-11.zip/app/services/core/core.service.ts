import { Injectable } from '@angular/core';
import { UtilsService } from '../utils/utils.service'
import { SkinsService } from '../css/skins/skins.service';
import { CommonService } from './common/common.service';
import { UiService } from './ui/ui.service';
import { FacadesService } from './facades/facades.service';
import { DatastoreService } from './datastore/datastore.service';
import { DataprocessorService } from './dataprocessor/dataprocessor.service';
import { TimelineService } from './ui/timeline/timeline.service';
import { ConstantService } from '../constants/constant.service';
import { PluginsService } from './plugins/plugins.service';
import { LocaleService } from '../locale/locale.service';
import { PublishHelpersService } from '../publish-helpers/publish-helpers.service';
import { WorktimeService } from './worktime/worktime.service';
import { LightboxService } from './lightbox/lightbox.service';
import { GanttService } from '../gantt/gantt.service';

@Injectable({
  providedIn: 'root'
})
export class CoreService {
  constants;
  config: any;
  env: any;
  min_date;
  max_date;
  boxAttribute = "data-dhxbox";
  _dhx_msg_cfg = null;
  constructor(private utilsService: UtilsService, private skinService: SkinsService, private commonService: CommonService,
    private uiService: UiService, private facadeService: FacadesService, private dataStoreService: DatastoreService,
    private dataProcessorService: DataprocessorService, private timelineService: TimelineService, private constantService: ConstantService,
    private pluginService: PluginsService, private localeService: LocaleService, private publishHelper: PublishHelpersService,
    private worktimeService: WorktimeService, private lightboxService: LightboxService, private ganttService: GanttService) {
    this.config = this.ganttService.config;
    this.env = this.utilsService.env;
    console.log(this.config);
  }

  messagebox: any = {
    seed: (new Date()).valueOf(),
    uid: this.utilsService.uid,
    expire: 4000,
    keyboard: true,
    position: "top",
    pull: {},
    timers: {}
  }

  modalityObj: any = {
    
  }

  cachedFunctions(gantt) {

    gantt._cached_functions = {
      cache: {},
      mode: false,
      critical_path_mode: false,
      wrap_methods: function (methods, object) {
        if (object._prefetch_originals) {
          for (var i in object._prefetch_originals) {
            object[i] = object._prefetch_originals[i];
          }
        }
        object._prefetch_originals = {};
        for (let i = 0; i < methods.length; i++)
          this.prefetch(methods[i], object);

      },
      prefetch: function (methodname, host) {
        var original = host[methodname];
        if (original) {
          var optimizer = this;

          host._prefetch_originals[methodname] = original;
          host[methodname] = function get_prefetched_value() {

            var argumentsArray = new Array(arguments.length);
            for (var i = 0, l = arguments.length; i < l; i++) {
              argumentsArray[i] = arguments[i];
            }

            if (optimizer.active) {
              var args = optimizer.get_arguments_hash(Array.prototype.slice.call(argumentsArray));
              if (!optimizer.cache[methodname]) {
                optimizer.cache[methodname] = {};
              }

              var cached_values = optimizer.cache[methodname];

              if (optimizer.has_cached_value(cached_values, args)) {
                return optimizer.get_cached_value(cached_values, args);
              } else {
                var value = original.apply(this, argumentsArray);
                optimizer.cache_value(cached_values, args, value);
                return value;
              }
            }

            return original.apply(this, argumentsArray);
          };
        }
        return original;
      },
      cache_value: function (cache, arguments_hash, value) {
        if (this.is_date(value))
          value = new Date(value);
        cache[arguments_hash] = value;
      },
      has_cached_value: function (cache, arguments_hash) {
        return cache.hasOwnProperty(arguments_hash);
      },
      get_cached_value: function (cache, arguments_hash) {
        var data = cache[arguments_hash];

        //for cached dates - return copy
        if (this.is_date(data)) {
          data = new Date(data);
        }
        return data;
      },
      is_date: function (value) {
        return (value && value.getUTCDate);
      },
      get_arguments_hash: function (args) {
        var values = [];
        for (var i = 0; i < args.length; i++) {
          values.push(this.stringify_argument(args[i]));
        }
        return "(" + values.join(";") + ")";
      },
      stringify_argument: function (value) {
        //expecting task or link, or any other data entries, dates and primitive values
        var ret = "";
        if (value.id) {
          ret = value.id;
        } else if (this.is_date(value)) {
          ret = value.valueOf();
        } else {
          ret = value;
        }
        return ret + "";
      },
      activate: function () {
        this.clear();
        this.active = true;
      },
      deactivate: function () {
        this.clear();
        this.active = false;
      },
      clear: function () {
        this.cache = {};
      },

      setup: function (gantt) {
        var override_gantt = [];

        var gantt_methods = [
          '_isProjectEnd',
          '_getProjectEnd',
          '_getSlack'
        ];



        if (this.mode == 'auto') {
          if (this.config.highlight_critical_path) {
            override_gantt = gantt_methods;
          }
        } else if (this.mode === true) {
          override_gantt = gantt_methods;
        }

        this.wrap_methods(override_gantt, gantt);

      },
      update_if_changed: function (gantt) {
        var changed = (this.critical_path_mode != this.config.highlight_critical_path ||
          this.mode !== this.config.optimize_render);
        if (changed) {
          this.critical_path_mode = this.config.highlight_critical_path;
          this.mode = this.config.optimize_render;
          this.setup(gantt);
        }
      }
    };

    function activate() {
      gantt._cached_functions.update_if_changed(gantt);
      if (!gantt._cached_functions.active) {
        gantt._cached_functions.activate();
      }
      return true;
    }
    gantt.attachEvent("onBeforeGanttRender", activate);
    gantt.attachEvent("onBeforeDataRender", activate);
    gantt.attachEvent("onBeforeSmartRender", function () {
      activate();
    });
    gantt.attachEvent("onBeforeParse", activate);
    gantt.attachEvent("onDataRender", function () {
      gantt._cached_functions.deactivate();
    });
    var deactivTimeout = null;
    gantt.attachEvent("onSmartRender", function () {
      if (deactivTimeout)
        clearTimeout(deactivTimeout);
      deactivTimeout = setTimeout(function () {
        gantt._cached_functions.deactivate();
      }, 1000);
    });

    gantt.attachEvent("onBeforeGanttReady", function () {
      gantt._cached_functions.update_if_changed(gantt);
      return true;
    });

  }


  data(gantt) {

    var helpers = this.utilsService;

    gantt.attachEvent("onBeforeTaskUpdate", function (id, task) {
      gantt._init_task_timing(task);
      return true;
    });
    gantt.attachEvent("onBeforeTaskAdd", function (id, task) {
      gantt._init_task_timing(task);
      return true;
    });

  };

  // isUnscheduledTask(task) {
  //   this.commonService.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isUnscheduledTask. Task object was expected");
  //   return (!!task.unscheduled || !task.start_date);
  // };

  // _isAllowedUnscheduledTask(task) {
  //   return !!(task.unscheduled && this.config.show_unscheduled);
  // };

  // isTaskVisible = function (id) {
  //   if (!this.isTaskExists(id))
  //     return false;

  //   var task = this.getTask(id);

  //   var taskStart = task.start_date ? task.start_date.valueOf() : null;
  //   var taskEnd = task.end_date ? task.end_date.valueOf() : null;

  //   if (!(this._isAllowedUnscheduledTask(task) || (taskStart && taskEnd && taskStart <= this._max_date.valueOf() && taskEnd >= this._min_date.valueOf()))) {
  //     return false;
  //   }

  //   return !!(this.getGlobalTaskIndex(id) >= 0);
  // };

  // _getProjectEnd() {
  //   if (this.config.project_end) {
  //     return this.config.project_end;
  //   } else {
  //     var tasks = this.getTaskByTime();
  //     tasks = tasks.sort(function (a, b) {
  //       return +a.end_date > +b.end_date ? 1 : -1;
  //     });
  //     return tasks.length ? tasks[tasks.length - 1].end_date : null;
  //   }
  // };
  // _getProjectStart() {
  //   if (this.config.project_start) {
  //     return this.config.project_start;
  //   }

  //   // use timeline start if project start is not specified
  //   if (this.config.start_date) {
  //     return this.config.start_date;
  //   }
  //   if (this.getState().min_date) {
  //     return this.getState().min_date;
  //   }

  //   // earliest task start if neither project start nor timeline are specified
  //   var tasks = this.getTaskByTime();
  //   tasks = tasks.sort(function (a, b) {
  //     return +a.start_date > +b.start_date ? 1 : -1;
  //   });
  //   return tasks.length ? tasks[0].start_date : null;
  // };

  // _defaultTaskDate(item, parent_id) {
  //   var parent = (parent_id && parent_id != this.config.root_id) ? this.getTask(parent_id) : false,
  //     startDate = null;
  //   if (parent) {
  //     if (this.config.schedule_from_end) {
  //       startDate = this.calculateEndDate({
  //         start_date: parent.end_date,
  //         duration: - this.config.duration_step,
  //         task: item
  //       });
  //     } else {
  //       startDate = parent.start_date;
  //     }

  //   } else if (this.config.schedule_from_end) {
  //     startDate = gantt.calculateEndDate({
  //       start_date: gantt._getProjectEnd(),
  //       duration: - this.config.duration_step,
  //       task: item
  //     });
  //   } else {
  //     var first = gantt.getTaskByIndex(0);
  //     startDate = first ? (first.start_date ? first.start_date : (first.end_date ? gantt.calculateEndDate({
  //       start_date: first.end_date,
  //       duration: -this.config.duration_step,
  //       task: item
  //     }) : null)) : this.config.start_date || gantt.getState().min_date;
  //   }
  //   gantt.assert(startDate, "Invalid dates");
  //   return new Date(startDate);
  // };

  // _set_default_task_timing(task) {
  //   task.start_date = task.start_date || this._defaultTaskDate(task, this.getParent(task));
  //   task.duration = task.duration || this.config.duration_step;
  //   task.end_date = task.end_date || this.calculateEndDate(task);
  // };

  // createTask(item, parent, index) {
  //   item = item || {};
  //   if (!this.utilsService.defined(item.id))
  //     item.id = this.utilsService.uid();

  //   if (!item.start_date) {
  //     item.start_date = this._defaultTaskDate(item, parent);
  //   }
  //   if (item.text === undefined) {
  //     item.text = gantt.locale.labels.new_task;
  //   }
  //   if (item.duration === undefined) {
  //     item.duration = 1;
  //   }

  //   if (this.isTaskExists(parent)) {
  //     this.setParent(item, parent, true);
  //     var parentObj = this.getTask(parent);
  //     parentObj.$open = true;
  //   }

  //   if (!this.utilsService.callEvent("onTaskCreated", [item], undefined)) {
  //     return null;
  //   }
  //   if (this.config.details_on_create) {
  //     item.$new = true;
  //     this.silent(function () {
  //       gantt.$data.tasksStore.addItem(item, index);
  //     });
  //     this.selectTask(item.id);
  //     this.refreshData();
  //     this.showLightbox(item.id);
  //   } else {
  //     if (this.addTask(item, parent, index)) {
  //       this.showTask(item.id);
  //       this.selectTask(item.id);
  //     }
  //   }
  //   return item.id;
  // };

  // _update_flags(oldid, newid) {
  //   //  TODO: need a proper way to update all possible flags
  //   var store = gantt.$data.tasksStore;
  //   if (oldid === undefined) {
  //     this._lightbox_id = null;

  //     store.silent(function () {
  //       store.unselect();
  //     });

  //     if (this._tasks_dnd && this._tasks_dnd.drag) {
  //       this._tasks_dnd.drag.id = null;
  //     }
  //   } else {
  //     if (this._lightbox_id == oldid)
  //       this._lightbox_id = newid;

  //     // TODO: probably can be removed
  //     if (store.getSelectedId() == oldid) {
  //       store.silent(function () {
  //         store.unselect(oldid);
  //         store.select(newid);
  //       });
  //     }
  //     if (this._tasks_dnd && this._tasks_dnd.drag && this._tasks_dnd.drag.id == oldid) {
  //       this._tasks_dnd.drag.id = newid;
  //     }
  //   }
  // };

  // _get_task_timing_mode(task, force) {
  //   var task_type = this.getTaskType(task.type);

  //   var state = {
  //     type: task_type,
  //     $no_start: false,
  //     $no_end: false
  //   };

  //   if (!force && task_type == task.$rendered_type) {
  //     state.$no_start = task.$no_start;
  //     state.$no_end = task.$no_end;
  //     return state;
  //   }

  //   if (task_type == this.config.types.project) {
  //     //project duration is always defined by children duration
  //     state.$no_end = state.$no_start = true;
  //   } else if (task_type != this.config.types.milestone) {
  //     //tasks can have fixed duration, children duration(as projects), or one date fixed, and other defined by nested items
  //     state.$no_end = !(task.end_date || task.duration);
  //     state.$no_start = !task.start_date;

  //     if (this._isAllowedUnscheduledTask(task)) {
  //       state.$no_end = state.$no_start = false;
  //     }
  //   }

  //   return state;
  // };

  // _init_task_timing(task) {
  //   var task_mode = gantt._get_task_timing_mode(task, true);

  //   var dirty = task.$rendered_type != task_mode.type;

  //   var task_type = task_mode.type;

  //   if (dirty) {
  //     task.$no_start = task_mode.$no_start;
  //     task.$no_end = task_mode.$no_end;
  //     task.$rendered_type = task_mode.type;
  //   }

  //   if (dirty && task_type != this.config.types.milestone) {
  //     if (task_type == this.config.types.project) {
  //       //project duration is always defined by children duration
  //       this._set_default_task_timing(task);
  //     }
  //   }

  //   if (task_type == this.config.types.milestone) {
  //     task.end_date = task.start_date;
  //   }
  //   if (task.start_date && task.end_date) {
  //     task.duration = this.calculateDuration(task);
  //   }

  //   if (!task.end_date) {
  //     task.end_date = task.start_date;
  //   }

  //   task.duration = task.duration || 0;
  // };

  // isSummaryTask(task) {
  //   gantt.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isSummaryTask. Task object was expected");

  //   var mode = gantt._get_task_timing_mode(task);

  //   return !!(mode.$no_end || mode.$no_start);
  // };

  // // downward calculation of project duration
  // resetProjectDates(task) {
  //   var taskMode = this._get_task_timing_mode(task);
  //   if (taskMode.$no_end || taskMode.$no_start) {
  //     var dates = this.getSubtaskDates(task.id);
  //     this._assign_project_dates(task, dates.start_date, dates.end_date);
  //   }
  // };

  // getSubtaskDuration(task_id) {
  //   var res = 0,
  //     root = task_id !== undefined ? task_id : this.config.root_id;

  //   this.eachTask(function (child) {
  //     if (this.getTaskType(child.type) == this.config.types.project || this.isUnscheduledTask(child))
  //       return;

  //     res += child.duration;
  //   }, root);

  //   return res;
  // };

  // getSubtaskDates(task_id) {
  //   var min = null,
  //     max = null,
  //     root = task_id !== undefined ? task_id : this.config.root_id;

  //   this.eachTask(function (child) {
  //     if (this.getTaskType(child.type) == this.config.types.project || this.isUnscheduledTask(child))
  //       return;

  //     if ((child.start_date && !child.$no_start) && (!min || min > child.start_date.valueOf()))
  //       min = child.start_date.valueOf();
  //     if ((child.end_date && !child.$no_end) && (!max || max < child.end_date.valueOf()))
  //       max = child.end_date.valueOf();
  //   }, root);

  //   return {
  //     start_date: min ? new Date(min) : null,
  //     end_date: max ? new Date(max) : null
  //   };
  // };

  // _assign_project_dates(task, from, to) {
  //   var taskTiming = this._get_task_timing_mode(task);
  //   if (taskTiming.$no_start) {
  //     if (from && from != Infinity) {
  //       task.start_date = new Date(from);
  //     } else {
  //       task.start_date = this._defaultTaskDate(task, this.getParent(task));
  //     }
  //   }

  //   if (taskTiming.$no_end) {
  //     if (to && to != -Infinity) {
  //       task.end_date = new Date(to);
  //     } else {
  //       task.end_date = this.calculateEndDate({
  //         start_date: task.start_date,
  //         duration: this.config.duration_step,
  //         task: task
  //       });
  //     }
  //   }
  //   if (taskTiming.$no_start || taskTiming.$no_end) {
  //     this._init_task_timing(task);
  //   }
  // };

  // upward calculation of project duration
  // _update_parents(taskId, silent) {
  //   if (!taskId) return;

  //   var task = this.getTask(taskId);
  //   var pid = this.getParent(task);

  //   var taskTiming = this._get_task_timing_mode(task);

  //   var has_changed = true;

  //   if (taskTiming.$no_start || taskTiming.$no_end) {
  //     var oldStart = task.start_date.valueOf(),
  //       oldEnd = task.end_date.valueOf();

  //     gantt.resetProjectDates(task);

  //     // not refresh parent projects if dates hasn't changed
  //     if (oldStart == task.start_date.valueOf() && oldEnd == task.end_date.valueOf()) {
  //       has_changed = false;
  //     }

  //     if (has_changed && !silent) {
  //       this.refreshTask(task.id, true);
  //     }
  //   }


  //   if (has_changed && pid && this.isTaskExists(pid)) {
  //     this._update_parents(pid, silent);
  //   }
  // };

  // roundDate(config) {
  //   var scale = gantt.getScale();

  //   if (helpers.isDate(config)) {
  //     config = {
  //       date: config,
  //       unit: scale ? scale.unit : this.config.duration_unit,
  //       step: scale ? scale.step : this.config.duration_step
  //     };
  //   }
  //   var date = config.date,
  //     steps = config.step,
  //     unit = config.unit;

  //   if (!scale) {
  //     return date;
  //   }

  //   var upper, lower, colIndex;
  //   if (unit == scale.unit && steps == scale.step &&
  //     +date >= +scale.min_date && +date <= +scale.max_date) {
  //     //find date in time scale config
  //     colIndex = Math.floor(gantt.columnIndexByDate(date));

  //     if (!scale.trace_x[colIndex]) {
  //       colIndex -= 1;// end of time scale
  //       if (scale.rtl) {
  //         colIndex = 0;
  //       }
  //     }
  //     lower = new Date(scale.trace_x[colIndex]);
  //     upper = gantt.date.add(lower, steps, unit);
  //   } else {
  //     colIndex = Math.floor(gantt.columnIndexByDate(date));

  //     upper = gantt.date[unit + "_start"](new Date(scale.min_date));
  //     if (scale.trace_x[colIndex]) {
  //       upper = gantt.date[unit + "_start"](scale.trace_x[colIndex]);// end of time scale
  //     }

  //     while (+upper < +date) {
  //       upper = gantt.date[unit + "_start"](gantt.date.add(upper, steps, unit));

  //       var tzOffset = upper.getTimezoneOffset();

  //       upper = gantt._correct_dst_change(upper, tzOffset, upper, unit);
  //       if (gantt.date[unit + '_start'])
  //         upper = gantt.date[unit + '_start'](upper);
  //     }

  //     lower = gantt.date.add(upper, -1 * steps, unit);

  //   }
  //   if (config.dir && config.dir == 'future')
  //     return upper;
  //   if (config.dir && config.dir == 'past')
  //     return lower;

  //   if (Math.abs(date - lower) < Math.abs(upper - date)) {
  //     return lower;
  //   } else {
  //     return upper;
  //   }

  // };

  // correctTaskWorkTime(task) {
  //   if (this.config.work_time && this.config.correct_work_time) {
  //     if (!this.isWorkTime(task.start_date, undefined, task)) {
  //       task.start_date = this.getClosestWorkTime({ date: task.start_date, dir: 'future', task: task });
  //       task.end_date = this.calculateEndDate(task);
  //     } else if (!this.isWorkTime(new Date(+task.end_date - 1), undefined, task)) {
  //       task.end_date = this.calculateEndDate(task);
  //     }
  //   }
  // };


  data_task_layers(gantt) {
    delete gantt.addTaskLayer;
    delete gantt.addLinkLayer;
  };


  // data_task_types(gantt) {

  getTaskType(type) {
    return "task";
  };
  // };

  /***/
  // }

  // deprecatedWarnings() {

  // return function (gantt) {

  // no deprecated methods for now

  // eslint-disable-next-line no-unused-vars
  deprecated(badCode, goodCode, versionDeprecated, versionDeleted) {

    var formatting = this.env.isIE ? "" : "%c";
    versionDeprecated = versionDeprecated || "v6.0";
    versionDeleted = versionDeleted || "v7.0";

    var message = [
      formatting, "\"", badCode, "\"", formatting,
      " has been deprecated in dhtmlxGantt ", versionDeprecated, " and will stop working in ", versionDeleted, ". Use ",
      formatting, "\"", goodCode, "\"", formatting,
      " instead. \nSee more details at http://docs.dhtmlx.com/gantt/migrating.html "
    ].join("");

    var log = window.console.warn || window.console.log;

    var args = [message];
    if (!this.env.isIE) {
      args = args.concat(["font-weight:bold", "font-weight:normal", "font-weight:bold", "font-weight:normal"]);
    }

    log.apply(window.console, args);
  }

  // gantt.getSlack is defined inside an extension, leave it without message for now

  // };

  // }


  destructor(gantt) {

    gantt.destructor = function () {
      gantt.callEvent("onDestroy", []);
      this.clearAll();

      if (this.config.$root) {
        delete this.config.$root.gantt;
      }

      this._eventRemoveAll();
      if (this.$layout) {
        this.$layout.destructor();
      }

      this.resetLightbox();

      if (this._dp && this._dp.destructor) {
        this._dp.destructor();
      }
      this.$services.destructor();

      // detachAllEvents should be called last, because in components may be attached events
      this.detachAllEvents();

      for (var i in this) {
        if (i.indexOf("$") === 0) {
          delete this[i];
        }
      }
      gantt.$destroyed = true;
    };
  }

  dynamicLoading(gantt) {

  };

  // DHXGantt() {
  //   console.log(this)
  //   var constants = this.constantService.keyCodes();
  //   var version = "6.2.6";
  //   var license = "gpl";
  //   var templates = {};
  //   var ext = {};
  //   var keys = {
  //     edit_save: constants.KEY_CODES.ENTER,
  //     edit_cancel: constants.KEY_CODES.ESC
  //   };
  // }

  // core() {
  //   // use a named constructor to make gantt instance discoverable in heap snapshots
  //   var gantt: any = this.DHXGantt();

  //   gantt.$services = gantt.$inject(this.commonService.services);
  //   this.config = gantt.$inject(this.commonService.config());
  //   gantt.ajax = this.commonService.ajax(gantt);
  //   gantt.date = this.commonService.date(gantt);
  //   var dnd = this.commonService.dnd(gantt);
  //   gantt.$services.setService("dnd", function () { return dnd; });

  //   gantt.$services.setService("config", function () {
  //     return this.config;
  //   });
  //   gantt.$services.setService("date", function () {
  //     return gantt.date;
  //   });
  //   gantt.$services.setService("locale", function () {
  //     return gantt.locale;
  //   });
  //   gantt.$services.setService("templates", function () {
  //     return gantt.templates;
  //   });

  //   var templatesLoader = (this.commonService.templates())(gantt);
  //   gantt.$services.setService("templateLoader", function () {
  //     return templatesLoader;
  //   });

  //   var eventable = (this.utilsService.eventable());
  //   eventable(gantt);

  //   var StateService = (this.commonService.state());
  //   var stateService = StateService();

  //   stateService.registerProvider("global", function () {
  //     var res = {
  //       min_date: gantt._min_date,
  //       max_date: gantt._max_date,
  //       selected_task: null
  //     };

  //     // do not throw error if getState called from non-initialized gantt
  //     if (gantt.$data && gantt.$data.tasksStore) {
  //       res.selected_task = gantt.$data.tasksStore.getSelectedId();
  //     }
  //     return res;
  //   });
  //   gantt.getState = stateService.getState;
  //   gantt.$services.setService("state", function () {
  //     return stateService;
  //   });

  //   var utils = this.utilsService.utils();
  //   utils.mixin(gantt, utils);

  //   gantt.Promise = this.utilsService.promise;
  //   gantt.env = this.utilsService.env;

  //   var domHelpers = this.utilsService;
  //   gantt.utils = {
  //     dom: {
  //       getNodePosition: domHelpers.getNodePosition,
  //       getRelativeEventPosition: domHelpers.getRelativeEventPosition,
  //       isChildOf: domHelpers.isChildOf,
  //       hasClass: domHelpers.hasClass,
  //       closest: domHelpers.closest
  //     }
  //   };

  //   var domEvents: any = this.utilsService.domEventScope();
  //   gantt.event = domEvents.attach;
  //   gantt.eventRemove = domEvents.detach;
  //   gantt._eventRemoveAll = domEvents.detachAll;
  //   gantt._createDomEventScope = domEvents.extend;

  //   utils.mixin(gantt, this.message)(gantt);
  //   var uiApi = this.uiService.index().init(gantt);
  //   gantt.$ui = uiApi.factory;
  //   gantt.$ui.layers = uiApi.render;
  //   gantt.$mouseEvents = uiApi.mouseEvents;
  //   gantt.$services.setService("mouseEvents", function () {
  //     return gantt.$mouseEvents;
  //   });
  //   gantt.mixin(gantt, uiApi.layersApi);

  //   this.data_task_layers(gantt);

  //   gantt.$services.setService("layers", function () {
  //     return uiApi.layersService;
  //   });

  //   var createLayoutFacade = this.facadeService.layout;
  //   gantt.mixin(gantt, createLayoutFacade());

  //   this.dataStoreService.datastoreHooks(gantt);

  //   var DataProcessor = this.dataProcessorService.index();
  //   gantt.dataProcessor = DataProcessor.DEPRECATED_api;
  //   gantt.createDataProcessor = DataProcessor.createDataProcessor;

  //   this.pluginService.index(gantt);

  //   this.dynamicLoading(gantt);
  //   this.gridColumnApi(gantt);
  //   this.waiAria(gantt);
  //   this.tasks(gantt);
  //   this.load(gantt);
  //   this.worktimeService.workTime(gantt);
  //   this.data(gantt);

  //   this.publishHelper.voidScriptSecond().default(gantt);

  //   this.lightboxService.index(gantt);
  //   this.lightboxOptionalTime(gantt);
  //   this.data_task_types(gantt);
  //   this.cachedFunctions(gantt);
  //   this.skin(gantt);
  //   this.skinService.skyblue(gantt);
  //   this.skinService.meadow(gantt);
  //   this.skinService.terrace(gantt);
  //   this.skinService.broadway(gantt);
  //   this.skinService.material(gantt);
  //   this.skinService.contrastBlack(gantt);
  //   this.skinService.contrastWhite(gantt);
  //   this.touch(gantt);
  //   this.localeService.index(gantt);
  //   this.gantt_core(gantt);
  //   this.destructor(gantt);
  //   this.publishHelper.voidScriptThird().default(gantt);
  //   return gantt;
  // }


  gantt() {
    this.commonService.import(this.gantt);
    this.skinService.terraceCss();
    // this.core();

    function DHXGantt() {
      console.log(this)
      var constants = this.constantService.keyCodes();
      var version = "6.2.6";
      var license = "gpl";
      var templates = {};
      var ext = {};
      var keys = {
        edit_save: constants.KEY_CODES.ENTER,
        edit_cancel: constants.KEY_CODES.ESC
      };
    }
    return function core() {
      // use a named constructor to make gantt instance discoverable in heap snapshots
      var gantt: any = new DHXGantt();

      this.$services = this.commonService.services;
      this.config = this.ganttService.config;
      gantt.ajax = this.commonService.ajax(gantt);
      gantt.date = this.commonService.date(gantt);
      var dnd = this.commonService.dnd(gantt);
      gantt.$services.setService("dnd", function () { return dnd; });

      gantt.$services.setService("config", function () {
        return this.config;
      });
      gantt.$services.setService("date", function () {
        return gantt.date;
      });
      gantt.$services.setService("locale", function () {
        return gantt.locale;
      });
      gantt.$services.setService("templates", function () {
        return gantt.templates;
      });

      var templatesLoader = (this.commonService.templates())(gantt);
      gantt.$services.setService("templateLoader", function () {
        return templatesLoader;
      });

      var eventable = (this.utilsService.eventable());
      eventable(gantt);

      var StateService = (this.commonService.state());
      var stateService = StateService();

      stateService.registerProvider("global", function () {
        var res = {
          min_date: gantt._min_date,
          max_date: gantt._max_date,
          selected_task: null
        };

        // do not throw error if getState called from non-initialized gantt
        if (gantt.$data && gantt.$data.tasksStore) {
          res.selected_task = gantt.$data.tasksStore.getSelectedId();
        }
        return res;
      });
      gantt.getState = stateService.getState;
      gantt.$services.setService("state", function () {
        return stateService;
      });

      var utils = this.utilsService.utils();
      utils.mixin(gantt, utils);

      gantt.Promise = this.utilsService.promise;
      gantt.env = this.utilsService.env;

      var domHelpers = this.utilsService;
      gantt.utils = {
        dom: {
          getNodePosition: domHelpers.getNodePosition,
          getRelativeEventPosition: domHelpers.getRelativeEventPosition,
          isChildOf: domHelpers.isChildOf,
          hasClass: domHelpers.hasClass,
          closest: domHelpers.closest
        }
      };

      var domEvents: any = this.utilsService.domEventScope();
      gantt.event = domEvents.attach;
      gantt.eventRemove = domEvents.detach;
      gantt._eventRemoveAll = domEvents.detachAll;
      gantt._createDomEventScope = domEvents.extend;

      utils.mixin(gantt, this.message)(gantt);
      var uiApi = this.uiService.index().init(gantt);
      gantt.$ui = uiApi.factory;
      gantt.$ui.layers = uiApi.render;
      gantt.$mouseEvents = uiApi.mouseEvents;
      gantt.$services.setService("mouseEvents", function () {
        return gantt.$mouseEvents;
      });
      gantt.mixin(gantt, uiApi.layersApi);

      this.data_task_layers(gantt);

      gantt.$services.setService("layers", function () {
        return uiApi.layersService;
      });

      var createLayoutFacade = this.facadeService.layout;
      gantt.mixin(gantt, createLayoutFacade());

      this.dataStoreService.datastoreHooks(gantt);

      var DataProcessor = this.dataProcessorService.index();
      gantt.dataProcessor = DataProcessor.DEPRECATED_api;
      gantt.createDataProcessor = DataProcessor.createDataProcessor;

      this.pluginService.index(gantt);

      this.dynamicLoading(gantt);
      this.gridColumnApi(gantt);
      this.waiAria(gantt);
      this.tasks(gantt);
      this.load(gantt);
      this.worktimeService.workTime(gantt);
      this.data(gantt);

      this.publishHelper.voidScriptSecond().default(gantt);

      this.lightboxService.index(gantt);
      this.lightboxOptionalTime(gantt);
      this.data_task_types(gantt);
      this.cachedFunctions(gantt);
      this.skin(gantt);
      this.skinService.skyblue(gantt);
      this.skinService.meadow(gantt);
      this.skinService.terrace(gantt);
      this.skinService.broadway(gantt);
      this.skinService.material(gantt);
      this.skinService.contrastBlack(gantt);
      this.skinService.contrastWhite(gantt);
      this.touch(gantt);
      this.localeService.index(gantt);
      this.gantt_core(gantt);
      this.destructor(gantt);
      this.publishHelper.voidScriptThird().default(gantt);
      return gantt;
    }
  }


  init(node, from?, to?) {

    if (from && to) {
      this.config.start_date = this.config.min_date = new Date(from);
      this.config.end_date = this.config.max_date = new Date(to);
    }
    // this.date.init();
    this.commonService.init();
    if (!this.config.scroll_size)
      this.config.scroll_size = this.utilsService.getScrollSize() || 1;

    // can be called only once
    this.init = function (node) {
      if (this.$container && this.$container.parentNode) {
        this.$container.parentNode.removeChild(this.$container);
        this.$container = null;
      }

      if (this.$layout) {
        this.$layout.clear();
      }
      this._reinit(node);
    };

    this._reinit(node);
  }

  _reinit = function (node) {
    this.utilsService.callEvent("onBeforeGanttReady", [], undefined);

    // detach listeners before clearing old DOM, possible IE errors when accessing detached nodes
    this.utilsService.detachAll();
    this.uiService.reset();

    this.resetLightbox();
    this._update_flags();


    var config = this.$services.getService("templateLoader");
    config.initTemplates(this);

    this._clearTaskLayers();
    this._clearLinkLayers();

    //this.clear
    if (this.$layout) {
      this.$layout.destructor();
      this.$ui.reset();
    }

    this.config.$root = this.utilsService.toNode(node);
    if (this.config.$root) {
      this.config.$root.innerHTML = "";
    }
    this.config.$root.gantt = this;
    this.calculateScaleRange(this);
    this.config.layout.id = "main";
    this.$layout = this.$ui.createView("layout", node, this.config.layout);

    this.$layout.attachEvent("onBeforeResize", function () {
      var storeNames = this.$services.getService("datastores");
      for (var i = 0; i < storeNames.length; i++) {
        gantt.getDatastore(storeNames[i]).filter();
      }
    });

    this.$layout.attachEvent("onResize", function () {
      gantt.refreshData();
    });

    this.utilsService.callEvent("onGanttLayoutReady", [], undefined);
    this.$layout.render();

    this.$container = this.$layout.$container.firstChild;

    this.addResizeListener(gantt);

    this.utilsService.callEvent("onTemplatesReady", [], undefined);
    this.uiService.reset(this.config.$root);
    this.utilsService.callEvent("onGanttReady", [], undefined);

    this.render();
  };


  gantt_core(gantt) {
    var domHelpers = this.utilsService,
      helpers = this.utilsService;
    var calculateScaleRange = this.ganttDataRange();

    // gantt.assert = this.commonService.assert(gantt);

    //initial initialization
    // gantt.init = function (node, from, to) {
    //   if (from && to) {
    //     this.config.start_date = this._min_date = new Date(from);
    //     this.config.end_date = this._max_date = new Date(to);
    //   }
    //   this.date.init();

    //   if (!this.config.scroll_size)
    //     this.config.scroll_size = domHelpers.getScrollSize() || 1;

    //   //can be called only once
    //   this.init = function (node) {
    //     if (this.$container && this.$container.parentNode) {
    //       this.$container.parentNode.removeChild(this.$container);
    //       this.$container = null;
    //     }

    //     if (this.$layout) {
    //       this.$layout.clear();
    //     }
    //     this._reinit(node);
    //   };

    //   this._reinit(node);
    // };


    function addResizeListener(gantt) {
      var containerStyles = window.getComputedStyle(gantt.$root);
      if (containerStyles.getPropertyValue("position") == "static") {
        gantt.$root.style.position = "relative";
      }

      var resizeWatcher = document.createElement('iframe');
      resizeWatcher.className = "gantt_container_resize_watcher";
      resizeWatcher.tabIndex = -1;

      // in some environments (namely, in SalesForce) iframe.contentWindow is not available
      gantt.$root.appendChild(resizeWatcher);
      if (resizeWatcher.contentWindow) {
        listenWindowResize(gantt, resizeWatcher.contentWindow);
      } else {
        // if so - ditch the iframe and fallback to listening the main window resize
        gantt.$root.removeChild(resizeWatcher);
        listenWindowResize(gantt, window);
      }
    }

    function listenWindowResize(gantt, window) {
      var resizeDelay;
      gantt.event(window, "resize", function () {
        clearTimeout(resizeDelay);
        resizeDelay = setTimeout(function () {
          gantt.render();
        }, 300);
      });
    }

    gantt.$click = {
      buttons: {
        "edit": function (id) {
          gantt.showLightbox(id);
        },
        "delete": function (id) {
          var question = gantt.locale.labels.confirm_deleting;
          var title = gantt.locale.labels.confirm_deleting_title;

          gantt._dhtmlx_confirm(question, title, function () {
            if (!gantt.isTaskExists(id)) {
              gantt.hideLightbox();
              return;
            }

            var task = gantt.getTask(id);
            if (task.$new) {
              gantt.silent(function () {
                gantt.deleteTask(id, true);
              });
              gantt.refreshData();
            } else {
              gantt.deleteTask(id);
            }

            gantt.hideLightbox();
          });
        }
      }
    };

    //renders self
    gantt.render = function () {
      this.callEvent("onBeforeGanttRender", []);

      if (!this.config.sort && this._sort) {
        this._sort = undefined;
      }

      var pos = this.getScrollState();
      var posX = pos ? pos.x : 0;
      if (this._getHorizontalScrollbar()) {
        var scrollbar = this._getHorizontalScrollbar();
        posX = scrollbar.$config.codeScrollLeft || posX || 0;
      }


      var visible_date = null;
      if (posX) {
        visible_date = gantt.dateFromPos(posX + this.config.task_scroll_offset);
      }
      calculateScaleRange(this);

      this.$layout.$config.autosize = this.config.autosize;
      this.$layout.resize();

      if (this.config.preserve_scroll && pos) {

        if (posX) {
          var new_pos = gantt.getScrollState();
          var new_date = gantt.dateFromPos(new_pos.x);
          if (!(+visible_date == +new_date && new_pos.y == pos.y)) {
            if (visible_date) {
              this.showDate(visible_date);
            }
            if (pos.y)
              gantt.scrollTo(undefined, pos.y);
          }
        }
      }

      this.callEvent("onGanttRender", []);
    };

    //TODO: add layout.resize method that wouldn't trigger data repaint
    gantt.setSizes = gantt.render;

    gantt.locate = function (e) {
      var trg = domHelpers.getTargetNode(e);

      //ignore empty cells
      var className = domHelpers.getClassName(trg);
      if ((className || "").indexOf("gantt_task_cell") >= 0) return null;

      var targetAttribute = arguments[1] || this.config.task_attribute;

      var node = domHelpers.locateAttribute(trg, targetAttribute);
      if (node) {
        return node.getAttribute(targetAttribute);
      } else {
        return null;
      }
    };

    gantt._locate_css = function (e, classname, strict) {
      return domHelpers.locateClassName(e, classname, strict);
    };

    gantt._locateHTML = function (e, attribute) {
      return domHelpers.locateAttribute(e, attribute || this.config.task_attribute);
    };

    gantt.getTaskRowNode = function (id) {
      var els = this.$grid_data.childNodes;
      var attribute = this.config.task_attribute;
      for (var i = 0; i < els.length; i++) {
        if (els[i].getAttribute) {
          var value = els[i].getAttribute(attribute);
          if (value == id) return els[i];
        }
      }
      return null;
    };

    gantt.changeLightboxType = function (type) {
      if (this.getLightboxType() == type)
        return true;
      gantt._silent_redraw_lightbox(type);
    };


    gantt._get_link_type = function (from_start, to_start) {
      var type = null;
      if (from_start && to_start) {
        type = this.config.links.start_to_start;
      } else if (!from_start && to_start) {
        type = this.config.links.finish_to_start;
      } else if (!from_start && !to_start) {
        type = this.config.links.finish_to_finish;
      } else if (from_start && !to_start) {
        type = this.config.links.start_to_finish;
      }
      return type;
    };

    gantt.isLinkAllowed = function (from, to, from_start, to_start) {
      var link = null;
      if (typeof (from) == "object") {
        link = from;
      } else {
        link = { source: from, target: to, type: this._get_link_type(from_start, to_start) };
      }

      if (!link) return false;
      if (!(link.source && link.target && link.type)) return false;
      if (link.source == link.target) return false;

      var res = true;
      //any custom rules
      if (this.checkEvent("onLinkValidation"))
        res = this.callEvent("onLinkValidation", [link]);

      return res;
    };


    gantt._correct_dst_change = function (date, prevOffset, step, unit) {
      var time_unit = helpers.getSecondsInUnit(unit) * step;
      if (time_unit > 60 * 60 && time_unit < 60 * 60 * 24) {
        //correct dst change only if current unit is more than one hour and less than day (days have own checking), e.g. 12h
        var offsetChanged = date.getTimezoneOffset() - prevOffset;
        if (offsetChanged) {
          date = gantt.date.add(date, offsetChanged, "minute");
        }
      }
      return date;
    };

    gantt.isSplitTask = function (task) {
      gantt.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isSplitTask. Task object was expected");
      return this.$data.tasksStore._isSplitItem(task);
    };

    gantt._is_icon_open_click = function (e) {
      if (!e)
        return false;
      var target = e.target || e.srcElement;
      if (!(target && target.className))
        return false;
      var className = domHelpers.getClassName(target);
      if (className.indexOf("gantt_tree_icon") !== -1 && (className.indexOf("gantt_close") !== -1 || className.indexOf("gantt_open") !== -1))
        return true;
      return false;
    };

  };

  /***/
  // }

  ganttDataRange() {

    var scaleHelper = this.timelineService.scales();
    var PrimaryScaleHelper = this.timelineService.scales();


    function dateRangeResolver(gantt) {
      //reset project timing
      //_get_tasks_data(gantt);
      return gantt.getSubtaskDates();
    }

    function defaultRangeResolver() {
      return {
        start_date: new Date(),
        end_date: new Date()
      };
    }

    function resolveConfigRange(unit, gantt) {
      var range = {
        start_date: null,
        end_date: null
      };

      if (this.config.start_date && this.config.end_date) {
        range.start_date = gantt.date[unit + "_start"](new Date(this.config.start_date));

        var end = new Date(this.config.end_date);
        var start_interval = gantt.date[unit + "_start"](new Date(end));
        if (+end != +start_interval) {
          end = gantt.date.add(start_interval, 1, unit);
        } else {
          end = start_interval;
        }

        range.end_date = end;
      }
      return range;
    }

    function _scale_range_unit(gantt) {
      var primaryScale = (PrimaryScaleHelper(gantt)).primaryScale();
      var unit = primaryScale.unit;
      var step = primaryScale.step;
      if (this.config.scale_offset_minimal) {

        var helper = scaleHelper(gantt);
        var scales = [helper.primaryScale()].concat(helper.getSubScales());

        helper.sortScales(scales);
        unit = scales[scales.length - 1].unit;
        step = scales[scales.length - 1].step || 1;
      }
      return { unit: unit, step: step };
    }

    function _init_tasks_range(gantt) {
      var cfg = _scale_range_unit(gantt);
      var unit = cfg.unit,
        step = cfg.step;
      var range = resolveConfigRange(unit, gantt);

      if (!(range.start_date && range.end_date)) {
        range = dateRangeResolver(gantt);
        if (!range.start_date || !range.end_date) {
          // range = defaultRangeResolver(gantt);
          range = defaultRangeResolver();
        }

        range.start_date = gantt.date[unit + "_start"](range.start_date);
        range.start_date = gantt.calculateEndDate({
          start_date: gantt.date[unit + "_start"](range.start_date),
          duration: -1,
          unit: unit,
          step: step
        });//one free column before first task

        range.end_date = gantt.date[unit + "_start"](range.end_date);
        range.end_date = gantt.calculateEndDate({ start_date: range.end_date, duration: 2, unit: unit, step: step });//one free column after last task
      }

      gantt._min_date = range.start_date;
      gantt._max_date = range.end_date;
    }

    function _adjust_scales(gantt) {
      if (this.config.fit_tasks) {
        var old_min = +gantt._min_date,
          old_max = +gantt._max_date;
        //this._init_tasks_range();
        if (+gantt._min_date != old_min || +gantt._max_date != old_max) {
          gantt.render();

          gantt.callEvent("onScaleAdjusted", []);
          return true;
        }
      }
      return false;
    }

    return function updateTasksRange(gantt) {
      _init_tasks_range(gantt);
      _adjust_scales(gantt);
    };


    /***/
  }

  // () {

  gridColumnApi(gantt) {
    gantt.getGridColumn = function (name) {
      var columns = this.config.columns;

      for (var i = 0; i < columns.length; i++) {
        if (columns[i].name == name)
          return columns[i];
      }

      return null;
    };

    gantt.getGridColumns = function () {
      return this.config.columns.slice();
    };
  };

  /***/
  // }

  // lightboxOptionalTime() {

  lightboxOptionalTime(gantt) {

    gantt._extend_to_optional = function (lightbox_block) {

      var duration = lightbox_block;
      var optional_time = {
        render: duration.render,
        focus: duration.focus,
        set_value: function (node, value, task, section) {
          var mapping = gantt._resolve_default_mapping(section);
          if (!task[mapping.start_date] || (mapping.start_date == "start_date" && this._isAllowedUnscheduledTask(task))) {
            optional_time.disable(node, section);
            var val = {};

            for (var i in mapping) {
              //take default values from the time control from task start/end dates
              val[mapping[i]] = task[i];
            }

            return duration.set_value.call(gantt, node, value, val, section);//set default value
          } else {
            optional_time.enable(node, section);
            return duration.set_value.call(gantt, node, value, task, section);
          }
        },
        get_value: function (node, task, section) {
          if (section.disabled) {
            return { start_date: null };
          } else {
            return duration.get_value.call(gantt, node, task, section);
          }
        },
        update_block: function (node, section) {
          gantt.callEvent("onSectionToggle", [gantt._lightbox_id, section]);
          node.style.display = section.disabled ? "none" : "block";

          if (section.button) {
            var button = node.previousSibling.querySelector(".gantt_custom_button_label"),
              labels = gantt.locale.labels;

            var button_text = section.disabled ? labels[section.name + "_enable_button"] : labels[section.name + "_disable_button"];

            button.innerHTML = button_text;
          }
          gantt.resizeLightbox();
        },
        disable: function (node, section) {
          section.disabled = true;
          optional_time.update_block(node, section);

        },
        enable: function (node, section) {
          section.disabled = false;
          optional_time.update_block(node, section);
        },
        button_click: function (index, el, section, container) {
          if (gantt.callEvent("onSectionButton", [gantt._lightbox_id, section]) === false) {
            return;
          }
          var config = gantt._get_typed_lightbox_config()[index];
          if (config.disabled) {
            optional_time.enable(container, config);
          } else {
            optional_time.disable(container, config);
          }
        }
      };
      return optional_time;
    };

    gantt.form_blocks.duration_optional = gantt._extend_to_optional(gantt.form_blocks.duration);
    gantt.form_blocks.time_optional = gantt._extend_to_optional(gantt.form_blocks.time);

  };

  /***/
  // }

  // load() {    

  load(gantt) {
    var helpers = this.utilsService;
    gantt.load = function (url, type, callback) {
      this._load_url = url;
      this.assert(arguments.length, "Invalid load arguments");

      var tp = 'json', cl = null;
      if (arguments.length >= 3) {
        tp = type;
        cl = callback;
      } else {
        if (typeof arguments[1] == "string")
          tp = arguments[1];
        else if (typeof arguments[1] == "function")
          cl = arguments[1];
      }

      this._load_type = tp;

      this.callEvent("onLoadStart", [url, tp]);

      return this.ajax.get(url, gantt.bind(function (l) {
        this.on_load(l, tp);
        this.callEvent("onLoadEnd", [url, tp]);
        if (typeof cl == "function")
          cl.call(this);
      }, this));
    };
    gantt.parse = function (data, type) {
      this.on_load({ xmlDoc: { responseText: data } }, type);
    };

    gantt.serialize = function (type) {
      type = type || "json";
      return this[type].serialize();
    };

    /*
    tasks and relations
    {
    data:[
      {
        "id":"string",
        "text":"...",
        "start_date":"Date or string",
        "end_date":"Date or string",
        "duration":"number",
        "progress":"0..1",
        "parent_id":"string",
        "order":"number"
      },...],
    links:[
      {
        id:"string",
        source:"string",
        target:"string",
        type:"string"
      },...],
    collections:{
        collectionName:[
          {key:, label:, optional:...},...
        ],...
      }
    }
  
    * */

    gantt.on_load = function (resp, type) {
      if (resp.xmlDoc && resp.xmlDoc.status === 404) { // work if we don't have a file at current url
        this.assert(false, "Failed to load the data from <a href='" + resp.xmlDoc.responseURL + "' target='_blank'>"
          + resp.xmlDoc.responseURL + "</a>, server returns 404");
        return;
      }
      this.callEvent("onBeforeParse", []);
      if (!type)
        type = "json";
      this.assert(this[type], "Invalid data type:'" + type + "'");

      var raw = resp.xmlDoc.responseText;

      var data = this[type].parse(raw, resp);
      this._process_loading(data);
    };

    gantt._process_loading = function (data) {
      if (data.collections)
        this._load_collections(data.collections);

      this.$data.tasksStore.parse(data.data);
      var links = data.links || (data.collections ? data.collections.links : []);
      this.$data.linksStore.parse(links);

      //this._sync_links();
      this.callEvent("onParse", []);
      this.render();
      if (this.config.initial_scroll) {
        var firstTask = this.getTaskByIndex(0);
        var id = firstTask ? firstTask.id : this.config.root_id;
        if (this.isTaskExists(id))
          this.showTask(id);
      }
    };


    gantt._load_collections = function (collections) {
      var collections_loaded = false;
      for (var key in collections) {
        if (collections.hasOwnProperty(key)) {
          collections_loaded = true;
          var collection = collections[key];
          var arr = this.serverList[key];
          if (!arr) continue;
          arr.splice(0, arr.length); //clear old options
          for (var j = 0; j < collection.length; j++) {
            var option = collection[j];
            var obj = this.copy(option);
            obj.key = obj.value;// resulting option object

            for (var option_key in option) {
              if (option.hasOwnProperty(option_key)) {
                if (option_key == "value" || option_key == "label")
                  continue;
                obj[option_key] = option[option_key]; // obj['value'] = option['value']
              }
            }
            arr.push(obj);
          }
        }
      }
      if (collections_loaded)
        this.callEvent("onOptionsLoad", []);
    };

    gantt.attachEvent("onBeforeTaskDisplay", function (id, task) {
      return !task.$ignore;
    });

    function jsonParseError(data) {
      gantt.assert(false, "Can't parse data: incorrect value of gantt.parse or gantt.load method. "
        + "Actual argument value: " + JSON.stringify(data));
      throw new Error("Invalid argument for gantt.parse or gantt.load. An object or a JSON string of format https://docs.dhtmlx.com/gantt/desktop__supported_data_formats.html#json is expected. Actual argument value: "
        + JSON.stringify(data));
    }

    gantt.json = {
      parse: function (data) {
        if (!data) {
          jsonParseError(data);
        }

        if (typeof data == "string") {
          if (this.window.JSON) {
            try {
              data = JSON.parse(data);
            }
            catch (e) {
              jsonParseError(data);
            }
          } else {
            gantt.assert(false, "JSON is not supported");
          }
        }

        if (!data.data) {
          jsonParseError(data);
        }

        if (data.dhx_security)
          gantt.security_key = data.dhx_security;
        return data;
      },
      serializeTask: function (task) {
        return this._copyObject(task);
      },
      serializeLink: function (link) {
        return this._copyLink(link);
      },
      _copyLink: function (obj) {
        var copy = {};
        for (var key in obj)
          copy[key] = obj[key];
        return copy;
      },
      _copyObject: function (obj) {
        var copy = {};
        for (var key in obj) {
          if (key.charAt(0) == "$")
            continue;
          copy[key] = obj[key];

          if (helpers.isDate(copy[key])) {
            copy[key] = gantt.templates.xml_format !== gantt.templates.formate_date ? gantt.templates.xml_format(copy[key]) : gantt.templates.formate_date(copy[key]);
          }
        }
        return copy;
      },
      serialize: function () {
        var tasks = [];
        var links = [];

        gantt.eachTask(function (obj) {
          gantt.resetProjectDates(obj);
          tasks.push(this.serializeTask(obj));
        }, this.config.root_id, this);

        var rawLinks = gantt.getLinks();
        for (var i = 0; i < rawLinks.length; i++) {
          links.push(this.serializeLink(rawLinks[i]));
        }

        return {
          data: tasks,
          links: links
        };
      }
    };

    /*
    <data>
      <task id:"some" parent_id="0" progress="0.5">
        <text>My task 1</text>
        <start_date>16.08.2013</start_date>
        <end_date>22.08.2013</end_date>
      </task>
      <coll_options>
        <links>
          <link source='a1' target='b2' type='c3' />
        </links>
      </coll_options>
    </data>
    */

    function xmlParseError(data) {
      gantt.assert(false, "Can't parse data: incorrect value of gantt.parse or gantt.load method. "
        + "Actual argument value: " + JSON.stringify(data));
      throw new Error("Invalid argument for gantt.parse or gantt.load. An XML of format https://docs.dhtmlx.com/gantt/desktop__supported_data_formats.html#xmldhtmlxgantt20 is expected. Actual argument value: "
        + JSON.stringify(data));
    }

    gantt.xml = {
      _xmlNodeToJSON: function (node, attrs_only) {
        var t: any = {};
        for (var i = 0; i < node.attributes.length; i++)
          t[node.attributes[i].name] = node.attributes[i].value;

        if (!attrs_only) {
          for (var i = 0; i < node.childNodes.length; i++) {
            var child = node.childNodes[i];
            if (child.nodeType == 1)
              t[child.tagName] = child.firstChild ? child.firstChild.nodeValue : "";
          }

          if (!t.text) t.text = node.firstChild ? node.firstChild.nodeValue : "";
        }

        return t;
      },
      _getCollections: function (loader) {
        var collection = {};
        var opts = gantt.ajax.xpath("//coll_options", loader);
        for (var i = 0; i < opts.length; i++) {
          var bind = opts[i].getAttribute("for");
          var arr = collection[bind] = [];
          var itms = gantt.ajax.xpath(".//item", opts[i]);
          for (var j = 0; j < itms.length; j++) {
            var itm = itms[j];
            var attrs = itm.attributes;
            var obj = { key: itms[j].getAttribute("value"), label: itms[j].getAttribute("label") };
            for (var k = 0; k < attrs.length; k++) {
              var attr = attrs[k];
              if (attr.nodeName == "value" || attr.nodeName == "label")
                continue;
              obj[attr.nodeName] = attr.nodeValue;
            }
            arr.push(obj);
          }
        }
        return collection;
      },
      _getXML: function (text, loader, toptag) {
        toptag = toptag || "data";
        if (!loader.getXMLTopNode) {
          loader = gantt.ajax.parse(loader);
        }

        var xml = gantt.ajax.xmltop(toptag, loader.xmlDoc);
        if (!xml || xml.tagName != toptag) {
          xmlParseError(text);
        }

        var skey = xml.getAttribute("dhx_security");
        if (skey)
          gantt.security_key = skey;

        return xml;
      },
      parse: function (text, loader) {
        loader = this._getXML(text, loader);
        var data: any = {};

        var evs = data.data = [];
        var xml = gantt.ajax.xpath("//task", loader);

        for (var i = 0; i < xml.length; i++)
          evs[i] = this._xmlNodeToJSON(xml[i]);

        data.collections = this._getCollections(loader);
        return data;
      },
      _copyLink: function (obj) {
        return "<item id='" + obj.id + "' source='" + obj.source + "' target='" + obj.target + "' type='" + obj.type + "' />";
      },
      _copyObject: function (obj) {
        return "<task id='" + obj.id + "' parent='" + (obj.parent || "") + "' start_date='" + obj.start_date + "' duration='" + obj.duration + "' open='" + (!!obj.open) + "' progress='" + obj.progress + "' end_date='" + obj.end_date + "'><![CDATA[" + obj.text + "]]></task>";
      },
      serialize: function () {
        var tasks = [];
        var links = [];

        var json = gantt.json.serialize();
        for (var i = 0, len = json.data.length; i < len; i++) {
          tasks.push(this._copyObject(json.data[i]));
        }
        for (var i = 0, len = json.links.length; i < len; i++) {
          links.push(this._copyLink(json.links[i]));
        }
        return "<data>" + tasks.join("") + "<coll_options for='links'>" + links.join("") + "</coll_options></data>";
      }
    };


    gantt.oldxml = {
      parse: function (text, loader) {
        loader = gantt.xml._getXML(text, loader, "projects");
        var data: any = { collections: { links: [] } };

        var evs = data.data = [];
        var xml = gantt.ajax.xpath("//task", loader);

        for (var i = 0; i < xml.length; i++) {
          evs[i] = gantt.xml._xmlNodeToJSON(xml[i]);
          var parent = xml[i].parentNode;

          if (parent.tagName == "project")
            evs[i].parent = "project-" + parent.getAttribute("id");
          else
            evs[i].parent = parent.parentNode.getAttribute("id");
        }

        xml = gantt.ajax.xpath("//project", loader);
        for (var i = 0; i < xml.length; i++) {
          var ev = gantt.xml._xmlNodeToJSON(xml[i], true);
          ev.id = "project-" + ev.id;
          evs.push(ev);
        }

        for (var i = 0; i < evs.length; i++) {
          var ev = evs[i];
          ev.start_date = ev.startdate || ev.est;
          ev.end_date = ev.enddate;
          ev.text = ev.name;
          ev.duration = ev.duration / 8;
          ev.open = 1;
          if (!ev.duration && !ev.end_date) ev.duration = 1;
          if (ev.predecessortasks)
            data.collections.links.push({
              target: ev.id,
              source: ev.predecessortasks,
              type: this.config.links.finish_to_start
            });
        }

        return data;
      },
      serialize: function () {
        gantt.message("Serialization to 'old XML' is not implemented");
      }
    };

    gantt.serverList = function (name, array) {
      if (array) {
        this.serverList[name] = array.slice(0);
      } else if (!this.serverList[name]) {
        this.serverList[name] = [];
      }
      return this.serverList[name];
    };

  };

  /***/
  // }

  // message() {


  /***/
  // }

  skin(gantt) {

    function _configure(col, data, force) {
      for (var key in data)
        if (typeof col[key] == "undefined" || force)
          col[key] = data[key];
    }

    function _get_skin(force, gantt) {
      var skin = gantt.skin;
      if (!skin || force) {
        var links = document.getElementsByTagName("link");
        for (var i = 0; i < links.length; i++) {
          var res = links[i].href.match("dhtmlxgantt_([a-z_]+).css");
          if (res) {
            if (gantt.skins[res[1]] || !skin) {
              skin = res[1];
              break;
            }
          }
        }
      }

      gantt.skin = skin || "terrace";
      var skinset = gantt.skins[gantt.skin] || gantt.skins["terrace"];

      //apply skin related settings
      _configure(this.config, skinset.config, force);

      var config = gantt.getGridColumns();
      if (config[1] && !gantt.defined(config[1].width))
        config[1].width = skinset._second_column_width;
      if (config[2] && !gantt.defined(config[2].width))
        config[2].width = skinset._third_column_width;

      for (var i = 0; i < config.length; i++) {
        var column = config[i];
        if (column.name == "add") {
          if (!column.width) {
            column.width = 44;
          }
          if (!(gantt.defined(column.min_width) && gantt.defined(column.max_width))) {
            column.min_width = column.min_width || column.width;
            column.max_width = column.max_width || column.width;
          }
          if (column.min_width)
            column.min_width = +column.min_width;
          if (column.max_width)
            column.max_width = +column.max_width;
          if (column.width) {
            column.width = +column.width;
            column.width = (column.min_width && column.min_width > column.width) ? column.min_width : column.width;
            column.width = (column.max_width && column.max_width < column.width) ? column.max_width : column.width;
          }
        }
      }

      if (skinset.config.task_height)
        this.config.task_height = skinset.config.task_height || "full";

      if (skinset._lightbox_template)
        gantt._lightbox_template = skinset._lightbox_template;

      if (skinset._redefine_lightbox_buttons) {
        this.config.buttons_right = skinset._redefine_lightbox_buttons["buttons_right"];
        this.config.buttons_left = skinset._redefine_lightbox_buttons["buttons_left"];
      }


      gantt.resetLightbox();
    }

    return function (gantt) {
      if (!gantt.resetSkin) {
        gantt.resetSkin = function () {
          this.skin = "";
          _get_skin(true, this);
        };
        gantt.skins = {};

        gantt.attachEvent("onGanttLayoutReady", function () {
          _get_skin(false, this);
        });
      }
    };

    /***/
  }

  // tasks() {

  tasks(gantt) {
    gantt.isReadonly = function (item) {
      if (item && item[this.config.editable_property]) {
        return false;
      } else {
        return (item && item[this.config.readonly_property]) || this.config.readonly;
      }
    };
  };

  /***/
  // }

  // touch() {

  touch(gantt) {

    this.config.touch_drag = 500; //nearly immediate dnd
    this.config.touch = true;
    this.config.touch_feedback = true;
    this.config.touch_feedback_duration = 1;
    gantt._prevent_touch_scroll = false;


    gantt._touch_feedback = function () {
      if (this.config.touch_feedback) {
        if (navigator.vibrate)
          navigator.vibrate(this.config.touch_feedback_duration);
      }
    };

    gantt.attachEvent("onGanttReady", gantt.bind(function () {
      if (this.config.touch != "force")
        this.config.touch = this.config.touch &&
          ((navigator.userAgent.indexOf("Mobile") != -1) ||
            (navigator.userAgent.indexOf("iPad") != -1) ||
            (navigator.userAgent.indexOf("Android") != -1) ||
            (navigator.userAgent.indexOf("Touch") != -1));

      if (this.config.touch) {

        var touchEventsSupported = true;
        try {
          document.createEvent("TouchEvent");
        } catch (e) {
          touchEventsSupported = false;
        }

        if (touchEventsSupported) {
          this._touch_events(["touchmove", "touchstart", "touchend"], function (ev) {
            if (ev.touches && ev.touches.length > 1) return null;
            if (ev.touches[0])
              return {
                target: ev.target,
                pageX: ev.touches[0].pageX,
                pageY: ev.touches[0].pageY,
                clientX: ev.touches[0].clientX,
                clientY: ev.touches[0].clientY
              };
            else
              return ev;
          }, function () {
            return false;
          });
        } else if (window.navigator.pointerEnabled) {
          this._touch_events(["pointermove", "pointerdown", "pointerup"], function (ev) {
            if (ev.pointerType == "mouse") return null;
            return ev;
          }, function (ev) {
            return (!ev || (ev.pointerType == "mouse"));
          });
        } else if (window.navigator.msPointerEnabled) {
          this._touch_events(["MSPointerMove", "MSPointerDown", "MSPointerUp"], function (ev) {
            if (ev.pointerType == ev.MSPOINTER_TYPE_MOUSE) return null;
            return ev;
          }, function (ev) {
            return (!ev || ev.pointerType == ev.MSPOINTER_TYPE_MOUSE);
          });
        }

      }
    }, gantt));


    function getTaskDND() {
      var _tasks_dnd;
      if (gantt.$ui.getView("timeline")) {
        _tasks_dnd = gantt.$ui.getView("timeline")._tasks_dnd;
      }
      return _tasks_dnd;
    }

    var touchHandlers = [];

    //we can't use native scrolling, as we need to sync momentum between different parts
    //so we will block native scroll and use the custom one
    //in future we can add custom momentum
    gantt._touch_events = function (names, accessor, ignore) {
      //webkit on android need to be handled separately
      var dblclicktime: any = 0;
      var action_mode = false;
      var scroll_mode = false;
      var action_start = null;
      var scroll_state;
      var long_tap_timer = null;
      var current_target = null;



      for (var i = 0; i < touchHandlers.length; i++) {
        gantt.eventRemove(touchHandlers[i][0], touchHandlers[i][1], touchHandlers[i][2]);
      }
      touchHandlers = [];

      //touch move
      touchHandlers.push([gantt.$container, names[0], function (e) {
        var _tasks_dnd = getTaskDND();

        if (ignore(e)) return;

        //ignore common and scrolling moves
        if (!action_mode) return;

        if (long_tap_timer) clearTimeout(long_tap_timer);

        var source = accessor(e);
        if (_tasks_dnd && (_tasks_dnd.drag.id || _tasks_dnd.drag.start_drag)) {
          _tasks_dnd.on_mouse_move(source);
          if (e.preventDefault)
            e.preventDefault();
          e.cancelBubble = true;
          return false;
        }
        if (!gantt._prevent_touch_scroll) {
          if (source && action_start) {
            var dx = action_start.pageX - source.pageX;
            var dy = action_start.pageY - source.pageY;
            if (!scroll_mode && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
              gantt._touch_scroll_active = scroll_mode = true;
              dblclicktime = 0;
              scroll_state = gantt.getScrollState();
            }

            if (scroll_mode) {
              gantt.scrollTo(scroll_state.x + dx, scroll_state.y + dy);
              var new_scroll_state = gantt.getScrollState();

              if ((scroll_state.x != new_scroll_state.x && dy > 2 * dx) ||
                (scroll_state.y != new_scroll_state.y && dx > 2 * dy)) {
                return block_action(e);
              }
            }
          }
          return block_action(e);
        }
        return true;
      }]);


      //block touch context menu in IE10
      touchHandlers.push([this.$container, "contextmenu", function (e) {
        if (action_mode)
          return block_action(e);
      }]);

      //touch start
      touchHandlers.push([this.$container, names[1], function (e) {
        if (ignore(e)) return;
        if (e.touches && e.touches.length > 1) {
          action_mode = false;
          return;
        }

        action_start = accessor(e);
        if (!gantt._locate_css(action_start, "gantt_hor_scroll") && !gantt._locate_css(action_start, "gantt_ver_scroll")) {
          action_mode = true;
        }
        var _tasks_dnd = getTaskDND();

        //long tap
        long_tap_timer = setTimeout(function () {
          var taskId = gantt.locate(action_start);
          if (_tasks_dnd && (taskId && !gantt._locate_css(action_start, "gantt_link_control") && !gantt._locate_css(action_start, "gantt_grid_data"))) {
            _tasks_dnd.on_mouse_down(action_start);

            if (_tasks_dnd.drag && _tasks_dnd.drag.start_drag) {
              cloneTaskRendered(taskId);
              _tasks_dnd._start_dnd(action_start);
              gantt._touch_drag = true;

              gantt.refreshTask(taskId);

              gantt._touch_feedback();
            }

          }

          long_tap_timer = null;
        }, this.config.touch_drag);
      }]);

      //touch end
      touchHandlers.push([this.$container, names[2], function (e) {
        if (ignore(e)) return;
        if (long_tap_timer) clearTimeout(long_tap_timer);
        gantt._touch_drag = false;
        action_mode = false;
        var source = accessor(e);

        var _tasks_dnd = getTaskDND();

        if (_tasks_dnd)
          _tasks_dnd.on_mouse_up(source);

        if (current_target) {
          gantt.refreshTask(gantt.locate(current_target));
          if (current_target.parentNode) {
            current_target.parentNode.removeChild(current_target);
            gantt._touch_feedback();
          }
        }

        gantt._touch_scroll_active = action_mode = scroll_mode = false;
        current_target = null;

        //dbl-tap handling
        if (action_start && dblclicktime) {
          var now: any = new Date();
          if ((now - dblclicktime) < 500) {

            var mouseEvents = gantt.$services.getService("mouseEvents");
            mouseEvents.onDoubleClick(action_start);
            block_action(e);
          } else
            dblclicktime = now;
        } else {
          dblclicktime = new Date();
        }
      }]);

      for (var i = 0; i < touchHandlers.length; i++) {
        gantt.event(touchHandlers[i][0], touchHandlers[i][1], touchHandlers[i][2]);
      }

      //common helper, prevents event
      function block_action(e) {
        if (e && e.preventDefault)
          e.preventDefault();
        (e || event).cancelBubble = true;
        return false;
      }

      function cloneTaskRendered(taskId) {
        var renders = gantt._getTaskLayers();
        var task = gantt.getTask(taskId);
        if (task && gantt.isTaskVisible(taskId)) {
          for (var i = 0; i < renders.length; i++) {
            task = renders[i].rendered[taskId];
            if (task && task.getAttribute(this.config.task_attribute) && task.getAttribute(this.config.task_attribute) == taskId) {
              var copy = task.cloneNode(true);
              current_target = task;
              renders[i].rendered[taskId] = copy;
              task.style.display = "none";
              copy.className += " gantt_drag_move ";
              task.parentNode.appendChild(copy);
              //return copy;
            }
          }
        }
      }
    };

  };

  /***/
  // }

  // waiAria() {

  waiAria(gantt) {
    // TODO: why eslint fails on regexp?
    // eslint-disable-next-line no-control-regex
    var htmlTags = new RegExp("<(?:.|\n)*?>", "gm");
    var extraSpaces = new RegExp(" +", "gm");

    function stripHTMLLite(htmlText) {
      return (htmlText + "")
        .replace(htmlTags, " ").
        replace(extraSpaces, " ");
    }

    var singleQuotes = new RegExp("'", "gm");
    function escapeQuotes(text) {
      return (text + "").replace(singleQuotes, "&#39;");
    }

    gantt._waiAria = {
      getAttributeString: function (attr) {
        var attributes = [" "];
        for (var i in attr) {
          var text = escapeQuotes(stripHTMLLite(attr[i]));
          attributes.push(i + "='" + text + "'");
        }
        attributes.push(" ");
        return attributes.join(" ");

      },

      getTimelineCellAttr: function (dateString) {

        return gantt._waiAria.getAttributeString({ "aria-label": dateString });
      },

      _taskCommonAttr: function (task, div) {

        if (!(task.start_date && task.end_date))
          return;

        div.setAttribute("aria-label", stripHTMLLite(gantt.templates.tooltip_text(task.start_date, task.end_date, task)));

        if (gantt.isReadonly(task)) {
          div.setAttribute("aria-readonly", true);
        }

        if (task.$dataprocessor_class) {
          div.setAttribute("aria-busy", true);
        }

        div.setAttribute("aria-selected", gantt.isSelectedTask(task.id) ? "true" : "false");
      },

      setTaskBarAttr: function (task, div) {
        this._taskCommonAttr(task, div);

        if (!gantt.isReadonly(task) && this.config.drag_move) {
          if (task.id != gantt.getState().drag_id) {
            div.setAttribute("aria-grabbed", false);
          } else {
            div.setAttribute("aria-grabbed", true);
          }
        }
      },

      taskRowAttr: function (task, div) {

        this._taskCommonAttr(task, div);

        if (!gantt.isReadonly(task) && this.config.order_branch) {
          div.setAttribute("aria-grabbed", false);
        }

        div.setAttribute("role", "row");

        div.setAttribute("aria-level", task.$level);

        if (gantt.hasChild(task.id)) {
          div.setAttribute("aria-expanded", task.$open ? "true" : "false");
        }
      },

      linkAttr: function (link, div) {

        var linkTypes = this.config.links;

        var toStart = link.type == linkTypes.finish_to_start || link.type == linkTypes.start_to_start;
        var fromStart = link.type == linkTypes.start_to_start || link.type == linkTypes.start_to_finish;

        var content = gantt.locale.labels.link + " " + gantt.templates.drag_link(link.source, fromStart, link.target, toStart);

        div.setAttribute("aria-label", stripHTMLLite(content));
        if (gantt.isReadonly(link)) {
          div.setAttribute("aria-readonly", true);
        }
      },

      gridSeparatorAttr: function (div) {
        div.setAttribute("role", "separator");
      },

      lightboxHiddenAttr: function (div) {
        div.setAttribute("aria-hidden", "true");
      },

      lightboxVisibleAttr: function (div) {
        div.setAttribute("aria-hidden", "false");
      },

      lightboxAttr: function (div) {
        div.setAttribute("role", "dialog");
        div.setAttribute("aria-hidden", "true");
        div.firstChild.setAttribute("role", "heading");
      },

      lightboxButtonAttrString: function (buttonName) {
        return this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels[buttonName], "tabindex": "0" });
      },

      lightboxHeader: function (div, headerText) {
        div.setAttribute("aria-label", headerText);
      },

      lightboxSelectAttrString: function (time_option) {
        var label = "";

        switch (time_option) {
          case "%Y":
            label = gantt.locale.labels.years;
            break;
          case "%m":
            label = gantt.locale.labels.months;
            break;
          case "%d":
            label = gantt.locale.labels.days;
            break;
          case "%H:%i":
            label = gantt.locale.labels.hours + gantt.locale.labels.minutes;
            break;
          default:
            break;
        }

        return gantt._waiAria.getAttributeString({ "aria-label": label });
      },

      lightboxDurationInputAttrString: function (section) {
        return this.getAttributeString({ "aria-label": gantt.locale.labels.column_duration, "aria-valuemin": "0" });
      },

      gridAttrString: function () {
        return [" role='treegrid'", this.config.multiselect ? "aria-multiselectable='true'" : "aria-multiselectable='false'", " "].join(" ");
      },


      gridScaleRowAttrString: function () {
        return "role='row'";
      },

      gridScaleCellAttrString: function (column, label) {
        var attrs = "";
        if (column.name == "add") {
          attrs = this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels.new_task });
        } else {

          var attributes = {
            "role": "columnheader",
            "aria-label": label
          };

          if (gantt._sort && gantt._sort.name == column.name) {
            if (gantt._sort.direction == "asc") {
              attributes["aria-sort"] = "ascending";
            } else {
              attributes["aria-sort"] = "descending";
            }
          }

          attrs = this.getAttributeString(attributes);
        }
        return attrs;
      },

      gridDataAttrString: function () {
        return "role='rowgroup'";
      },

      gridCellAttrString: function (column, textValue) {
        return this.getAttributeString({ "role": "gridcell", "aria-label": textValue });
      },

      gridAddButtonAttrString: function (column) {
        return this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels.new_task });
      },

      messageButtonAttrString: function (buttonLabel) {
        return "tabindex='0' role='button' aria-label='" + buttonLabel + "'";
      },

      messageInfoAttr: function (div) {
        div.setAttribute("role", "alert");
        //div.setAttribute("tabindex", "-1");
      },

      messageModalAttr: function (div, uid) {
        div.setAttribute("role", "dialog");
        if (uid) {
          div.setAttribute("aria-labelledby", uid);
        }

        //	div.setAttribute("tabindex", "-1");
      },

      quickInfoAttr: function (div) {
        div.setAttribute("role", "dialog");
      },

      quickInfoHeaderAttrString: function () {
        return " role='heading' ";
      },

      quickInfoHeader: function (div, header) {
        div.setAttribute("aria-label", header);
      },

      quickInfoButtonAttrString: function (label) {
        return gantt._waiAria.getAttributeString({ "role": "button", "aria-label": label, "tabindex": "0" });
      },

      tooltipAttr: function (div) {
        div.setAttribute("role", "tooltip");
      },

      tooltipVisibleAttr: function (div) {
        div.setAttribute("aria-hidden", "false");
      },

      tooltipHiddenAttr: function (div) {
        div.setAttribute("aria-hidden", "true");
      }
    };

    function isDisabled() {
      return !this.config.wai_aria_attributes;
    }

    for (var i in gantt._waiAria) {
      gantt._waiAria[i] = (function (payload) {
        return function () {
          if (isDisabled()) {
            return "";
          }
          return payload.apply(this, arguments);
        };
      })(gantt._waiAria[i]);
    }


  };

  // message(gantt) {
  //   var utils = this.utilsService;
  //   var domHelpers = this.utilsService;



  //   // return {
  //   //   alert: alertBox,
  //   //   confirm: confirmBox,
  //   //   message: messageBox,
  //   //   modalbox: modalBox
  //   // };
  // };

  // callback(config, result) {
  //   var usercall = config.callback;
  //   this.modalBoxHide(config.box);

  //   this._dhx_msg_cfg = config.box = null;
  //   if (usercall)
  //     usercall(result);
  // }

  // modal_key(e) {
  //   if (this._dhx_msg_cfg) {
  //     e = e || event;
  //     var code = e.which || e.keyCode; // event.keyCode
  //     var preventDefault = false;

  //     if (this.messagebox.keyboard) {
  //       if (code == 13 || code == 32) {
  //         // default behavior is to confirm/submit popup on space/enter
  //         // if browser focus is set on button element - do button click instead of default behavior
  //         var target = e.target || e.srcElement;
  //         if (this.utilsService.getClassName(target).indexOf("gantt_popup_button") > -1 && target.click) {
  //           target.click();
  //         } else {
  //           this.callback(this._dhx_msg_cfg, true);
  //           preventDefault = true;
  //         }
  //       }

  //       if (code == 27) {
  //         this.callback(this._dhx_msg_cfg, false);
  //         preventDefault = true;
  //       }
  //     }

  //     if (preventDefault) {
  //       if (e.preventDefault)
  //         e.preventDefault();
  //       return !(e.cancelBubble = true);
  //     }
  //     return;
  //   }
  // }

  // // gantt.event(document, "keydown", modal_key, true);

  // modality(mode) {
  //   if (!this.modalityObj.cover) {
  //     this.modalityObj.cover = document.createElement("div");
  //     //necessary for IE only
  //     this.modalityObj.cover.onkeydown = this.modal_key;
  //     this.modalityObj.cover.className = "dhx_modal_cover";
  //     document.body.appendChild(this.modalityObj.cover);
  //   }

  //   this.modalityObj.cover.style.display = mode ? "inline-block" : "none";
  // }

  // button(text, className, result) {
  //   var buttonAriaAttrs = gantt._waiAria.messageButtonAttrString(text);
  //   var name = className.toLowerCase().replace(/ /g, "_");
  //   var button_css = "gantt_" + name + "_button" + " dhtmlx_" + name + "_button"; // dhtmlx_ok_button, dhtmlx_click_me_button
  //   return "<div " + buttonAriaAttrs + " class='gantt_popup_button dhtmlx_popup_button " + button_css + "' data-result='" + result + "' result='" + result + "' ><div>" + text + "</div></div>";
  // }

  // messageonclick(text) {
  //   this.messageBoxhide(text.id);
  //   text = null;
  // }

  // info(text) {
  //   if (!this.messagebox.area) {
  //     this.messagebox.area = document.createElement("div");
  //     this.messagebox.area.className = "gantt_message_area dhtmlx_message_area";
  //     this.messagebox.area.style[this.messagebox.position] = "5px";
  //     document.body.appendChild(this.messagebox.area);
  //   }

  //   this.messageBoxhide(text.id);
  //   var message = document.createElement("div");
  //   message.innerHTML = "<div>" + text.text + "</div>";
  //   message.className = "gantt-info dhtmlx-info gantt-" + text.type + " dhtmlx-" + text.type;
  //   this.messageonclick(text);

  //   gantt._waiAria.messageInfoAttr(message);

  //   if (this.messagebox.position == "bottom" && this.messagebox.area.firstChild)
  //     this.messagebox.area.insertBefore(message, this.messagebox.area.firstChild);
  //   else
  //     this.messagebox.area.appendChild(message);

  //   if (text.expire > 0)
  //     this.messagebox.timers[text.id] = window.setTimeout(function () {
  //       this.messagebox.hide(text.id);
  //     }, text.expire);

  //   this.messagebox.pull[text.id] = message;
  //   message = null;

  //   return text.id;
  // }

  // getFirstDefined(...args) {
  //   var values = [].slice.apply(arguments, [0]);

  //   for (var i = 0; i < values.length; i++) {
  //     if (values[i]) {
  //       return values[i];
  //     }
  //   }

  // }

  // _boxStructure(config, ok, cancel) {
  //   var outerThis: CoreService;
  //   var box = document.createElement("div");

  //   var contentId = this.utilsService.uid();
  //   gantt._waiAria.messageModalAttr(box, contentId);


  //   box.className = " gantt_modal_box dhtmlx_modal_box gantt-" + config.type + " dhtmlx-" + config.type;
  //   box.setAttribute(this.boxAttribute, '1');

  //   var inner = '';

  //   if (config.width)
  //     box.style.width = config.width;
  //   if (config.height)
  //     box.style.height = config.height;
  //   if (config.title)
  //     inner += '<div class="gantt_popup_title dhtmlx_popup_title">' + config.title + '</div>';
  //   inner += '<div class="gantt_popup_text dhtmlx_popup_text" id="' + contentId + '"><span>' + (config.content ? '' : config.text) + '</span></div><div  class="gantt_popup_controls dhtmlx_popup_controls">';
  //   if (ok)
  //     inner += this.button(this.getFirstDefined(config.ok, this.localeService.locale.labels.message_ok, "OK"), "ok", true);
  //   if (cancel)
  //     inner += this.button(this.getFirstDefined(config.cancel, this.localeService.locale.labels.message_cancel, "Cancel"), "cancel", false);

  //   if (config.buttons) {
  //     for (var i = 0; i < config.buttons.length; i++) {
  //       var btn = config.buttons[i];
  //       if (typeof btn == "object") {
  //         // Support { label:"Save", css:"main_button", value:"save" }
  //         var label = btn.label;
  //         var css = btn.css || ("gantt_" + btn.label.toLowerCase() + "_button dhtmlx_" + btn.label.toLowerCase() + "_button");
  //         var value = btn.value || i;
  //         inner += this.button(label, css, value);
  //       } else {
  //         inner += this.button(btn, btn, i);
  //       }
  //     }
  //   }

  //   inner += '</div>';
  //   box.innerHTML = inner;

  //   if (config.content) {
  //     var node = config.content;
  //     if (typeof node == "string")
  //       node = document.getElementById(node);
  //     if (node.style.display == 'none')
  //       node.style.display = "";
  //     box.childNodes[config.title ? 1 : 0].appendChild(node);
  //   }

  //   box.onclick = function (e: Event) {
  //     e = e || event;
  //     var source: any = e.target || e.srcElement;
  //     if (!source.className) source = source.parentNode;
  //     if (source.className.split(" ")[0] == "gantt_popup_button") {
  //       var result = source.getAttribute("data-result");
  //       result = (result == "true") || (result == "false" ? false : result);
  //       outerThis.callback(config, result);
  //     }
  //   };
  //   config.box = box;
  //   if (ok || cancel)
  //     this._dhx_msg_cfg = config;

  //   return box;
  // }

  // _createBox(config, ok, cancel) {
  //   var box = config.tagName ? config : this._boxStructure(config, ok, cancel);

  //   if (!config.hidden)
  //     this.modality(true);
  //   document.body.appendChild(box);
  //   var x = Math.abs(Math.floor(((window.innerWidth || document.documentElement.offsetWidth) - box.offsetWidth) / 2));
  //   var y = Math.abs(Math.floor(((window.innerHeight || document.documentElement.offsetHeight) - box.offsetHeight) / 2));
  //   if (config.position == "top")
  //     box.style.top = "-3px";
  //   else
  //     box.style.top = y + 'px';
  //   box.style.left = x + 'px';
  //   //necessary for IE only
  //   box.onkeydown = this.modal_key;

  //   this.modalBoxFocus(box);

  //   if (config.hidden)
  //     this.modalBoxHide(box);

  //   gantt.callEvent("onMessagePopup", [box]);
  //   return box;
  // }

  // alertPopup(config) {
  //   return this._createBox(config, true, false);
  // }

  // confirmPopup(config) {
  //   return this._createBox(config, true, true);
  // }

  // boxPopup(config) {
  //   return this._createBox(config, false, false);
  // }

  // box_params(text, type, callback) {
  //   if (typeof text != "object") {
  //     if (typeof type == "function") {
  //       callback = type;
  //       type = "";
  //     }
  //     text = { text: text, type: type, callback: callback };
  //   }
  //   return text;
  // }

  // params(text, type, expire, id) {
  //   if (typeof text != "object")
  //     text = { text: text, type: type, expire: expire, id: id };
  //   text.id = text.id || this.utilsService.uid();
  //   text.expire = text.expire || this.messagebox.expire;
  //   return text;
  // }

  // alertBox() {
  //   var text = this.box_params.apply(this, arguments);
  //   text.type = text.type || "confirm";
  //   return this.alertPopup(text);
  // }

  // confirmBox() {
  //   var text = this.box_params.apply(this, arguments);
  //   text.type = text.type || "alert";
  //   return this.confirmPopup(text);
  // }
  // modalBox() {
  //   var text = this.box_params.apply(this, arguments);
  //   text.type = text.type || "alert";
  //   return this.boxPopup(text);
  // };

  // modalBoxHide(node) {
  //   while (node && node.getAttribute && !node.getAttribute(this.boxAttribute))
  //     node = node.parentNode;
  //   if (node) {
  //     node.parentNode.removeChild(node);
  //     this.modality(false);

  //     this.utilsService.callEvent("onAfterMessagePopup", [node], undefined);
  //   }
  // };

  // modalBoxFocus(node) {
  //   setTimeout(function () {
  //     var focusable = this.utilsService.getFocusableNodes(node);
  //     if (focusable.length) {
  //       if (focusable[0].focus) focusable[0].focus();
  //     }
  //   }, 1);
  // };

  // messageBox(text, type, expire, id) {
  //   text = this.params.apply(this, arguments);
  //   text.type = text.type || "info";

  //   var subtype = text.type.split("-")[0];
  //   switch (subtype) {
  //     case "alert":
  //       return this.alertPopup(text);
  //     case "confirm":
  //       return this.confirmPopup(text);
  //     case "modalbox":
  //       return this.boxPopup(text);
  //     default:
  //       return this.info(text);
  //   }
  // }

  // messageBoxhideAll() {
  //   for (var key in this.messagebox.pull)
  //     this.messageBoxhide(key);
  // }

  // messageBoxhide(id) {
  //   var obj = this.messagebox.pull[id];
  //   if (obj && obj.parentNode) {
  //     window.setTimeout(function () {
  //       obj.parentNode.removeChild(obj);
  //       obj = null;
  //     }, 2000);
  //     obj.className += " hidden";

  //     if (this.messagebox.timers[id])
  //       window.clearTimeout(this.messagebox.timers[id]);
  //     delete this.messagebox.pull[id];
  //   }
  // }

  // popups = [];
  // gantt.attachEvent("onMessagePopup", function(box) {
  //   this.popups.push(box);
  // });
  // gantt.attachEvent("onAfterMessagePopup", function(box) {
  //   for (var i = 0; i < this.popups.length; i++) {
  //     if (this.popups[i] === box) {
  //       this.popups.splice(i, 1);
  //       i--;
  //     }
  //   }
  // });

  // gantt.attachEvent("onDestroy", function() {
  //   if (this.modalityObj.cover && this.modalityObj.cover.parentNode) {
  //     this.modalityObj.cover.parentNode.removeChild(this.modalityObj.cover);
  //   }

  //   for (var i = 0; i < this.popups.length; i++) {
  //     if (this.popups[i].parentNode) {
  //       this.popups[i].parentNode.removeChild(this.popups[i]);
  //     }
  //   }
  //   this.popups = null;

  //   if (this.messagebox.area && this.messagebox.area.parentNode) {
  //     this.messagebox.area.parentNode.removeChild(this.messagebox.area);
  //   }
  //   this.messagebox = null;
  // });

  refreshData() {
    
  }





}
