import { Injectable } from '@angular/core';
import { UtilsService } from 'src/app/services/utils/utils.service';

@Injectable({
  providedIn: 'root'
})
export class EditorsService {

  constructor(private utilsService: UtilsService) { }

  // base() {

  base(gantt) {

    var BaseEditor = function () {
    };

    BaseEditor.prototype = {
      show: function (id, column, config, placeholder) {
      },
      hide: function () {
      },
      set_value: function (value, id, column, node) {
        this.get_input(node).value = value;
      },
      get_value: function (id, column, node) {
        return this.get_input(node).value || "";
      },
      is_changed: function (value, id, column, node) {
        var currentValue = this.get_value(id, column, node);
        if (currentValue && value && currentValue.valueOf && value.valueOf) {
          return currentValue.valueOf() != value.valueOf();
        } else {
          return currentValue != value;
        }
      },
      is_valid: function (value, id, column, node) {
        return true;
      },

      save: function (id, column, node) {

      },
      get_input: function (node) {
        return node.querySelector("input");
      },
      focus: function (node) {
        var input = this.get_input(node);
        if (!input) {
          return;
        }
        if (input.focus) {
          input.focus();
        }

        if (input.select) {
          input.select();
        }
      }
    };
    return BaseEditor;
  };

  /***/
  // }

  date(outerThis?: EditorsService) {

    return function (gantt) {
      var BaseEditor = outerThis.base(gantt),
        utils = outerThis.utilsService;
      var __extends = outerThis.utilsService.extends();

      var html5DateFormat = "%Y-%m-%d";

      var dateToStr = null;
      var strToDate = null;

      function init() {
        if (!dateToStr) {
          dateToStr = gantt.date.date_to_str(html5DateFormat);
        }
        if (!strToDate) {
          strToDate = gantt.date.str_to_date(html5DateFormat);
        }
      }

      function DateEditor() {
        var self = BaseEditor.apply(this, arguments) || this;

        return self;
      }

      __extends(DateEditor, BaseEditor);

      utils.mixin(DateEditor.prototype, {
        show: function (id, column, config, placeholder) {

          init();
          var minValue = dateToStr(config.min || gantt.getState().min_date);
          var maxValue = dateToStr(config.max || gantt.getState().max_date);

          var html = "<div style='width:140px'><input type='date' min='" + minValue + "' max='" + maxValue + "' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        },
        set_value: function (value, id, column, node) {
          if (value && value.getFullYear) {
            this.get_input(node).value = dateToStr(value);
          } else {
            this.get_input(node).value = value;
          }
        },
        is_valid: function (value, id, column, node) {
          if (!value || isNaN(value.getTime()))
            return false;
          return true;
        },
        get_value: function (id, column, node) {
          var parsed;
          try {
            parsed = strToDate(this.get_input(node).value || "");
          } catch (e) {
            parsed = null;// return null will cancel changes
          }

          return parsed;
        }
      }, true);

      return DateEditor;
    };


    /***/
  }

  number(outerThis?: EditorsService) {

    return function (gantt) {

      var BaseEditor = outerThis.base(gantt),
        utils = outerThis.utilsService;
      var __extends = outerThis.utilsService.extends();

      function NumberEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(NumberEditor, BaseEditor);

      utils.mixin(NumberEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var min = config.min || 0,
            max = config.max || 100;

          var html = "<div><input type='number' min='" + min + "' max='" + max + "' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        },
        get_value: function (id, column, node) {
          return this.get_input(node).value || "";
        },
        is_valid: function (value, id, column, node) {
          return !isNaN(parseInt(value, 10));
        }
      }, true);

      return NumberEditor;
    };

    /***/
  }

  predecessor(outerThis?: EditorsService) {

    return function (gantt) {

      var BaseEditor = outerThis.base(gantt),
        utils = outerThis.utilsService;
      var __extends = outerThis.utilsService.extends();

      function PredecessorEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(PredecessorEditor, BaseEditor);

      function parseInputString(value, config) {
        var predecessors = (value || "").split(config.delimiter || ",");
        for (var i = 0; i < predecessors.length; i++) {
          var val = predecessors[i].trim();
          if (val) {
            predecessors[i] = val;
          } else {
            predecessors.splice(i, 1);
            i--;
          }
        }
        predecessors.sort();
        return predecessors;
      }

      function formatPredecessors(task, config, gantt) {
        var links = task.$target;
        var labels = [];
        for (var i = 0; i < links.length; i++) {
          var link = gantt.getLink(links[i]);
          var pred = gantt.getTask(link.source);
          labels.push(gantt.getWBSCode(pred));
        }
        return labels.join((config.delimiter || ",") + " ");
      }

      function getSelectedLinks(taskId, predecessorCodes) {
        var links = [];
        predecessorCodes.forEach(function (code) {
          var predecessor = gantt.getTaskByWBSCode(code);
          if (predecessor) {
            var link = {
              source: predecessor.id,
              target: taskId,
              type: gantt.config.links.finish_to_start,
              lag: 0
            };
            if (gantt.isLinkAllowed(link)) {
              links.push(link);
            }
          }
        });
        return links;
      }

      function getLinksDiff(task, predecessorCodes) {
        var selectedLinks = getSelectedLinks(task.id, predecessorCodes);
        var existingLinksSearch = {};
        task.$target.forEach(function (linkId) {
          var link = gantt.getLink(linkId);
          existingLinksSearch[link.source + "_" + link.target] = link.id;
        });

        var linksToAdd = [];
        selectedLinks.forEach(function (link) {
          var linkKey = link.source + "_" + link.target;
          if (!existingLinksSearch[linkKey]) {
            linksToAdd.push(link);
          } else {
            delete existingLinksSearch[linkKey];
          }
        });

        var linksToDelete = [];
        for (var i in existingLinksSearch) {
          linksToDelete.push(existingLinksSearch[i]);
        }

        return {
          add: linksToAdd,
          remove: linksToDelete
        };
      }

      utils.mixin(PredecessorEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var html = "<div><input type='text' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        },
        hide: function () {
        },
        set_value: function (value, id, column, node) {
          this.get_input(node).value = formatPredecessors(value, column.editor, gantt);
        },
        get_value: function (id, column, node) {
          return parseInputString((this.get_input(node).value || ""), column.editor);
        },
        save: function (id, column, node) {
          var task = gantt.getTask(id);

          var linksDiff = getLinksDiff(task, this.get_value(id, column, node));

          if (linksDiff.add.length || linksDiff.remove.length) {
            gantt.batchUpdate(function () {
              linksDiff.add.forEach(function (link) {
                gantt.addLink(link);
              });
              linksDiff.remove.forEach(function (linkId) {
                gantt.deleteLink(linkId);
              });

              if (gantt.autoSchedule)
                gantt.autoSchedule();
            });
          }
        },
        is_changed: function (value, id, column, node) {
          var inputPredecessors = this.get_value(id, column, node);
          var taskPredecessors = parseInputString(formatPredecessors(value, column.editor, gantt), column.editor);

          return inputPredecessors.join() !== taskPredecessors.join();
        }
      }, true);

      return PredecessorEditor;
    };

    /***/
  }

  select(outerThis?: EditorsService) {

    return function (gantt) {
      var BaseEditor = outerThis.base(gantt),
        utils = outerThis.utilsService;
      var __extends = outerThis.utilsService.extends();

      function SelectEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(SelectEditor, BaseEditor);

      utils.mixin(SelectEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var html = "<div><select name='" + column.name + "'>";
          var optionsHtml = [],
            options = config.options || [];

          for (var i = 0; i < options.length; i++) {
            optionsHtml.push("<option value='" + config.options[i].key + "'>" + options[i].label + "</option>");
          }

          html += optionsHtml.join("") + "</select></div>";
          placeholder.innerHTML = html;
        },
        get_input: function (node) {
          return node.querySelector("select");
        }
      }, true);

      return SelectEditor;
    };

    /***/
  }

  text(outerThis?: EditorsService) {

    return function (gantt) {

      var BaseEditor = outerThis.base(gantt),
        utils = outerThis.utilsService;
      var __extends = outerThis.utilsService.extends();

      function TextEditor() {
        var self = BaseEditor.apply(this, arguments) || this;
        return self;
      }

      __extends(TextEditor, BaseEditor);

      utils.mixin(TextEditor.prototype, {
        show: function (id, column, config, placeholder) {
          var html = "<div><input type='text' name='" + column.name + "'></div>";
          placeholder.innerHTML = html;
        }
      }, true);

      return TextEditor;
    };

    /***/
  }
}
