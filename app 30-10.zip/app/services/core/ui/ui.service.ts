import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import { RenderService } from './render/render.service';
import { LayoutService , Cell , Layout} from './layout/layout.service';
import { TimelineService } from './timeline/timeline.service';
import { GridService, Grid } from './grid/grid.service';
import { GridEditorsService } from './grid/editors/grideditors.service';
import { CommonService } from '../common/common.service';
import { utils } from 'gantt';

@Injectable({
  providedIn: 'root'
})
export class UiService {
  eventHandlers = {
    "click": {},
    "doubleclick": {},
    "contextMenu": {}
  };
  constructor(private utilsService: UtilsService, private renderService: RenderService, private layoutService: LayoutService, private timelineService: TimelineService,
    private gridService: GridService, private gridEditorService: GridEditorsService, private commonService: CommonService) { }

  configurable(obj, parent) {
    utils.mixin(obj, new Configurable(parent));
  }

  ganttLayers() {

    var createLayerFactory = this.renderService.layerEngine();

    var createLayerEngine = function (gantt) {
      var factory = createLayerFactory(gantt);
      return {
        getDataRender: function (name) {
          return gantt.$services.getService("layer:" + name) || null;
        },
        createDataRender: function (config) {
          var name = config.name,
            defaultContainer = config.defaultContainer,
            previusSiblingContainer = config.defaultContainerSibling;

          var layers = factory.createGroup(
            defaultContainer,
            previusSiblingContainer,
            function (itemId, item) {
              if (layers.filters) {
                for (var i = 0; i < layers.filters.length; i++) {
                  if (layers.filters[i](itemId, item) === false) {
                    return false;
                  }
                }
              } else {
                return true;
              }
            }
          );

          gantt.$services.setService("layer:" + name, function () {
            return layers;
          });

          gantt.attachEvent("onGanttReady", function () {
            layers.addLayer(); // init layers on start
          });

          return layers;
        },
        init: function () {
          var taskLayers = this.createDataRender({
            name: "task",
            defaultContainer: function () {
              if (gantt.$task_data) {
                return gantt.$task_data;
              } else if (gantt.$ui.getView("timeline")) {
                return gantt.$ui.getView("timeline").$task_data;
              }
            },
            defaultContainerSibling: function () {
              if (gantt.$task_links) {
                return gantt.$task_links;
              } else if (gantt.$ui.getView("timeline")) {
                return gantt.$ui.getView("timeline").$task_links;
              }
            },
            filter: function (item) {

            }
          }, gantt);

          var linkLayers = this.createDataRender({
            name: "link",
            defaultContainer: function () {
              if (gantt.$task_data) {
                return gantt.$task_data;
              } else if (gantt.$ui.getView("timeline")) {
                return gantt.$ui.getView("timeline").$task_data;
              }
            }
          }, gantt);

          return {
            addTaskLayer: function (config) {
              return taskLayers.addLayer(config);
            },

            /*getTaskLayer: function(id){
              return taskLayers.getLayer(id);
            },*/

            _getTaskLayers: function () {
              return taskLayers.getLayers();
            },
            removeTaskLayer: function (id) {
              taskLayers.removeLayer(id);
            },
            /*eachTaskLayer: function(code){
              taskLayers.eachLayer(code);
            },*/
            _clearTaskLayers: function () {
              taskLayers.clear();
            },
            addLinkLayer: function (config) {
              return linkLayers.addLayer(config);
            },
            /*getLinkLayer: function(id){
              return linkLayers.getLayer(id);
            },*/
            _getLinkLayers: function () {
              return linkLayers.getLayers();
            },
            removeLinkLayer: function (id) {
              linkLayers.removeLayer(id);
            },
            /*eachLinkLayer: function(code){
              linkLayers.eachLayer(code);
            },*/
            _clearLinkLayers: function () {
              linkLayers.clear();
            }
          };
        }
      };
    };

    return createLayerEngine;

    /***/
  }

  index() {

    var uiFactory = this.uiFactory(),
      mouseEvents = this.mouse(),
      createLayers = this.ganttLayers(),
      cell = Cell,
      layout = Layout,
      ViewLayout = this.layoutService.viewLayout(),
      ViewCell = this.layoutService.viewCell(),
      Resizer = this.layoutService.resizerCell(),
      Scrollbar = this.layoutService.scrollbarCell(),
      Timeline = this.timelineService.timeline(),
      grid = Grid,
      ResourceGrid = Grid,
      ResourceTimeline = this.timelineService.timeline(),
      ResourceHistogram = this.timelineService.timeline();


    var gridEditorsFactory = this.gridEditorService.controller();


    var renderTaskBar = this.renderService.taskBarSmartRender(),
      renderSplitTaskBar = this.renderService.taskSplitRender(),
      renderTaskBg = this.renderService.taskBgRender(),
      renderLink = this.renderService.linkRender(),
      gridRenderer = this.renderService.taskGridLineRender();

    var mainGridInitializer = this.gridService.mainGridInitializer();
    var mainTimelineInitializer = this.timelineService.mainTimelineInitializer();
    var mainLayoutInitializer = this.main_layoutInitializer();

    function initUI(gantt) {
      function attachInitializer(view, initializer) {
        var ext = initializer(gantt);
        if (ext.onCreated)
          ext.onCreated(view);
        view.attachEvent("onReady", function () {
          if (ext.onInitialized)
            ext.onInitialized(view);
        });
        view.attachEvent("onDestroy", function () {
          if (ext.onDestroyed)
            ext.onDestroyed(view);
        });
      }

      var factory = uiFactory.createFactory(gantt);
      factory.registerView("cell", Cell);
      factory.registerView("resizer", Resizer);
      factory.registerView("scrollbar", Scrollbar);
      factory.registerView("layout", Layout, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "main") {
          attachInitializer(view, mainLayoutInitializer);
        }
      });
      factory.registerView("viewcell", ViewCell);
      factory.registerView("multiview", ViewLayout);
      factory.registerView("timeline", Timeline, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "timeline" || view.$config.bind == "task") {
          attachInitializer(view, mainTimelineInitializer);
        }
      });
      factory.registerView("grid", grid, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "grid" || view.$config.bind == "task") {
          attachInitializer(view, mainGridInitializer);
        }
      });

      factory.registerView("resourceGrid", ResourceGrid);
      factory.registerView("resourceTimeline", ResourceTimeline);
      factory.registerView("resourceHistogram", ResourceHistogram);

      var layersEngine = createLayers(gantt);

      var inlineEditors = gridEditorsFactory(gantt);

      gantt.ext.inlineEditors = inlineEditors;
      gantt.ext._inlineEditors = inlineEditors;
      inlineEditors.init(gantt);

      return {
        factory: factory,
        mouseEvents: mouseEvents.init(gantt),
        layersApi: layersEngine.init(),
        render: {
          gridLine: function () {
            return gridRenderer(gantt);
          },
          taskBg: function () {
            return renderTaskBg(gantt);
          },
          taskBar: function () {
            return renderTaskBar(gantt);
          },
          taskSplitBar: function () {
            return renderSplitTaskBar(gantt);
          },
          link: function () {
            return renderLink(gantt);
          }
        },
        layersService: {
          getDataRender: function (name) {
            // return layersEngine.getDataRender(name, gantt);
            return layersEngine.getDataRender(name);
          },
          createDataRender: function (config) {
            // return layersEngine.createDataRender(config, gantt);
            return layersEngine.createDataRender(config);

          }
        }
      };
    }

    return {
      init: initUI
    };

    /***/
  }

  main_layoutInitializer() {

    var domHelpers = this.utilsService;

    var initializer = (function () {
      return function (gantt) {
        return {

          getVerticalScrollbar: function () {
            return gantt.$ui.getView("scrollVer");
          },
          getHorizontalScrollbar: function () {
            return gantt.$ui.getView("scrollHor");
          },

          _legacyGridResizerClass: function (layout) {
            var resizers = layout.getCellsByType("resizer");
            for (var i = 0; i < resizers.length; i++) {
              var r = resizers[i];
              var gridResizer = false;

              var prev = r.$parent.getPrevSibling(r.$id);
              if (prev && prev.$config && prev.$config.id === "grid") {
                gridResizer = true;
              } else {
                var next = r.$parent.getNextSibling(r.$id);
                if (next && next.$config && next.$config.id === "grid") {
                  gridResizer = true;
                }
              }

              if (gridResizer) {
                r.$config.css = (r.$config.css ? r.$config.css + " " : "") + "gantt_grid_resize_wrap";
              }
            }
          },

          onCreated: function (layout) {
            var first = true;

            this._legacyGridResizerClass(layout);

            layout.attachEvent("onBeforeResize", function () {
              var mainTimeline = gantt.$ui.getView("timeline");
              if (mainTimeline)
                mainTimeline.$config.hidden = mainTimeline.$parent.$config.hidden = !gantt.config.show_chart;

              var mainGrid = gantt.$ui.getView("grid");

              if (!mainGrid)
                return;

              var showGrid = gantt.config.show_grid;
              if (first) {
                var colsWidth = mainGrid._getColsTotalWidth();
                if (colsWidth !== false) {
                  gantt.config.grid_width = colsWidth;
                }
                showGrid = showGrid && !!gantt.config.grid_width;
                gantt.config.show_grid = showGrid;
              }
              mainGrid.$config.hidden = mainGrid.$parent.$config.hidden = !showGrid;

              if (!mainGrid.$config.hidden) {
                /* restrict grid width due to min_width, max_width, min_grid_column_width */
                var grid_limits = mainGrid._getGridWidthLimits();
                if (grid_limits[0] && gantt.config.grid_width < grid_limits[0])
                  gantt.config.grid_width = grid_limits[0];
                if (grid_limits[1] && gantt.config.grid_width > grid_limits[1])
                  gantt.config.grid_width = grid_limits[1];
                if (mainTimeline && gantt.config.show_chart) {

                  mainGrid.$config.width = gantt.config.grid_width - 1;
                  if (!first) {
                    if (mainTimeline && !domHelpers.isChildOf(mainTimeline.$task, layout.$view)) {
                      // timeline is being displayed after being not visible, reset grid with from full screen
                      if (!mainGrid.$config.original_grid_width) {
                        var skinSettings = gantt.skins[gantt.skin];
                        if (skinSettings && skinSettings.config && skinSettings.config.grid_width) {
                          mainGrid.$config.original_grid_width = skinSettings.config.grid_width;
                        } else {
                          mainGrid.$config.original_grid_width = 0;
                        }
                      }
                      gantt.config.grid_width = mainGrid.$config.original_grid_width;
                      mainGrid.$parent.$config.width = gantt.config.grid_width;
                    } else {
                      mainGrid.$parent._setContentSize(mainGrid.$config.width, mainGrid.$config.height);
                      gantt.$layout._syncCellSizes(mainGrid.$parent.$config.group, gantt.config.grid_width);
                    }
                  } else {
                    mainGrid.$parent.$config.width = gantt.config.grid_width;
                    if (mainGrid.$parent.$config.group) {
                      gantt.$layout._syncCellSizes(mainGrid.$parent.$config.group, mainGrid.$parent.$config.width);
                    }
                  }
                } else {
                  if (mainTimeline && domHelpers.isChildOf(mainTimeline.$task, layout.$view)) {
                    // hiding timeline, remember grid with to restore it when timeline is displayed again
                    mainGrid.$config.original_grid_width = gantt.config.grid_width;
                  }
                  if (!first) {
                    mainGrid.$parent.$config.width = 0;
                  }
                }
              }

              first = false;
            });
            this._initScrollStateEvents(layout);
          },

          _initScrollStateEvents: function (layout) {
            gantt._getVerticalScrollbar = this.getVerticalScrollbar;
            gantt._getHorizontalScrollbar = this.getHorizontalScrollbar;

            var vertical = this.getVerticalScrollbar();
            var horizontal = this.getHorizontalScrollbar();
            if (vertical) {
              vertical.attachEvent("onScroll", function (oldPos, newPos, dir) {
                var scrollState = gantt.getScrollState();
                gantt.callEvent("onGanttScroll", [scrollState.x, oldPos, scrollState.x, newPos]);
              });
            }
            if (horizontal) {
              horizontal.attachEvent("onScroll", function (oldPos, newPos, dir) {
                var scrollState = gantt.getScrollState();
                gantt.callEvent("onGanttScroll", [oldPos, scrollState.y, newPos, scrollState.y]);
              });
            }

            layout.attachEvent("onResize", function () {
              if (vertical && !gantt.$scroll_ver) {
                gantt.$scroll_ver = vertical.$scroll_ver;
              }

              if (horizontal && !gantt.$scroll_hor) {
                gantt.$scroll_hor = horizontal.$scroll_hor;
              }
            });
          },

          _findGridResizer: function (layout, grid) {
            var resizers = layout.getCellsByType("resizer");

            var gridFirst = true;
            var gridResizer;
            for (var i = 0; i < resizers.length; i++) {
              var res = resizers[i];
              res._getSiblings();
              var prev = res._behind;
              var next = res._front;
              if (prev && prev.$content === grid || (prev.isChild && prev.isChild(grid))) {
                gridResizer = res;
                gridFirst = true;
                break;
              } else if (next && next.$content === grid || (next.isChild && next.isChild(grid))) {
                gridResizer = res;
                gridFirst = false;
                break;
              }
            }
            return {
              resizer: gridResizer,
              gridFirst: gridFirst
            };
          },

          onInitialized: function (layout) {
            var grid = gantt.$ui.getView("grid");

            var resizeInfo = this._findGridResizer(layout, grid);

            // expose grid resize events
            if (resizeInfo.resizer) {
              var gridFirst = resizeInfo.gridFirst,
                next = resizeInfo.resizer;
              var initialWidth;
              next.attachEvent("onResizeStart", function (prevCellWidth, nextCellWidth) {

                var grid = gantt.$ui.getView("grid");
                var viewCell = grid ? grid.$parent : null;
                if (viewCell) {
                  var limits = grid._getGridWidthLimits();

                  // min grid width is defined by min widths of its columns, unless grid has horizontal scroll
                  if (!grid.$config.scrollable)
                    viewCell.$config.minWidth = limits[0];

                  viewCell.$config.maxWidth = limits[1];
                }
                initialWidth = gridFirst ? prevCellWidth : nextCellWidth;
                return gantt.callEvent("onGridResizeStart", [initialWidth]);
              });
              next.attachEvent("onResize", function (newBehindSize, newFrontSize) {
                var newSize = gridFirst ? newBehindSize : newFrontSize;
                return gantt.callEvent("onGridResize", [initialWidth, newSize]);
              });
              next.attachEvent("onResizeEnd", function (oldBackSize, oldFrontSize, newBackSize, newFrontSize) {

                var oldSize = gridFirst ? oldBackSize : oldFrontSize;
                var newSize = gridFirst ? newBackSize : newFrontSize;
                var grid = gantt.$ui.getView("grid");
                var viewCell = grid ? grid.$parent : null;
                if (viewCell) {
                  viewCell.$config.minWidth = undefined;
                }
                var res = gantt.callEvent("onGridResizeEnd", [oldSize, newSize]);
                if (res) {
                  gantt.config.grid_width = newSize;
                }

                return res;
              });
            }

          },
          onDestroyed: function (timeline) {

          }
        };

      };
    })();

    return initializer;

    /***/
  }



  domHelpers = this.utilsService;

  addEventTarget(event, className, handler, root) {
    if (!this.eventHandlers[event][className]) {
      this.eventHandlers[event][className] = [];
    }

    this.eventHandlers[event][className].push({
      handler: handler,
      root: root
    });
  }

  callHandler(eventName, className, root, args) {
    var handlers = this.eventHandlers[eventName][className];
    if (handlers) {
      for (var i = 0; i < handlers.length; i++) {
        if (!(root || handlers[i].root) || handlers[i].root === root) {
          handlers[i].handler.apply(this, args);
        }
      }
    }
  }

  onClick(e) {
    e = e || window.event;
    var id = gantt.locate(e);

    var handlers = this.findEventHandlers(e, this.eventHandlers.click);
    var res = true;
    if (id !== null) {
      res = !gantt.checkEvent("onTaskClick") || gantt.callEvent("onTaskClick", [id, e]);
    } else {
      gantt.callEvent("onEmptyClick", [e]);
    }

    if (res) {
      var default_action = this.callEventHandlers(handlers, e, id);
      if (!default_action)
        return;

      if (id && gantt.getTask(id) && gantt.config.select_task && !gantt.config.multiselect) {
        gantt.selectTask(id);
      }
    }
  }

  onContextMenu(e) {
    e = e || window.event;
    var linkAttribute: any = this.commonService.config()

    // tslint:disable-next-line: one-variable-per-declaration
    let src = e.target || e.srcElement;
    let taskId = gantt.locate(src);
    let linkId = this.utilsService.locateAttribute(src, 'link_id');

    var res = !gantt.checkEvent("onContextMenu") || this.utilsService.callEvent("onContextMenu", [taskId, linkId, e], undefined);
    if (!res) {
      if (e.preventDefault)
        e.preventDefault();
      else
        e.returnValue = false;
    }
    return res;
  }

  findEventHandlers(e, hash) {
    var trg = e.target || e.srcElement;
    var handlers = [];
    while (trg) {
      var css = this.utilsService.getClassName(trg);
      if (css) {
        css = css.split(" ");
        for (var i = 0; i < css.length; i++) {
          if (!css[i]) continue;
          if (hash[css[i]]) {
            var delegateHandlers = hash[css[i]];

            for (var h = 0; h < delegateHandlers.length; h++) {
              if (delegateHandlers[h].root) {
                if (!this.utilsService.isChildOf(trg, delegateHandlers[h].root)) {
                  continue;
                }
              }
              handlers.push(delegateHandlers[h].handler);
            }
          }
        }
      }
      trg = trg.parentNode;
    }
    return handlers;
  }

  callEventHandlers(handlers, e, id) {
    var res = true;

    for (var i = 0; i < handlers.length; i++) {
      var handlerResult = handlers[i].call(gantt, e, id, e.target || e.srcElement);
      res = res && !(typeof handlerResult != "undefined" && handlerResult !== true);
    }

    return res;
  }


  onDoubleClick(e) {
    e = e || window.event;
    var id = gantt.locate(e);

    var handlers = this.findEventHandlers(e, this.eventHandlers.doubleclick);
    // when doubleclick fired not on task, id === null
    var res = !gantt.checkEvent("onTaskDblClick") || id === null || gantt.callEvent("onTaskDblClick", [id, e]);
    if (res) {
      var default_action = this.callEventHandlers(handlers, e, id);
      if (!default_action)
        return;

      if (id !== null && gantt.getTask(id)) {
        if (res && gantt.config.details_on_dblclick) {
          gantt.showLightbox(id);
        }
      }
    }
  }

  onMouseMove(e) {
    if (gantt.checkEvent("onMouseMove")) {
      var id = gantt.locate(e);
      this.commonService.config()._last_move_event = e;
      gantt.callEvent("onMouseMove", [id, e]);
    }
  }

  detach(eventName, className, handler, root) {
    if (this.eventHandlers[eventName] && this.eventHandlers[eventName][className]) {
      var handlers = this.eventHandlers[eventName];
      var elementHandlers = handlers[className];
      for (var i = 0; i < elementHandlers.length; i++) {
        if (elementHandlers[i].root == root) {
          elementHandlers.splice(i, 1);
          i--;
        }
      }
      if (!elementHandlers.length) {
        delete handlers[className];
      }

    }
  }


  reset(node?) {
    var domEvents: any = this.utilsService.extend();

    domEvents.detachAll();

    if (node) {
      domEvents.attach(node, "click", this.onClick);
      domEvents.attach(node, "dblclick", this.onDoubleClick);
      domEvents.attach(node, "mousemove", this.onMouseMove);
      domEvents.attach(node, "contextmenu", this.onContextMenu);
    }
  }



  mouse() {

    var domHelpers = this.utilsService;


    var createMouseHandler = (function (domHelpers) {
      return function (gantt) {
        var eventHandlers = {
          "click": {},
          "doubleclick": {},
          "contextMenu": {}
        };

        function addEventTarget(event, className, handler, root) {
          if (!eventHandlers[event][className]) {
            eventHandlers[event][className] = [];
          }

          eventHandlers[event][className].push({
            handler: handler,
            root: root
          });
        }

        function callHandler(eventName, className, root, args) {
          var handlers = eventHandlers[eventName][className];
          if (handlers) {
            for (var i = 0; i < handlers.length; i++) {
              if (!(root || handlers[i].root) || handlers[i].root === root) {
                handlers[i].handler.apply(this, args);
              }
            }
          }
        }

        function onClick(e) {
          e = e || window.event;
          var id = gantt.locate(e);

          var handlers = findEventHandlers(e, eventHandlers.click);
          var res = true;
          if (id !== null) {
            res = !gantt.checkEvent("onTaskClick") || gantt.callEvent("onTaskClick", [id, e]);
          } else {
            gantt.callEvent("onEmptyClick", [e]);
          }

          if (res) {
            var default_action = callEventHandlers(handlers, e, id);
            if (!default_action)
              return;

            if (id && gantt.getTask(id) && gantt.config.select_task && !gantt.config.multiselect) {
              gantt.selectTask(id);
            }
          }
        }

        function onContextMenu(e) {
          e = e || window.event;
          var src = e.target || e.srcElement,
            taskId = gantt.locate(src),
            linkId = gantt.locate(src, gantt.config.link_attribute);

          var res = !gantt.checkEvent("onContextMenu") || gantt.callEvent("onContextMenu", [taskId, linkId, e]);
          if (!res) {
            if (e.preventDefault)
              e.preventDefault();
            else
              e.returnValue = false;
          }
          return res;
        }

        function findEventHandlers(e, hash) {
          var trg = e.target || e.srcElement;
          var handlers = [];
          while (trg) {
            var css = domHelpers.getClassName(trg);
            if (css) {
              css = css.split(" ");
              for (var i = 0; i < css.length; i++) {
                if (!css[i]) continue;
                if (hash[css[i]]) {
                  var delegateHandlers = hash[css[i]];

                  for (var h = 0; h < delegateHandlers.length; h++) {
                    if (delegateHandlers[h].root) {
                      if (!domHelpers.isChildOf(trg, delegateHandlers[h].root)) {
                        continue;
                      }
                    }
                    handlers.push(delegateHandlers[h].handler);
                  }
                }
              }
            }
            trg = trg.parentNode;
          }
          return handlers;
        }

        function callEventHandlers(handlers, e, id) {
          var res = true;

          for (var i = 0; i < handlers.length; i++) {
            var handlerResult = handlers[i].call(gantt, e, id, e.target || e.srcElement);
            res = res && !(typeof handlerResult != "undefined" && handlerResult !== true);
          }

          return res;
        }


        function onDoubleClick(e) {
          e = e || window.event;
          var id = gantt.locate(e);

          var handlers = findEventHandlers(e, eventHandlers.doubleclick);
          // when doubleclick fired not on task, id === null
          var res = !gantt.checkEvent("onTaskDblClick") || id === null || gantt.callEvent("onTaskDblClick", [id, e]);
          if (res) {
            var default_action = callEventHandlers(handlers, e, id);
            if (!default_action)
              return;

            if (id !== null && gantt.getTask(id)) {
              if (res && gantt.config.details_on_dblclick) {
                gantt.showLightbox(id);
              }
            }
          }
        }

        function onMouseMove(e) {
          if (gantt.checkEvent("onMouseMove")) {
            var id = gantt.locate(e);
            gantt._last_move_event = e;
            gantt.callEvent("onMouseMove", [id, e]);
          }
        }

        function detach(eventName, className, handler, root) {
          if (eventHandlers[eventName] && eventHandlers[eventName][className]) {
            var handlers = eventHandlers[eventName];
            var elementHandlers = handlers[className];
            for (var i = 0; i < elementHandlers.length; i++) {
              if (elementHandlers[i].root == root) {
                elementHandlers.splice(i, 1);
                i--;
              }
            }
            if (!elementHandlers.length) {
              delete handlers[className];
            }

          }
        }

        var domEvents = gantt._createDomEventScope();

        function reset(node?) {

          domEvents.detachAll();

          if (node) {
            domEvents.attach(node, "click", onClick);
            domEvents.attach(node, "dblclick", onDoubleClick);
            domEvents.attach(node, "mousemove", onMouseMove);
            domEvents.attach(node, "contextmenu", onContextMenu);
          }
        }



        return {
          reset: reset,
          global: function (event, classname, handler) {
            addEventTarget(event, classname, handler, null);
          },
          delegate: addEventTarget,
          detach: detach,
          callHandler: callHandler,
          onDoubleClick: onDoubleClick,
          onMouseMove: onMouseMove,
          onContextMenu: onContextMenu,
          onClick: onClick,
          destructor: function () {
            reset();
            eventHandlers = null;
            domEvents = null;
          }

        };
      };

    })(domHelpers);


    return {
      init: createMouseHandler
    };

    /***/
  }

  // mouseEventContainer() {

  mouseEventContainer(gantt) {
    var events = [];

    return {
      delegate: function (event, className, handler, root) {
        events.push([event, className, handler, root]);

        var helper = gantt.$services.getService("mouseEvents");
        helper.delegate(event, className, handler, root);
      },
      destructor: function () {
        var mouseEvents = gantt.$services.getService("mouseEvents");
        for (var i = 0; i < events.length; i++) {
          var h = events[i];
          mouseEvents.detach(h[0], h[1], h[2], h[3]);
        }
        events = [];
      }
    };
  }

  // return create;

  /***/
  // }

  rowPositionMixin() {

    function createMixin() {
      var topCache = {};
      return {
        _resetTopPositionHeight: function () {
          topCache = {};
        },

        /**
         * Get top coordinate by row index (order)
         * @param {number} index
         */
        getRowTop: function (index) {
          return index * this.$getConfig().row_height;
        },

        /**
         * Get top coordinate by item id
         * @param {*} task_id
         */
        getItemTop: function (taskId) {
          if (this.$config.rowStore) {
            if (topCache[taskId] !== undefined) {
              return topCache[taskId];
            }
            var store = this.$config.rowStore;
            if (!store) return 0;

            var itemIndex = store.getIndexById(taskId);

            if (itemIndex === -1 && store.getParent && store.exists(taskId)) {
              var parentId = store.getParent(taskId);
              if (store.exists(parentId)) {
                // if task is not found in list - maybe it's parent is a split task and we should use parents index instead
                var parent = store.getItem(parentId);
                if (this.$gantt.isSplitTask(parent)) {
                  return this.getRowTop(store.getIndexById(parent.id));
                }
              }
            }
            topCache[taskId] = this.getRowTop(itemIndex);
            return topCache[taskId];
          } else {
            return 0;
          }

        }
      };
    }

    return createMixin;

    /***/
  }

  uiFactory() {

    var utils = this.utilsService

    var uiFactory = function createFactory(gantt) {
      var views = {};

      function ui(cell, parentView) {
        var content;
        var view = "cell";
        if (cell.view) {
          view = "viewcell";
        } else if (cell.resizer) {
          view = "resizer";
        }
        else if (cell.rows || cell.cols) {
          view = "layout";
        }
        else if (cell.views) {
          view = "multiview";
        }

        content = createView.call(this, view, null, cell, parentView);
        return content;
      }

      var createdViews = {};

      function createView(name, parent, config, parentView) {
        var creator = views[name];

        if (!creator || !creator.create)
          return false;

        if (name == "resizer" && !config.mode) {
          if (parentView.$config.cols) {
            config.mode = "x";
          } else {
            config.mode = "y";
          }
        }

        if (name == "viewcell" && config.view == "scrollbar" && !config.scroll) {
          if (parentView.$config.cols) {
            config.scroll = "y";
          } else {
            config.scroll = "x";
          }
        }

        var config = utils.copy(config);

        if (!config.id && !createdViews[config.view]) {
          config.id = config.view;
        }

        if (config.id && !config.css) {
          config.css = config.id + "_cell";
        }

        var view = new creator.create(parent, config, this, gantt);

        if (creator.configure) {
          creator.configure(view);
        }

        this.configurable(view, parentView);
        if (!view.$id) {
          view.$id = config.id || gantt.uid();
        }

        if (!view.$parent && typeof parent == "object") {
          view.$parent = parent;
        }
        if (!view.$config) {
          view.$config = config;
        }

        if (createdViews[view.$id]) {
          view.$id = gantt.uid();
        }

        createdViews[view.$id] = view;

        return view;
      }

      function reset() {
        createdViews = {};
      }

      function register(name, viewConstructor, configure?) {
        views[name] = { create: viewConstructor, configure: configure };
      }

      function getView(id) {
        return createdViews[id];
      }

      var factory = {
        initUI: ui,
        reset: reset,
        registerView: register,
        createView: createView,
        getView: getView
      };

      return factory;
    };

    return {
      createFactory: uiFactory
    };



    /***/
  }
}

export class Configurable {

  utils: UtilsService;
  parentConfig;
  parentTemplates;
  $gantt: any;
  $config: any;

  constructor(parentView?) {
    this.$getConfig(parentView);
    this.$getTemplates(parentView);
  }

  $getConfig(parentView?) {
    if (!this.parentConfig) {
      this.parentConfig = parentView ? parentView.$getConfig() : this.$gantt.config;
    }
    if (!this.$config.config) {
      return this.parentConfig;
    } else {
      return extendSettings.call(this, "config", this.parentConfig);
    }
  }

  $getTemplates(parentView?) {
    if (!this.parentTemplates) {
      this.parentTemplates = parentView ? parentView.$getTemplates() : this.$gantt.templates;
    }
    if (!this.$config.templates) {
      return this.parentTemplates;
    } else {
      return extendSettings.call(this, "templates", this.parentTemplates);
    }
  }

}

export class ViewSettings {
  utils: UtilsService;

  constructor(config) {
    this.utils.mixin(this, config, true);
  }
}

export class extendSettings {
  $config: any;

  constructor(store, parentSettings) {
    var own = this.$config[store];

    if (own) {
      if (own instanceof ViewSettings) {
        // tslint:disable-next-line: no-unused-expression
        // return own;
        own;
      } else {
        ViewSettings.prototype = parentSettings;
        this.$config[store] = new ViewSettings(own);
        return this.$config[store];
      }
    } else {
      return parentSettings;
    }
  }
}
