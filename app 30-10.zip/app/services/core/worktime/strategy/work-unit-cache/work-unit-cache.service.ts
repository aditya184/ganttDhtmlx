import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WorkUnitCacheService {

  constructor() { }

  index() {
    function createCacheObject() {
      // worktime hash is on the hot path,
      // Map seems to work faster than plain array, use it whenever possible
      if (typeof Map !== "undefined") {
        return new WorkUnitsMapCache();
      }
      else {
        return new WorkUnitsObjectCache();
      }
    }
    return { createCacheObject: createCacheObject };


  }
}

export class WorkUnitsMapCache {
  _cache: Map<any, any>;
  constructor() {
    this.clear();
  }

  getItem(unit, timestamp) {
    if (this._cache.has(unit)) {
      var unitCache = this._cache.get(unit);
      if (unitCache.has(timestamp)) {
        return unitCache.get(timestamp);
      }
    }
    return -1;
  }
  setItem(unit, timestamp, value) {
    if (!unit || !timestamp) {
      return;
    }
    var cache = this._cache;
    var unitCache;
    if (!cache.has(unit)) {
      unitCache = new Map();
      cache.set(unit, unitCache);
    }
    else {
      unitCache = cache.get(unit);
    }
    unitCache.set(timestamp, value);
  }
  clear() {
    this._cache = new Map();
  }
}


export class WorkUnitsObjectCache {
  _cache: any;

  constructor() {
    this.clear();
  }

  getItem(unit, timestamp) {
    var cache = this._cache;
    if (cache && cache[unit]) {
      var units = cache[unit];
      if (units[timestamp] !== undefined) {
        return units[timestamp];
      }
    }
    return -1;
  }

  setItem(unit, timestamp, value) {
    if (!unit || !timestamp) {
      return;
    }
    var cache = this._cache;
    if (!cache) {
      return;
    }
    if (!cache[unit]) {
      cache[unit] = {};
    }
    cache[unit][timestamp] = value;
  }

  clear() {
    this._cache = {};
  }
}
