import { TestBed } from '@angular/core/testing';

import { GanttObjectService } from './gantt-object.service';

describe('GanttObjectService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GanttObjectService = TestBed.get(GanttObjectService);
    expect(service).toBeTruthy();
  });
});
