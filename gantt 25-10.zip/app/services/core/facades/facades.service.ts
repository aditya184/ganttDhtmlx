import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import { DatastoreService } from '../datastore/datastore.service';

@Injectable({
  providedIn: 'root'
})
export class FacadesService {

  constructor(private utilsService: UtilsService) { }

  // datastore() {

  //   var utils = this.utilsService.utils();
  //   var createTasksFacade = this.datastoreTasks(),
  //     createLinksFacade = this.datastoreLinks(),
  //     DataStore = this.dataStoreService.dataStore(),
  //     TreeDataStore = this.dataStoreService.treeDatastore(),
  //     createDatastoreSelect = this.dataStoreService.select();
  //   var datastoreRender = this.dataStoreService.datastoreRender();

  //   function getDatastores() {
  //     var storeNames = this.$services.getService("datastores");
  //     var res = [];
  //     for (var i = 0; i < storeNames.length; i++) {
  //       res.push(this.getDatastore(storeNames[i]));
  //     }
  //     return res;
  //   }

  //   var createDatastoreFacade = function () {
  //     return {
  //       createDatastore: function (config) {

  //         var $StoreType = (config.type || "").toLowerCase() == "treedatastore" ? TreeDataStore : DataStore;

  //         if (config) {
  //           var self = this;
  //           config.openInitially = function () { return self.config.open_tree_initially; };
  //         }

  //         var store = $StoreType(config);
  //         this.mixin(store, createDatastoreSelect(store));

  //         if (config.name) {
  //           var servicePrefix = "datastore:";

  //           this.$services.dropService(servicePrefix + config.name);
  //           this.$services.setService(servicePrefix + config.name, function () { return store; });

  //           var storeList = this.$services.getService("datastores");
  //           if (!storeList) {
  //             storeList = [];
  //             this.$services.setService("datastores", function () { return storeList; });
  //             storeList.push(config.name);
  //           } else if (storeList.indexOf(config.name) < 0) {
  //             storeList.push(config.name);
  //           }

  //           datastoreRender.bindDataStore(config.name, this);
  //         }

  //         return store;
  //       },
  //       getDatastore: function (name) {
  //         return this.$services.getService("datastore:" + name);
  //       },

  //       refreshData: function () {
  //         var scrollState = this.getScrollState();
  //         this.callEvent("onBeforeDataRender", []);

  //         var stores = getDatastores.call(this);
  //         for (var i = 0; i < stores.length; i++) {
  //           stores[i].refresh();
  //         }

  //         if (scrollState.x || scrollState.y) {
  //           this.scrollTo(scrollState.x, scrollState.y);
  //         }
  //         this.callEvent("onDataRender", []);
  //       },

  //       isChildOf: function (childId, parentId) {
  //         return this.$data.tasksStore.isChildOf(childId, parentId);
  //       },

  //       refreshTask: function (taskId, refresh_links) {
  //         var task = this.getTask(taskId);
  //         if (task && this.isTaskVisible(taskId)) {

  //           this.$data.tasksStore.refresh(taskId, !!this.getState().drag_id);// do quick refresh during drag and drop

  //           if (refresh_links !== undefined && !refresh_links)
  //             return;
  //           for (var i = 0; i < task.$source.length; i++) {
  //             this.refreshLink(task.$source[i]);
  //           }
  //           for (var i = 0; i < task.$target.length; i++) {
  //             this.refreshLink(task.$target[i]);
  //           }
  //         } else if (this.isTaskExists(taskId) && this.isTaskExists(this.getParent(taskId))) {
  //           this.refreshTask(this.getParent(taskId));
  //         }

  //       },
  //       refreshLink: function (linkId) {
  //         this.$data.linksStore.refresh(linkId, !!this.getState().drag_id);// do quick refresh during drag and drop
  //       },

  //       silent: function (code) {
  //         var gantt = this;
  //         gantt.$data.tasksStore.silent(function () {
  //           gantt.$data.linksStore.silent(function () {
  //             code();
  //           });
  //         });
  //       },

  //       clearAll: function () {
  //         var stores = getDatastores.call(this);
  //         for (var i = 0; i < stores.length; i++) {
  //           stores[i].clearAll();
  //         }

  //         this._update_flags();
  //         this.userdata = {};
  //         this.callEvent("onClear", []);
  //         this.render();
  //       },
  //       _clear_data: function () {
  //         this.$data.tasksStore.clearAll();
  //         this.$data.linksStore.clearAll();
  //         this._update_flags();
  //         this.userdata = {};
  //       },

  //       selectTask: function (id) {
  //         var store = this.$data.tasksStore;
  //         if (!this.config.select_task)
  //           return false;
  //         if (id) {

  //           store.select(id);
  //         }
  //         return store.getSelectedId();
  //       },
  //       unselectTask: function (id) {
  //         var store = this.$data.tasksStore;
  //         store.unselect(id);
  //       },
  //       isSelectedTask: function (id) {
  //         return this.$data.tasksStore.isSelected(id);
  //       },
  //       getSelectedId: function () {
  //         return this.$data.tasksStore.getSelectedId();
  //       }
  //     };
  //   };

  //   function createFacade() {
  //     var res = utils.mixin({}, createDatastoreFacade());
  //     utils.mixin(res, createTasksFacade());
  //     utils.mixin(res, createLinksFacade());
  //     return res;
  //   }




  //   return { create: createFacade };

  //   /***/
  // }

  datastoreLinks() {

    var utils = this.utilsService;


    var createLinksStoreFacade = function () {
      return {
        getLinkCount: function () {
          return this.$data.linksStore.count();
        },

        getLink: function (id) {
          return this.$data.linksStore.getItem(id);
        },

        getLinks: function () {
          return this.$data.linksStore.getItems();
        },

        isLinkExists: function (id) {
          return this.$data.linksStore.exists(id);
        },

        addLink: function (link) {
          return this.$data.linksStore.addItem(link);
        },

        updateLink: function (id, data) {
          if (!utils.defined(data))
            data = this.getLink(id);
          this.$data.linksStore.updateItem(id, data);
        },

        deleteLink: function (id) {
          return this.$data.linksStore.removeItem(id);
        },

        changeLinkId: function (oldid, newid) {
          return this.$data.linksStore.changeId(oldid, newid);
        }
      };
    };

    return createLinksStoreFacade;

    /***/
  }

  datastoreTasks() {

    var utils = this.utilsService;

    var createTasksDatastoreFacade = function () {
      return {
        getTask: function (id) {
          this.assert(id, "Invalid argument for gantt.getTask");
          var task = this.$data.tasksStore.getItem(id);
          this.assert(task, "Task not found id=" + id);
          return task;
        },
        getTaskByTime: function (from, to) {
          var p = this.$data.tasksStore.getItems();

          var res = [];

          if (!(from || to)) {
            res = p;
          } else {
            from = +from || -Infinity;
            to = +to || Infinity;
            for (var t = 0; t < p.length; t++) {
              var task = p[t];
              if (+task.start_date < to && +task.end_date > from)
                res.push(task);
            }
          }
          return res;
        },
        isTaskExists: function (id) {
          if (!this.$data || !this.$data.tasksStore) {
            return false;
          }
          return this.$data.tasksStore.exists(id);
        },
        updateTask: function (id, item) {
          if (!utils.defined(item)) item = this.getTask(id);
          this.$data.tasksStore.updateItem(id, item);
          if (this.isTaskExists(id))
            this.refreshTask(id);
        },
        addTask: function (item, parent, index) {
          if (!utils.defined(item.id))
            item.id = utils.uid();

          if (!utils.defined(parent)) parent = this.getParent(item) || 0;
          if (!this.isTaskExists(parent)) parent = this.config.root_id;
          this.setParent(item, parent);

          return this.$data.tasksStore.addItem(item, index, parent);
        },
        deleteTask: function (id) {
          return this.$data.tasksStore.removeItem(id);
        },
        getTaskCount: function () {
          return this.$data.tasksStore.count();
        },
        getVisibleTaskCount: function () {
          return this.$data.tasksStore.countVisible();
        },
        getTaskIndex: function (id) {
          return this.$data.tasksStore.getBranchIndex(id);
        },
        getGlobalTaskIndex: function (id) {
          this.assert(id, "Invalid argument");
          return this.$data.tasksStore.getIndexById(id);
        },
        eachTask: function (code, parent, master) {
          return this.$data.tasksStore.eachItem(utils.bind(code, master || this), parent);
        },
        eachParent: function (callback, startTask, master) {
          return this.$data.tasksStore.eachParent(utils.bind(callback, master || this), startTask);
        },
        changeTaskId: function (oldid, newid) {
          this.$data.tasksStore.changeId(oldid, newid);
          var task = this.$data.tasksStore.getItem(newid);

          var links = [];

          if (task.$source) {
            links = links.concat(task.$source);
          }
          if (task.$target) {
            links = links.concat(task.$target);
          }

          for (var i = 0; i < links.length; i++) {
            var link = this.getLink(links[i]);
            if (link.source == oldid) {
              link.source = newid;
            }
            if (link.target == oldid) {
              link.target = newid;
            }
          }
        },
        calculateTaskLevel: function (item) {
          return this.$data.tasksStore.calculateItemLevel(item);
        },
        getNext: function (id) {
          return this.$data.tasksStore.getNext(id);
        },
        getPrev: function (id) {
          return this.$data.tasksStore.getPrev(id);
        },
        getParent: function (id) {
          return this.$data.tasksStore.getParent(id);
        },
        setParent: function (task, new_pid, silent) {
          return this.$data.tasksStore.setParent(task, new_pid, silent);
        },
        getSiblings: function (id) {
          return this.$data.tasksStore.getSiblings(id).slice();
        },
        getNextSibling: function (id) {
          return this.$data.tasksStore.getNextSibling(id);
        },
        getPrevSibling: function (id) {
          return this.$data.tasksStore.getPrevSibling(id);
        },
        getTaskByIndex: function (index) {
          var id = this.$data.tasksStore.getIdByIndex(index);
          if (this.isTaskExists(id)) {
            return this.getTask(id);
          } else {
            return null;
          }
        },
        getChildren: function (id) {
          if (!this.hasChild(id)) {
            return [];
          } else {
            return this.$data.tasksStore.getChildren(id).slice();
          }
        },
        hasChild: function (id) {
          return this.$data.tasksStore.hasChild(id);
        },
        open: function (id) {
          this.$data.tasksStore.open(id);
        },
        close: function (id) {
          this.$data.tasksStore.close(id);
        },
        moveTask: function (sid, tindex, parent) {
          return this.$data.tasksStore.move.apply(this.$data.tasksStore, arguments);
        },
        sort: function (field, desc, parent, silent) {
          var render = !silent;//4th argument to cancel redraw after sorting

          this.$data.tasksStore.sort(field, desc, parent);
          this.callEvent("onAfterSort", [field, desc, parent]);

          if (render) {
            this.render();
          }
        }
      };
    };

    return createTasksDatastoreFacade;




    /***/
  }

  layout() {

    function createLayoutFacade() {

      function getTimeline(gantt) {
        return gantt.$ui.getView("timeline");
      }

      function getGrid(gantt) {
        return gantt.$ui.getView("grid");
      }

      function getVerticalScrollbar(gantt) {
        return gantt.$ui.getView("scrollVer");
      }

      function getHorizontalScrollbar(gantt) {
        return gantt.$ui.getView("scrollHor");
      }

      var DEFAULT_VALUE = "DEFAULT_VALUE";

      function tryCall(getView, method, args, fallback) {
        var view = getView(this);
        if (!(view && view.isVisible())) {
          if (fallback) {
            return fallback();
          } else {
            return DEFAULT_VALUE;
          }
        } else {
          return view[method].apply(view, args);
        }
      }

      return {

        getColumnIndex: function (name) {
          var res = tryCall.call(this, getGrid, "getColumnIndex", [name]);
          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        dateFromPos: function (x) {
          var res = tryCall.call(this, getTimeline, "dateFromPos", Array.prototype.slice.call(arguments));
          if (res === DEFAULT_VALUE) {
            return this.getState().min_date;
          } else {
            return res;
          }
        },

        posFromDate: function (date) {
          var res = tryCall.call(this, getTimeline, "posFromDate", [date]);
          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        getRowTop: function (index) {
          var self = this;
          var res = tryCall.call(self, getTimeline, "getRowTop", [index],
            function () { return tryCall.call(self, getGrid, "getRowTop", [index]); }
          );

          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        getTaskTop: function (id) {
          var self = this;
          var res = tryCall.call(self, getTimeline, "getItemTop", [id],
            function () { return tryCall.call(self, getGrid, "getItemTop", [id]); }
          );

          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },


        getTaskPosition: function (task, start_date, end_date) {
          var res = tryCall.call(this, getTimeline, "getItemPosition", [task, start_date, end_date]);

          if (res === DEFAULT_VALUE) {
            var top = this.getTaskTop(task.id);
            var height = this.getTaskHeight();

            return {
              left: 0,
              top: top,
              height: height,
              width: 0
            };
          } else {
            return res;
          }
        },

        getTaskHeight: function () {
          var self = this;
          var res = tryCall.call(self, getTimeline, "getItemHeight", [],
            function () { return tryCall.call(self, getGrid, "getItemHeight", []); }
          );

          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },


        columnIndexByDate: function (date) {
          var res = tryCall.call(this, getTimeline, "columnIndexByDate", [date]);
          if (res === DEFAULT_VALUE) {
            return 0;
          } else {
            return res;
          }
        },

        roundTaskDates: function () {
          tryCall.call(this, getTimeline, "roundTaskDates", []);
        },

        getScale: function () {
          var res = tryCall.call(this, getTimeline, "getScale", []);
          if (res === DEFAULT_VALUE) {
            return null;
          } else {
            return res;
          }
        },

        getTaskNode: function (id) {
          var timeline = getTimeline(this);
          if (!timeline || !timeline.isVisible()) {
            return null;
          } else {
            return timeline._taskRenderer.rendered[id];
          }
        },


        getLinkNode: function (id) {
          var timeline = getTimeline(this);
          if (!timeline.isVisible()) {
            return null;
          } else {
            return timeline._linkRenderer.rendered[id];
          }
        },

        scrollTo: function (left, top) {
          var vertical = getVerticalScrollbar(this);
          var horizontal = getHorizontalScrollbar(this);

          var oldH = { position: 0 },
            oldV = { position: 0 };

          if (vertical) {
            oldV = vertical.getScrollState();
          }
          if (horizontal) {
            oldH = horizontal.getScrollState();
          }

          if (horizontal && left * 1 == left) {
            horizontal.scroll(left);
          }
          if (vertical && top * 1 == top) {
            vertical.scroll(top);
          }

          var newV = { position: 0 },
            newH = { position: 0 };
          if (vertical) {
            newV = vertical.getScrollState();
          }
          if (horizontal) {
            newH = horizontal.getScrollState();
          }

          this.callEvent("onGanttScroll", [oldH.position, oldV.position, newH.position, newV.position]);
        },

        showDate: function (date) {
          var date_x = this.posFromDate(date);
          var scroll_to = Math.max(date_x - this.config.task_scroll_offset, 0);
          this.scrollTo(scroll_to);
        },
        showTask: function (id) {
          var pos = this.getTaskPosition(this.getTask(id));

          var left = Math.max(pos.left - this.config.task_scroll_offset, 0);

          var dataHeight = this._scroll_state().y;
          var top;
          if (!dataHeight) {
            top = pos.top;
          } else {
            top = pos.top - (dataHeight - this.config.row_height) / 2;
          }

          this.scrollTo(left, top);
        },
        _scroll_state: function () {
          var result = {
            x: false,
            y: false,
            x_pos: 0,
            y_pos: 0,
            scroll_size: this.config.scroll_size + 1,//1px for inner content
            x_inner: 0,
            y_inner: 0
          };

          var scrollVer = getVerticalScrollbar(this),
            scrollHor = getHorizontalScrollbar(this);
          if (scrollHor) {
            var horState = scrollHor.getScrollState();
            if (horState.visible) {
              result.x = horState.size;
              result.x_inner = horState.scrollSize;
            }
            result.x_pos = horState.position || 0;
          }

          if (scrollVer) {
            var verState = scrollVer.getScrollState();
            if (verState.visible) {
              result.y = verState.size;

              result.y_inner = verState.scrollSize;
            }
            result.y_pos = verState.position || 0;
          }

          return result;
        },
        getScrollState: function () {
          var state = this._scroll_state();
          return { x: state.x_pos, y: state.y_pos, inner_width: state.x, inner_height: state.y, width: state.x_inner, height: state.y_inner };
        }

      };

    }

    return createLayoutFacade;

    /***/
  }

  worktimeCalendars() {

    // TODO: rework public api for date methods
    var utils = this.utilsService;

    var createWorktimeFacade = function (calendarManager, timeCalculator) {
      return {
        getWorkHours: function (date) {
          return timeCalculator.getWorkHours(date);
        },

        setWorkTime: function (config) {
          return timeCalculator.setWorkTime(config);
        },

        unsetWorkTime: function (config) {
          timeCalculator.unsetWorkTime(config);
        },

        isWorkTime: function (date, unit, task) {
          return timeCalculator.isWorkTime(date, unit, task);
        },

        getClosestWorkTime: function (config) {
          return timeCalculator.getClosestWorkTime(config);
        },

        calculateDuration: function (start_date, end_date, task) {
          return timeCalculator.calculateDuration(start_date, end_date, task);
        },
        _hasDuration: function (start_date, end_date, task) {
          return timeCalculator.hasDuration(start_date, end_date, task);
        },

        calculateEndDate: function (start, duration, unit, task) {
          return timeCalculator.calculateEndDate(start, duration, unit, task);
        },

        createCalendar: utils.bind(calendarManager.createCalendar, calendarManager),
        addCalendar: utils.bind(calendarManager.addCalendar, calendarManager),
        getCalendar: utils.bind(calendarManager.getCalendar, calendarManager),
        getCalendars: utils.bind(calendarManager.getCalendars, calendarManager),
        getTaskCalendar: utils.bind(calendarManager.getTaskCalendar, calendarManager),
        deleteCalendar: utils.bind(calendarManager.deleteCalendar, calendarManager)
      };
    };


    return { create: createWorktimeFacade };


    /***/
  }

}
