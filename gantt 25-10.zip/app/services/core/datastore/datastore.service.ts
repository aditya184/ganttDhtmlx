import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import { FacadesService } from '../facades/facades.service';
import { CoreService } from '../core.service';
import { TimelineService } from '../ui/timeline/timeline.service';
import { GanttObjectService } from '../../gantt-object.service';

@Injectable({
  providedIn: 'root'
})
export class DatastoreService {

  constructor(private utilsService: UtilsService, private facadeService: FacadesService, private timelineService: TimelineService) { }

  datastoreHooks(gantt) {

    var utils = this.utilsService;
    var facadeFactory = this.datastore();
    var calculateScaleRange = this.ganttDataRange();

    var facade = facadeFactory.create();
    utils.mixin(gantt, facade);
    var tasksStore = gantt.createDatastore({
      name: "task",
      type: "treeDatastore",
      rootId: function () { return gantt.config.root_id; },
      initItem: utils.bind(_init_task, gantt),
      getConfig: function () { return gantt.config; }
    });

    var linksStore = gantt.createDatastore({
      name: "link",
      initItem: utils.bind(_init_link, gantt)
    });

    gantt.attachEvent("onDestroy", function () {
      tasksStore.destructor();
      linksStore.destructor();
    });

    tasksStore.attachEvent("onBeforeRefreshAll", function () {

      var order = tasksStore.getVisibleItems();

      for (var i = 0; i < order.length; i++) {
        var item = order[i];
        item.$index = i;
        gantt.resetProjectDates(item);
      }

    });

    tasksStore.attachEvent("onFilterItem", function (id, task) {
      var min = null, max = null;
      if (gantt.config.start_date && gantt.config.end_date) {
        if (gantt._isAllowedUnscheduledTask(task)) return true;
        min = gantt.config.start_date.valueOf();
        max = gantt.config.end_date.valueOf();

        if (+task.start_date > max || +task.end_date < +min)
          return false;
      }
      return true;
    });

    tasksStore.attachEvent("onIdChange", function (oldId, newId) {
      gantt._update_flags(oldId, newId);
    });

    tasksStore.attachEvent("onAfterUpdate", function (id) {
      gantt._update_parents(id);
      if (gantt.getState("batchUpdate").batch_update) {
        return true;
      }

      var task = tasksStore.getItem(id);
      for (var i = 0; i < task.$source.length; i++) {
        linksStore.refresh(task.$source[i]);
      }
      for (var i = 0; i < task.$target.length; i++) {
        linksStore.refresh(task.$target[i]);
      }
    });

    tasksStore.attachEvent("onAfterItemMove", function (sid, parent, tindex) {
      var source = gantt.getTask(sid);

      if (this.getNextSibling(sid) !== null) {
        source.$drop_target = this.getNextSibling(sid);
      } else if (this.getPrevSibling(sid) !== null) {
        source.$drop_target = "next:" + this.getPrevSibling(sid);
      } else {
        source.$drop_target = "next:null";
      }

    });

    tasksStore.attachEvent("onStoreUpdated", function (id, item, action) {
      if (action == "delete") {
        gantt._update_flags(id, null);
      }

      var state = gantt.$services.getService("state");
      if (state.getState("batchUpdate").batch_update) {
        return;
      }

      if (gantt.config.fit_tasks && action !== "paint") {
        var oldState = gantt.getState();
        calculateScaleRange(gantt);
        var newState = gantt.getState();

        //this._init_tasks_range();
        if (+oldState.min_date != +newState.min_date || +oldState.max_date != +newState.max_date) {
          gantt.render();

          gantt.callEvent("onScaleAdjusted", []);
          return true;
        }

      }

      if (action == "add" || action == "move" || action == "delete") {
        gantt.$layout.resize();
      } else if (!id) {
        linksStore.refresh();
      }

    });

    linksStore.attachEvent("onAfterAdd", function (id, link) {
      sync_link(link);
    });
    linksStore.attachEvent("onAfterUpdate", function (id, link) {
      sync_links();
    });
    linksStore.attachEvent("onAfterDelete", function (id, link) {
      sync_link_delete(link);
    });
    linksStore.attachEvent("onBeforeIdChange", function (oldId, newId) {
      sync_link_delete(gantt.mixin({ id: oldId }, gantt.$data.linksStore.getItem(newId)));
      sync_link(gantt.$data.linksStore.getItem(newId));
    });

    function checkLinkedTaskVisibility(taskId) {
      var isVisible = gantt.isTaskVisible(taskId);
      if (!isVisible && gantt.isTaskExists(taskId)) {
        var parent = gantt.getParent(taskId);
        if (gantt.isTaskExists(parent) && gantt.isTaskVisible(parent)) {
          parent = gantt.getTask(parent);
          if (gantt.isSplitTask(parent)) {
            isVisible = true;
          }
        }
      }
      return isVisible;
    }

    linksStore.attachEvent("onFilterItem", function (id, link) {
      if (!gantt.config.show_links) {
        return false;
      }

      var sourceVisible = checkLinkedTaskVisibility(link.source);
      var targetVisible = checkLinkedTaskVisibility(link.target);

      if (!(sourceVisible && targetVisible) ||
        gantt._isAllowedUnscheduledTask(gantt.getTask(link.source)) || gantt._isAllowedUnscheduledTask(gantt.getTask(link.target)))
        return false;

      return gantt.callEvent("onBeforeLinkDisplay", [id, link]);
    });


    (function () {
      // delete all connected links after task is deleted
      var treeHelper = this.utilsService.task_tree_helpers();
      var deletedLinks = {};

      gantt.attachEvent("onBeforeTaskDelete", function (id, item) {
        deletedLinks[id] = treeHelper.getSubtreeLinks(gantt, id);
        return true;
      });

      gantt.attachEvent("onAfterTaskDelete", function (id, item) {
        if (deletedLinks[id]) {
          gantt.$data.linksStore.silent(function () {
            for (var i in deletedLinks[id]) {
              gantt.$data.linksStore.removeItem(i);
              sync_link_delete(deletedLinks[id][i]);
            }

            deletedLinks[id] = null;
          });
        }
      });
    })();

    gantt.attachEvent("onAfterLinkDelete", function (id, link) {
      gantt.refreshTask(link.source);
      gantt.refreshTask(link.target);
    });

    gantt.attachEvent("onParse", sync_links);

    mapEvents({
      source: linksStore,
      target: gantt,
      events: {
        "onItemLoading": "onLinkLoading",
        "onBeforeAdd": "onBeforeLinkAdd",
        "onAfterAdd": "onAfterLinkAdd",
        "onBeforeUpdate": "onBeforeLinkUpdate",
        "onAfterUpdate": "onAfterLinkUpdate",
        "onBeforeDelete": "onBeforeLinkDelete",
        "onAfterDelete": "onAfterLinkDelete",
        "onIdChange": "onLinkIdChange"
      }
    });

    mapEvents({
      source: tasksStore,
      target: gantt,
      events: {
        "onItemLoading": "onTaskLoading",
        "onBeforeAdd": "onBeforeTaskAdd",
        "onAfterAdd": "onAfterTaskAdd",
        "onBeforeUpdate": "onBeforeTaskUpdate",
        "onAfterUpdate": "onAfterTaskUpdate",
        "onBeforeDelete": "onBeforeTaskDelete",
        "onAfterDelete": "onAfterTaskDelete",
        "onIdChange": "onTaskIdChange",
        "onBeforeItemMove": "onBeforeTaskMove",
        "onAfterItemMove": "onAfterTaskMove",
        "onFilterItem": "onBeforeTaskDisplay",
        "onItemOpen": "onTaskOpened",
        "onItemClose": "onTaskClosed",
        "onBeforeSelect": "onBeforeTaskSelected",
        "onAfterSelect": "onTaskSelected",
        "onAfterUnselect": "onTaskUnselected"
      }
    });

    gantt.$data = {
      tasksStore: tasksStore,
      linksStore: linksStore
    };

    function sync_link(link) {
      if (gantt.isTaskExists(link.source)) {
        var sourceTask = gantt.getTask(link.source);
        sourceTask.$source = sourceTask.$source || [];
        sourceTask.$source.push(link.id);
      }
      if (gantt.isTaskExists(link.target)) {
        var targetTask = gantt.getTask(link.target);
        targetTask.$target = targetTask.$target || [];
        targetTask.$target.push(link.id);
      }
    }

    function sync_link_delete(link) {
      if (gantt.isTaskExists(link.source)) {
        var sourceTask = gantt.getTask(link.source);
        for (var i = 0; i < sourceTask.$source.length; i++) {
          if (sourceTask.$source[i] == link.id) {
            sourceTask.$source.splice(i, 1);
            break;
          }
        }
      }
      if (gantt.isTaskExists(link.target)) {
        var targetTask = gantt.getTask(link.target);
        for (var i = 0; i < targetTask.$target.length; i++) {
          if (targetTask.$target[i] == link.id) {
            targetTask.$target.splice(i, 1);
            break;
          }
        }
      }
    }

    function sync_links() {
      var task = null;
      var tasks = gantt.$data.tasksStore.getItems();

      for (var i = 0, len = tasks.length; i < len; i++) {
        task = tasks[i];
        task.$source = [];
        task.$target = [];
      }

      var links = gantt.$data.linksStore.getItems();
      for (var i = 0, len = links.length; i < len; i++) {

        var link = links[i];
        sync_link(link);
      }
    }

    function mapEvents(conf) {
      var mapFrom = conf.source;
      var mapTo = conf.target;
      for (var i in conf.events) {
        (function (sourceEvent, targetEvent) {
          mapFrom.attachEvent(sourceEvent, function () {
            return mapTo.callEvent(targetEvent, Array.prototype.slice.call(arguments));
          }, targetEvent);
        })(i, conf.events[i]);
      }
    }

    function _init_task(task) {
      if (!this.defined(task.id))
        task.id = this.uid();

      if (task.start_date)
        task.start_date = gantt.date.parseDate(task.start_date, "parse_date");
      if (task.end_date)
        task.end_date = gantt.date.parseDate(task.end_date, "parse_date");


      var duration = null;
      if (task.duration || task.duration === 0) {
        task.duration = duration = task.duration * 1;
      }

      if (duration) {
        if (task.start_date && !task.end_date) {
          task.end_date = this.calculateEndDate(task);
        } else if (!task.start_date && task.end_date) {
          task.start_date = this.calculateEndDate({
            start_date: task.end_date,
            duration: -task.duration,
            task: task
          });
        }
      }

      task.progress = Number(task.progress) || 0;

      if (this._isAllowedUnscheduledTask(task)) {
        this._set_default_task_timing(task);
      }
      this._init_task_timing(task);
      if (task.start_date && task.end_date)
        this.correctTaskWorkTime(task);

      task.$source = [];
      task.$target = [];
      if (task.parent === undefined) {
        task.parent = this.config.root_id;
      }
      return task;
    }

    function _init_link(link) {
      if (!this.defined(link.id))
        link.id = this.uid();
      return link;
    }
  }

  datastoreRender() {

    var storeRenderCreator = function (name, gantt) {
      var store = gantt.getDatastore(name);

      var itemRepainter = {
        renderItem: function (id, renderer) {

          var renders = renderer.getLayers();

          var item = store.getItem(id);
          if (item && store.isVisible(id)) {
            for (var i = 0; i < renders.length; i++)
              renders[i].render_item(item);
          }
        },
        renderItems: function (renderer) {
          var renderers = renderer.getLayers();
          for (var i = 0; i < renderers.length; i++) {
            renderers[i].clear();
          }

          var data = store.getVisibleItems();

          for (var i = 0; i < renderers.length; i++) {
            renderers[i].render_items(data);
          }
        },
        updateItems: function (layer) {
          if (layer.update_items) {
            var data = store.getVisibleItems();
            layer.update_items(data);
          }
        }
      };

      store.attachEvent("onStoreUpdated", function (id, item, action) {
        var renderer = gantt.$services.getService("layers").getDataRender(name);
        if (renderer) {
          renderer.onUpdateRequest = function (layer) {
            itemRepainter.updateItems(layer);
          };
        }
      });

      function skipRepaint(gantt) {
        var state = gantt.$services.getService("state");
        if (state.getState("batchUpdate").batch_update) {
          return true;
        } else {
          return false;
        }
      }

      store.attachEvent("onStoreUpdated", function (id, item, action) {
        if (skipRepaint(gantt)) {
          return;
        }

        var renderer = gantt.$services.getService("layers").getDataRender(name);

        if (renderer) {
          if (!id || action == "move" || action == "delete") {
            store.callEvent("onBeforeRefreshAll", []);
            itemRepainter.renderItems(renderer);
            store.callEvent("onAfterRefreshAll", []);
          } else {
            store.callEvent("onBeforeRefreshItem", [item.id]);
            itemRepainter.renderItem(item.id, renderer);
            store.callEvent("onAfterRefreshItem", [item.id]);
          }
        }

      });

      // TODO: probably can be done more in a more efficient way
      store.attachEvent("onItemOpen", function () {
        gantt.render();
      });

      store.attachEvent("onItemClose", function () {
        gantt.render();
      });

      function refreshId(renders, oldId, newId, item) {
        for (var i = 0; i < renders.length; i++) {
          renders[i].change_id(oldId, newId);
        }
      }

      store.attachEvent("onIdChange", function (oldId, newId) {

        // in case of linked datastores (tasks <-> links), id change should recalculate something in linked datastore before any repaint
        // use onBeforeIdChange for this hook.
        // TODO: use something more reasonable instead
        store.callEvent("onBeforeIdChange", [oldId, newId]);

        if (skipRepaint(gantt)) {
          return;
        }
        var renderer = gantt.$services.getService("layers").getDataRender(name);
        refreshId(renderer.getLayers(), oldId, newId, store.getItem(newId));
        itemRepainter.renderItem(newId, renderer);
      });

    };

    return {
      bindDataStore: storeRenderCreator
    };

    /***/
  }

  powerArray() {

    var utils = this.utilsService;

    var $powerArray = {
      $create: function (array?) {
        return utils.mixin(array || [], this);
      },
      //remove element at specified position
      $removeAt: function (pos, len) {
        if (pos >= 0) this.splice(pos, (len || 1));
      },
      //find element in collection and remove it
      $remove: function (value) {
        this.$removeAt(this.$find(value));
      },
      //add element to collection at specific position
      $insertAt: function (data, pos) {
        if (!pos && pos !== 0) 	//add to the end by default
          this.push(data);
        else {
          var b = this.splice(pos, (this.length - pos));
          this[pos] = data;
          this.push.apply(this, b); //reconstruct array without loosing this pointer
        }
      },
      //return index of element, -1 if it doesn't exists
      $find: function (data) {
        for (var i = 0; i < this.length; i++)
          if (data == this[i]) return i;
        return -1;
      },
      //execute some method for each element of array
      $each: function (functor, master) {
        for (var i = 0; i < this.length; i++)
          functor.call((master || this), this[i]);
      },
      //create new array from source, by using results of functor
      $map: function (functor, master) {
        for (var i = 0; i < this.length; i++)
          this[i] = functor.call((master || this), this[i]);
        return this;
      },
      $filter: function (functor, master) {
        for (var i = 0; i < this.length; i++)
          if (!functor.call((master || this), this[i])) {
            this.splice(i, 1);
            i--;
          }
        return this;
      }
    };

    return $powerArray;

    /***/
  }

  select() {

    function createDataStoreSelectMixin(store) {
      var selectedId = null;

      var deleteItem = store._removeItemInner;

      function unselect(id) {
        selectedId = null;
        this.callEvent("onAfterUnselect", [id]);
      }

      store._removeItemInner = function (id) {
        if (selectedId == id) {
          unselect.call(this, id);
        }

        if (selectedId && this.eachItem) {
          this.eachItem(function (subItem) {
            if (subItem.id == selectedId) {
              unselect.call(this, subItem.id);
            }
          }, id);
        }

        return deleteItem.apply(this, arguments);
      };

      store.attachEvent("onIdChange", function (oldId, newId) {
        if (store.getSelectedId() == oldId) {
          store.silent(function () {
            store.unselect(oldId);
            store.select(newId);
          });
        }
      });

      return {
        select: function (id) {
          if (id) {

            if (selectedId == id)
              return selectedId;

            if (!this._skip_refresh) {
              if (!this.callEvent("onBeforeSelect", [id])) {
                return false;
              }
            }

            this.unselect();

            selectedId = id;

            if (!this._skip_refresh) {
              this.refresh(id);
              this.callEvent("onAfterSelect", [id]);
            }
          }
          return selectedId;
        },
        getSelectedId: function () {
          return selectedId;
        },
        isSelected: function (id) {
          return id == selectedId;
        },
        unselect: function (id) {
          var id = id || selectedId;
          if (!id)
            return;
          selectedId = null;
          if (!this._skip_refresh) {
            this.refresh(id);
            unselect.call(this, id);
          }
        }
      };
    }

    return createDataStoreSelectMixin;

    /***/
  }

  // facade Service function
  // removing circular dependancy

  datastore() {

    var utils = this.utilsService;
    var createTasksFacade = this.facadeService.datastoreTasks(),
      createLinksFacade = this.facadeService.datastoreLinks(),
      dataStore = DataStore,
      treeDataStore = TreeDataStore,
      createDatastoreSelect = this.select();
    var datastoreRender = this.datastoreRender();

    function getDatastores() {
      var storeNames = this.$services.getService("datastores");
      var res = [];
      for (var i = 0; i < storeNames.length; i++) {
        res.push(this.getDatastore(storeNames[i]));
      }
      return res;
    }

    var createDatastoreFacade = function () {
      return {
        createDatastore: function (config) {

          var $StoreType = (config.type || "").toLowerCase() == "treedatastore" ? TreeDataStore : DataStore;

          if (config) {
            var self = this;
            config.openInitially = function () { return self.config.open_tree_initially; };
          }

          var store = new $StoreType(config);
          this.mixin(store, createDatastoreSelect(store));

          if (config.name) {
            var servicePrefix = "datastore:";

            this.$services.dropService(servicePrefix + config.name);
            this.$services.setService(servicePrefix + config.name, function () { return store; });

            var storeList = this.$services.getService("datastores");
            if (!storeList) {
              storeList = [];
              this.$services.setService("datastores", function () { return storeList; });
              storeList.push(config.name);
            } else if (storeList.indexOf(config.name) < 0) {
              storeList.push(config.name);
            }

            datastoreRender.bindDataStore(config.name, this);
          }

          return store;
        },
        getDatastore: function (name) {
          return this.$services.getService("datastore:" + name);
        },

        refreshData: function () {
          var scrollState = this.getScrollState();
          this.callEvent("onBeforeDataRender", []);

          var stores = getDatastores.call(this);
          for (var i = 0; i < stores.length; i++) {
            stores[i].refresh();
          }

          if (scrollState.x || scrollState.y) {
            this.scrollTo(scrollState.x, scrollState.y);
          }
          this.callEvent("onDataRender", []);
        },

        isChildOf: function (childId, parentId) {
          return this.$data.tasksStore.isChildOf(childId, parentId);
        },

        refreshTask: function (taskId, refresh_links) {
          var task = this.getTask(taskId);
          if (task && this.isTaskVisible(taskId)) {

            this.$data.tasksStore.refresh(taskId, !!this.getState().drag_id);// do quick refresh during drag and drop

            if (refresh_links !== undefined && !refresh_links)
              return;
            for (var i = 0; i < task.$source.length; i++) {
              this.refreshLink(task.$source[i]);
            }
            for (var i = 0; i < task.$target.length; i++) {
              this.refreshLink(task.$target[i]);
            }
          } else if (this.isTaskExists(taskId) && this.isTaskExists(this.getParent(taskId))) {
            this.refreshTask(this.getParent(taskId));
          }

        },
        refreshLink: function (linkId) {
          this.$data.linksStore.refresh(linkId, !!this.getState().drag_id);// do quick refresh during drag and drop
        },

        silent: function (code) {
          var gantt = this;
          gantt.$data.tasksStore.silent(function () {
            gantt.$data.linksStore.silent(function () {
              code();
            });
          });
        },

        clearAll: function () {
          var stores = getDatastores.call(this);
          for (var i = 0; i < stores.length; i++) {
            stores[i].clearAll();
          }

          this._update_flags();
          this.userdata = {};
          this.callEvent("onClear", []);
          this.render();
        },
        _clear_data: function () {
          this.$data.tasksStore.clearAll();
          this.$data.linksStore.clearAll();
          this._update_flags();
          this.userdata = {};
        },

        selectTask: function (id) {
          var store = this.$data.tasksStore;
          if (!this.config.select_task)
            return false;
          if (id) {

            store.select(id);
          }
          return store.getSelectedId();
        },
        unselectTask: function (id) {
          var store = this.$data.tasksStore;
          store.unselect(id);
        },
        isSelectedTask: function (id) {
          return this.$data.tasksStore.isSelected(id);
        },
        getSelectedId: function () {
          return this.$data.tasksStore.getSelectedId();
        }
      };
    };

    function createFacade() {
      var res = utils.mixin({}, createDatastoreFacade());
      utils.mixin(res, createTasksFacade());
      utils.mixin(res, createLinksFacade());
      return res;
    }




    return { create: createFacade };

    /***/
  }

  ganttDataRange() {

    var ScaleHelper = this.timelineService.scales();
    var PrimaryScaleHelper = this.timelineService.scales();


    function dateRangeResolver(gantt) {
      //reset project timing
      //_get_tasks_data(gantt);
      return gantt.getSubtaskDates();
    }

    function defaultRangeResolver() {
      return {
        start_date: new Date(),
        end_date: new Date()
      };
    }

    function resolveConfigRange(unit, gantt) {
      var range = {
        start_date: null,
        end_date: null
      };

      if (gantt.config.start_date && gantt.config.end_date) {
        range.start_date = gantt.date[unit + "_start"](new Date(gantt.config.start_date));

        var end = new Date(gantt.config.end_date);
        var start_interval = gantt.date[unit + "_start"](new Date(end));
        if (+end != +start_interval) {
          end = gantt.date.add(start_interval, 1, unit);
        } else {
          end = start_interval;
        }

        range.end_date = end;
      }
      return range;
    }

    function _scale_range_unit(gantt) {
      var primaryScale = (PrimaryScaleHelper(gantt)).primaryScale();
      var unit = primaryScale.unit;
      var step = primaryScale.step;
      if (gantt.config.scale_offset_minimal) {

        var helper = ScaleHelper(gantt);
        var scales = [helper.primaryScale()].concat(helper.getSubScales());

        helper.sortScales(scales);
        unit = scales[scales.length - 1].unit;
        step = scales[scales.length - 1].step || 1;
      }
      return { unit: unit, step: step };
    }

    function _init_tasks_range(gantt) {
      var cfg = _scale_range_unit(gantt);
      var unit = cfg.unit,
        step = cfg.step;
      var range = resolveConfigRange(unit, gantt);

      if (!(range.start_date && range.end_date)) {
        range = dateRangeResolver(gantt);
        if (!range.start_date || !range.end_date) {
          // range = defaultRangeResolver(gantt);
          range = defaultRangeResolver();
        }

        range.start_date = gantt.date[unit + "_start"](range.start_date);
        range.start_date = gantt.calculateEndDate({
          start_date: gantt.date[unit + "_start"](range.start_date),
          duration: -1,
          unit: unit,
          step: step
        });//one free column before first task

        range.end_date = gantt.date[unit + "_start"](range.end_date);
        range.end_date = gantt.calculateEndDate({ start_date: range.end_date, duration: 2, unit: unit, step: step });//one free column after last task
      }

      gantt._min_date = range.start_date;
      gantt._max_date = range.end_date;
    }

    function _adjust_scales(gantt) {
      if (gantt.config.fit_tasks) {
        var old_min = +gantt._min_date,
          old_max = +gantt._max_date;
        //this._init_tasks_range();
        if (+gantt._min_date != old_min || +gantt._max_date != old_max) {
          gantt.render();

          gantt.callEvent("onScaleAdjusted", []);
          return true;
        }
      }
      return false;
    }

    return function updateTasksRange(gantt) {
      _init_tasks_range(gantt);
      _adjust_scales(gantt);
    };


    /***/
  }
}

export class DataStore {
  pull: {};
  $initItem: any;
  visibleOrder: any;
  fullOrder: any;
  _skip_refresh: boolean;
  _filterRule: any;
  _searchVisibleOrder: {};
  $config: any;
  utilsService: UtilsService
  ganttObject: GanttObjectService
  dataStoreService: DatastoreService;
  constructor(config) {
    this.pull = {};
    this.$initItem = config.initItem;
    this.visibleOrder = this.dataStoreService.powerArray().$create();
    this.fullOrder = this.dataStoreService.powerArray().$create();
    this._skip_refresh = false;
    this._filterRule = null;
    this._searchVisibleOrder = {};
    this.$config = config;
    // eventable(this);
    return this;
  }


  _parseInner(data) {
    var item = null,
      loaded = [];
    for (var i = 0, len = data.length; i < len; i++) {
      item = data[i];
      if (this.$initItem) {
        item = this.$initItem(item);
      }
      if (this.ganttObject.callEvent("onItemLoading", [item])) {
        if (!this.pull.hasOwnProperty(item.id)) {
          this.fullOrder.push(item.id);
        }
        loaded.push(item);
        this.pull[item.id] = item;
      }
    }
    return loaded;
  }

  parse(data) {
    this.ganttObject.callEvent("onBeforeParse", [data]);
    var loaded = this._parseInner(data);
    this.refresh();
    this.ganttObject.callEvent("onParse", [loaded]);
  }

  getItem(id) {
    return this.pull[id];
  }

  _updateOrder(code) {
    code.call(this.visibleOrder);
    code.call(this.fullOrder);
  }

  updateItem(id, item) {
    if (!this.utilsService.defined(item)) item = this.getItem(id);

    if (!this._skip_refresh) {
      if (this.ganttObject.callEvent("onBeforeUpdate", [item.id, item]) === false) return false;
    }
    this.pull[id] = item;
    if (!this._skip_refresh) {
      this.ganttObject.callEvent("onAfterUpdate", [item.id, item]);
      this.ganttObject.callEvent("onStoreUpdated", [item.id, item, "update"]);
    }
  }

  _removeItemInner(id) {
    //clear from collections
    //this.visibleOrder.$remove(id);
    this._updateOrder(function () { this.$remove(id); });
    delete this.pull[id];
  }

  removeItem(id) {
    //utils.assert(this.exists(id), "Not existing ID in remove command"+id);

    var obj = this.getItem(id);	//save for later event
    if (!this._skip_refresh) {
      if (this.ganttObject.callEvent("onBeforeDelete", [obj.id, obj]) === false) return false;
    }

    this._removeItemInner(id);

    if (!this._skip_refresh) {
      this.filter();
      this.ganttObject.callEvent("onAfterDelete", [obj.id, obj]);
      //repaint signal
      this.ganttObject.callEvent("onStoreUpdated", [obj.id, obj, "delete"]);
    }
  }

  _addItemInner(item, index) {
    //in case of treetable order is sent as 3rd parameter
    //var order = index;

    if (this.exists(item.id)) {
      this.silent(function () { this.updateItem(item.id, item); });
    } else {
      var order = this.visibleOrder;

      //by default item is added to the end of the list
      var data_size = order.length;

      if (!this.utilsService.defined(index) || index < 0)
        index = data_size;
      //check to prevent too big indexes
      if (index > data_size) {
        //dhx.log("Warning","DataStore:add","Index of out of bounds");
        index = Math.min(order.length, index);
      }
    }


    //gantt.assert(!this.exists(id), "Not unique ID");

    this.pull[item.id] = item;
    if (!this._skip_refresh) {
      this._updateOrder(function () {
        if (this.$find(item.id) === -1)
          this.$insertAt(item.id, index);
      });
    }
    this.filter();
    //order.$insertAt(item.id,index);
  }


  isVisible(id) {
    return this.visibleOrder.$find(id) > -1;
  }

  getVisibleItems() {
    return this.getIndexRange();
  }

  addItem(item, index) {
    if (!this.utilsService.defined(item.id))
      item.id = this.utilsService.uid();

    if (this.$initItem) {
      item = this.$initItem(item);
    }

    if (!this._skip_refresh) {
      if (this.ganttObject.callEvent("onBeforeAdd", [item.id, item]) === false) return false;
    }


    this._addItemInner(item, index);

    if (!this._skip_refresh) {
      this.ganttObject.callEvent("onAfterAdd", [item.id, item]);
      //repaint signal
      this.ganttObject.callEvent("onStoreUpdated", [item.id, item, "add"]);
    }
    return item.id;
  }

  _changeIdInner(oldId, newId) {
    if (this.pull[oldId])
      this.pull[newId] = this.pull[oldId];

    var visibleOrder = this._searchVisibleOrder[oldId];
    this.pull[newId].id = newId;
    this._updateOrder(function () {
      this[this.$find(oldId)] = newId;
    });
    this._searchVisibleOrder[newId] = visibleOrder;
    delete this._searchVisibleOrder[oldId];

    //this.visibleOrder[this.visibleOrder.$find(oldId)]=newId;
    delete this.pull[oldId];
  }

  changeId(oldId, newId) {
    this._changeIdInner(oldId, newId);

    this.ganttObject.callEvent("onIdChange", [oldId, newId]);

  }

  exists(id) {
    return !!(this.pull[id]);
  }

  _moveInner(sindex, tindex) {
    var id = this.getIdByIndex(sindex);

    this._updateOrder(function () {
      this.$removeAt(sindex);
      this.$insertAt(id, Math.min(this.length, tindex));
    });
    //this.visibleOrder.$removeAt(sindex);	//remove at old position
    //if (sindex<tindex) tindex--;	//correct shift, caused by element removing
    //this.visibleOrder.$insertAt(id,Math.min(this.visibleOrder.length, tindex));	//insert at new position
  }

  move(sindex, tindex) {
    //gantt.assert(sindex>=0 && tindex>=0, "DataStore::move","Incorrect indexes");

    var id = this.getIdByIndex(sindex);
    var obj = this.getItem(id);
    this._moveInner(sindex, tindex);


    if (!this._skip_refresh) {
      //repaint signal
      this.ganttObject.callEvent("onStoreUpdated", [obj.id, obj, "move"]);
    }
  }

  clearAll() {
    this.pull = {};
    this.visibleOrder = this.dataStoreService.powerArray().$create();
    this.fullOrder = this.dataStoreService.powerArray().$create();
    if (this._skip_refresh) return;
    this.ganttObject.callEvent("onClearAll", []);
    this.refresh();
  }

  silent(code, master?) {
    this._skip_refresh = true;
    code.call(master || this);
    this._skip_refresh = false;
  }

  arraysEqual(arr1, arr2) {
    if (arr1.length !== arr2.length)
      return false;
    for (var i = 0; i < arr1.length; i++) {
      if (arr1[i] !== arr2[i])
        return false;
    }

    return true;
  }

  refresh(id?, quick?) {
    if (this._skip_refresh) return;

    var args;
    if (id) {
      args = [id, this.pull[id], "paint"];
    } else {
      args = [null, null, null];
    }

    if (this.ganttObject.callEvent("onBeforeStoreUpdate", args) === false) {
      return;
    }

    if (id) {
      // if item changes visible order (e.g. expand-collapse branch) - do a complete repaint
      if (!quick) {
        var oldOrder = this.visibleOrder;
        this.filter();
        if (!this.arraysEqual(oldOrder, this.visibleOrder)) {
          id = undefined;
        }
      }

    } else {
      this.filter();
    }

    if (id) {
      args = [id, this.pull[id], "paint"];
    } else {
      args = [null, null, null];
    }

    this.ganttObject.callEvent("onStoreUpdated", args);
  }

  count() {
    return this.fullOrder.length;
  }

  countVisible() {
    return this.visibleOrder.length;
  }

  sort(sort) { }

  serialize() { }

  eachItem(code) {
    for (var i = 0; i < this.fullOrder.length; i++) {
      var item = this.pull[this.fullOrder[i]];
      code.call(this, item);
    }
  }

  filter(rule?) {
    this.ganttObject.callEvent("onBeforeFilter", []);
    var filteredOrder = this.dataStoreService.powerArray().$create();
    this.eachItem(function (item) {
      if (this.ganttObject.callEvent("onFilterItem", [item.id, item])) {
        filteredOrder.push(item.id);
      }
    });

    this.visibleOrder = filteredOrder;
    this._searchVisibleOrder = {};
    for (var i = 0; i < this.visibleOrder.length; i++) {
      this._searchVisibleOrder[this.visibleOrder[i]] = i;
    }
    this.ganttObject.callEvent("onFilter", []);
  }

  getIndexRange(from?, to?) {
    to = Math.min((to || Infinity), this.countVisible() - 1);

    var ret = [];
    for (var i = (from || 0); i <= to; i++)
      ret.push(this.getItem(this.visibleOrder[i]));
    return ret;
  }

  getItems() {
    var res = [];
    for (var i in this.pull) {
      res.push(this.pull[i]);
    }
    /*	for(var i = 0; i < this.fullOrder.length; i++){
  
      }*/
    return res;
  }

  getIdByIndex(index) {
    return this.visibleOrder[index];
  }

  getIndexById(id) {
    var res = this._searchVisibleOrder[id];
    if (res === undefined) {
      res = -1;
    }
    return res;
  }

  _getNullIfUndefined(value) {
    if (value === undefined) {
      return null;
    } else {
      return value;
    }
  }

  getFirst() {
    return this._getNullIfUndefined(this.visibleOrder[0]);
  }

  getLast() {
    return this._getNullIfUndefined(this.visibleOrder[this.visibleOrder.length - 1]);
  }

  getNext(id) {
    return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(id) + 1]);
  }

  getPrev(id) {
    return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(id) - 1]);
  }

  destructor() {
    this.ganttObject.detachAllEvents();
    this.pull = null;
    this.$initItem = null;
    this.visibleOrder = null;
    this.fullOrder = null;
    this._skip_refresh = null;
    this._filterRule = null;
    this._searchVisibleOrder = null;
  }
}

export class TreeDataStore {
  _branches: {};
  pull: {};
  $initItem: any;
  $parentProperty: any;
  $getRootId: () => any;
  $openInitially: any;
  visibleOrder: any;
  fullOrder: any;
  _searchVisibleOrder: {};
  _skip_refresh: boolean;
  _ganttConfig: any;
  dataStore: DataStore;

  dataStoreService: DatastoreService;
  ganttObject: GanttObjectService
  utilsService: UtilsService;

  constructor(config) {
    DataStore.apply(this, [config]);
    this._branches = {};

    this.pull = {};
    this.$initItem = config.initItem;
    this.$parentProperty = config.parentProperty || "parent";

    if (typeof config.rootId !== "function") {
      this.$getRootId = (function (val) {
        return function () { return val; };
      })(config.rootId || 0);
    } else {
      this.$getRootId = config.rootId;
    }

    // TODO: replace with live reference to gantt config
    this.$openInitially = config.openInitially;

    this.visibleOrder = this.dataStoreService.powerArray().$create();
    this.fullOrder = this.dataStoreService.powerArray().$create();
    this._searchVisibleOrder = {};
    this._skip_refresh = false;

    this._ganttConfig = null;
    if (config.getConfig) {
      this._ganttConfig = config.getConfig();
    }

    this.ganttObject.attachEvent("onFilterItem", function (id, item) {

      var canOpenSplitTasks: any = false;
      if (this._ganttConfig) {
        var canOpenSplitTasks = this._ganttConfig.open_split_tasks;
      }

      var open = true;
      this.eachParent(function (parent) {
        open = open && parent.$open && (canOpenSplitTasks || !this._isSplitItem(parent));
      }, item);
      return !!open;
    });

    return this;
  }

  // utils.mixin({

  _buildTree(data) {
    var item = null;
    var rootId = this.$getRootId();
    for (var i = 0, len = data.length; i < len; i++) {
      item = data[i];
      this.setParent(item, this.getParent(item) || rootId);
    }

    // calculating $level for each item
    for (var i = 0, len = data.length; i < len; i++) {
      item = data[i];
      this._add_branch(item);
      item.$level = this.calculateItemLevel(item);

      if (!this.utilsService.defined(item.$open)) {
        item.$open = this.utilsService.defined(item.open) ? item.open : this.$openInitially();
      }

    }
    this._updateOrder();
  }
  _isSplitItem(item) {
    return (item.render == "split" && this.hasChild(item.id));
  }
  parse(data) {
    this.ganttObject.callEvent("onBeforeParse", [data]);
    var loaded = this.dataStore._parseInner(data);
    this._buildTree(loaded);
    this.filter();
    this.ganttObject.callEvent("onParse", [loaded]);
  }

  _addItemInner(item, index) {

    var parent = this.getParent(item);

    if (!this.utilsService.defined(parent)) {
      parent = this.$getRootId();
      this.setParent(item, parent);
    }

    var parentIndex = this.dataStore.getIndexById(parent);
    var targetIndex = parentIndex + Math.min(Math.max(index, 0), this.visibleOrder.length);

    if (targetIndex * 1 !== targetIndex) {
      targetIndex = undefined;
    }
    this._addItemInner.call(this, item, targetIndex);
    this.setParent(item, parent);

    if (item.hasOwnProperty("$rendered_parent")) {
      this._move_branch(item, item.$rendered_parent);
    }
    this._add_branch(item, index);
  }
  _changeIdInner(oldId, newId) {
    var children = this.getChildren(oldId);
    var visibleOrder = this._searchVisibleOrder[oldId];

    this._changeIdInner.call(this, oldId, newId);

    var parent = this.getParent(newId);

    this._replace_branch_child(parent, oldId, newId);
    for (var i = 0; i < children.length; i++) {
      this.setParent(this.dataStore.getItem(children[i]), newId);
    }

    this._searchVisibleOrder[newId] = visibleOrder;
    delete this._branches[oldId];
  }

  _traverseBranches(code, parent?) {
    parent = parent || this.$getRootId();
    var branch = this._branches[parent];
    if (branch) {
      for (var i = 0; i < branch.length; i++) {
        var itemId = branch[i];
        code.call(this, itemId);
        if (this._branches[itemId])
          this._traverseBranches(code, itemId);
      }
    }
  }

  _updateOrder(code?) {

    this.fullOrder = this.dataStoreService.powerArray().$create();
    this._traverseBranches(function (taskId) {
      this.fullOrder.push(taskId);
    });

    if (code)
      this._updateOrder.call(this, code);
  }

  _removeItemInner(id) {

    var items = [];
    this.eachItem(function (child) {
      items.push(child);
    }, id);

    items.push(this.dataStore.getItem(id));

    for (var i = 0; i < items.length; i++) {

      this._move_branch(items[i], this.getParent(items[i]), null);
      DataStore.prototype._removeItemInner.call(this, items[i].id);
      this._move_branch(items[i], this.getParent(items[i]), null);
    }
  }

  move(sid, tindex, parent) {
    //target id as 4th parameter
    var id = arguments[3];
    if (id) {
      if (id === sid) return;

      parent = this.getParent(id);
      tindex = this.getBranchIndex(id);
    }
    if (sid == parent) {
      return;
    }
    parent = parent || this.$getRootId();
    var source = this.dataStore.getItem(sid);
    var source_pid = this.getParent(source.id);

    var tbranch = this.getChildren(parent);

    if (tindex == -1)
      tindex = tbranch.length + 1;
    if (source_pid == parent) {
      var sindex = this.getBranchIndex(sid);
      if (sindex == tindex) return;
    }

    if (this.ganttObject.callEvent("onBeforeItemMove", [sid, parent, tindex]) === false)
      return false;

    this._replace_branch_child(source_pid, sid);
    tbranch = this.getChildren(parent);

    var tid = tbranch[tindex];
    if (!tid) //adding as last element
      tbranch.push(sid);
    else
      tbranch = tbranch.slice(0, tindex).concat([sid]).concat(tbranch.slice(tindex));

    this.setParent(source, parent);
    this._branches[parent] = tbranch;

    var diff = this.calculateItemLevel(source) - source.$level;
    source.$level += diff;
    this.eachItem(function (item) {
      item.$level += diff;
    }, source.id)// , this);


    this.dataStore._moveInner(this.dataStore.getIndexById(sid), this.dataStore.getIndexById(parent) + tindex);

    this.ganttObject.callEvent("onAfterItemMove", [sid, parent, tindex]);
    this.dataStore.refresh();
  }

  getBranchIndex(id) {
    var branch = this.getChildren(this.getParent(id));
    for (var i = 0; i < branch.length; i++)
      if (branch[i] == id)
        return i;

    return -1;
  }
  hasChild(id) {
    return (this.utilsService.defined(this._branches[id]) && this._branches[id].length);
  }
  getChildren(id) {
    return this.utilsService.defined(this._branches[id]) ? this._branches[id] : this.dataStoreService.powerArray().$create();
  }

  isChildOf(childId, parentId) {
    if (!this.dataStore.exists(childId))
      return false;
    if (parentId === this.$getRootId())
      return true;

    if (!this.hasChild(parentId))
      return false;

    var item = this.dataStore.getItem(childId);
    var pid = this.getParent(childId);

    var parent = this.dataStore.getItem(parentId);
    if (parent.$level >= item.$level) {
      return false;
    }

    while (item && this.dataStore.exists(pid)) {
      item = this.dataStore.getItem(pid);

      if (item && item.id == parentId)
        return true;
      pid = this.getParent(item);
    }
    return false;
  }

  getSiblings(id) {
    if (!this.dataStore.exists(id)) {
      return this.dataStoreService.powerArray().$create();
    }
    var parent = this.getParent(id);
    return this.getChildren(parent);

  }
  getNextSibling(id) {
    var siblings = this.getSiblings(id);
    for (var i = 0, len = siblings.length; i < len; i++) {
      if (siblings[i] == id)
        return siblings[i + 1] || null;
    }
    return null;
  }
  getPrevSibling(id) {
    var siblings = this.getSiblings(id);
    for (var i = 0, len = siblings.length; i < len; i++) {
      if (siblings[i] == id)
        return siblings[i - 1] || null;
    }
    return null;
  }
  getParent(id) {
    var item = null;
    if (id.id !== undefined) {
      item = id;
    } else {
      item = this.dataStore.getItem(id);
    }

    var parent;
    if (item) {
      parent = item[this.$parentProperty];
    } else {
      parent = this.$getRootId();
    }
    return parent;

  }

  clearAll() {
    this._branches = {};
    DataStore.prototype.clearAll.call(this);
  }

  calculateItemLevel(item) {
    var level = 0;
    this.eachParent(function () {
      level++;
    }, item);
    return level;
  }

  _setParentInner(item, new_pid, silent) {
    if (!silent) {
      if (item.hasOwnProperty("$rendered_parent")) {
        this._move_branch(item, item.$rendered_parent, new_pid);
      } else {
        this._move_branch(item, item[this.$parentProperty], new_pid);
      }
    }
  }
  setParent(item, new_pid, silent?) {
    this._setParentInner(item, new_pid, silent);

    item[this.$parentProperty] = new_pid;
  }
  eachItem(code, parent) {
    parent = parent || this.$getRootId();


    var branch = this.getChildren(parent);
    if (branch)
      for (var i = 0; i < branch.length; i++) {
        var item = this.pull[branch[i]];
        code.call(this, item);
        if (this.hasChild(item.id))
          this.eachItem(code, item.id);
      }
  }
  eachParent(code, startItem) {
    var parentsHash = {};
    var item = startItem;
    var parent = this.getParent(item);

    while (this.dataStore.exists(parent)) {
      if (parentsHash[parent]) {
        throw new Error("Invalid tasks tree. Cyclic reference has been detected on task " + parent);
      }
      parentsHash[parent] = true;
      item = this.dataStore.getItem(parent);
      code.call(this, item);
      parent = this.getParent(item);
    }
  }
  _add_branch(item, index?, parent?) {
    var pid = parent === undefined ? this.getParent(item) : parent;
    if (!this.hasChild(pid))
      this._branches[pid] = this.dataStoreService.powerArray().$create();
    var branch = this.getChildren(pid);
    var added_already = false;
    for (var i = 0, length = branch.length; i < length; i++) {
      if (branch[i] == item.id) {
        added_already = true;
        break;
      }
    }
    if (!added_already) {
      if (index * 1 == index) {

        branch.splice(index, 0, item.id);
      } else {
        branch.push(item.id);
      }

      item.$rendered_parent = pid;
    }
  }
  _move_branch(item, old_parent, new_parent?) {
    //this.setParent(item, new_parent);
    //this._sync_parent(task);
    this._replace_branch_child(old_parent, item.id);
    if (this.dataStore.exists(new_parent) || new_parent == this.$getRootId()) {

      this._add_branch(item, undefined, new_parent);
    } else {
      delete this._branches[item.id];
    }
    item.$level = this.calculateItemLevel(item);
    this.eachItem(function (child) {
      child.$level = this.calculateItemLevel(child);
    }, item.id);
  }

  _replace_branch_child(node, old_id, new_id?) {
    var branch = this.getChildren(node);
    if (branch && node !== undefined) {
      var newbranch = this.dataStoreService.powerArray().$create();
      for (var i = 0; i < branch.length; i++) {
        if (branch[i] != old_id)
          newbranch.push(branch[i]);
        else if (new_id)
          newbranch.push(new_id);
      }
      this._branches[node] = newbranch;
    }

  }

  sort(field, desc, parent) {
    if (!this.dataStore.exists(parent)) {
      parent = this.$getRootId();
    }

    if (!field) field = "order";
    var criteria = (typeof (field) == "string") ? (function (a, b) {
      if (a[field] == b[field]) {
        return 0;
      }

      var result = a[field] > b[field];
      return result ? 1 : -1;
    }) : field;

    if (desc) {
      var original_criteria = criteria;
      criteria = function (a, b) {
        return original_criteria(b, a);
      };
    }

    var els = this.getChildren(parent);

    if (els) {
      var temp = [];
      for (var i = els.length - 1; i >= 0; i--)
        temp[i] = this.dataStore.getItem(els[i]);

      temp.sort(criteria);

      for (var i = 0; i < temp.length; i++) {
        els[i] = temp[i].id;
        this.sort(field, desc, els[i]);
      }
    }
  }

  filter(rule?) {
    for (var i in this.pull) {
      if (this.pull[i].$rendered_parent !== this.getParent(this.pull[i])) {
        this._move_branch(this.pull[i], this.pull[i].$rendered_parent, this.getParent(this.pull[i]));
      }
    }
    return DataStore.prototype.filter.apply(this, arguments);
  }

  open(id) {
    if (this.dataStore.exists(id)) {
      this.dataStore.getItem(id).$open = true;
      this.ganttObject.callEvent("onItemOpen", [id]);
    }
  }

  close(id) {
    if (this.dataStore.exists(id)) {
      this.dataStore.getItem(id).$open = false;
      this.ganttObject.callEvent("onItemClose", [id]);
    }
  }

  destructor() {
    DataStore.prototype.destructor.call(this);
    this._branches = null;
  }

}


