import { Injectable } from '@angular/core';
import { UtilsService } from './utils/utils.service';
import { LocaleService } from './locale/locale.service';

@Injectable({
  providedIn: 'root'
})
export class GanttObjectService {
  boxAttribute = "data-dhxbox";
  _dhx_msg_cfg = null;
  eventHost;
  constructor(private utilsService: UtilsService, private localeService: LocaleService) { }

  messagebox: any = {
    seed: (new Date()).valueOf(),
    uid: this.utilsService.uid,
    expire: 4000,
    keyboard: true,
    position: "top",
    pull: {},
    timers: {}
  }

  modalityObj: any = {}
  gantt: any;

  createEventStorage(obj) {
    var dhx_catch = [];
    var z: any = function () {
      var res = true;
      for (var i = 0; i < dhx_catch.length; i++) {
        if (dhx_catch[i]) {
          var zr = dhx_catch[i].apply(obj, arguments);
          res = res && zr;
        }
      }
      return res;
    };
    z.addEvent = function (ev) {
      if (typeof (ev) == "function")
        return dhx_catch.push(ev) - 1;
      return false;
    };
    z.removeEvent = function (id) {
      dhx_catch[id] = null;
    };
    return z;
  }

  attachEvent(name, catcher, callObj?) {
    name = 'ev_' + name.toLowerCase();
    if (!this.eventHost[name])
      this.eventHost[name] = this.createEventStorage(callObj || this);

    return (name + ':' + this.eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
  };

  attachAll(callback, callObj) {
    this.attachEvent('listen_all', callback, callObj);
  }

  checkEvent(name) {
    return (!!this.eventHost['ev_' + name.toLowerCase()]);
  }

  detachEvent(id) {
    if (id) {
      var list = id.split(':');//get EventName and ID
      var eventName = list[0];
      var eventId = list[1];

      if (this.eventHost[eventName]) {
        this.eventHost[eventName].removeEvent(eventId); //remove event
      }
    }
  }

  detachAllEvents() {
    for (var name in this.eventHost) {
      if (name.indexOf("ev_") === 0)
        delete this.eventHost[name];
    }
  }

  callEvent(name, arg0, callObj?) {
    if (this.eventHost._silent_mode) return true;

    var handlerName = 'ev_' + name.toLowerCase();

    if (this.eventHost['ev_listen_all']) {
      this.eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
    }

    if (this.eventHost[handlerName])
      return this.eventHost[handlerName].apply(callObj || this, arg0);
    return true;
  }

  extends() {

    return function (d, b) {
      for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };

    /***/
  }

  callback(config, result) {
    var usercall = config.callback;
    this.modalBoxHide(config.box);

    this._dhx_msg_cfg = config.box = null;
    if (usercall)
      usercall(result);
  }

  modal_key(e) {
    if (this._dhx_msg_cfg) {
      e = e || event;
      var code = e.which || e.keyCode; // event.keyCode
      var preventDefault = false;

      if (this.messagebox.keyboard) {
        if (code == 13 || code == 32) {
          // default behavior is to confirm/submit popup on space/enter
          // if browser focus is set on button element - do button click instead of default behavior
          var target = e.target || e.srcElement;
          if (this.utilsService.getClassName(target).indexOf("gantt_popup_button") > -1 && target.click) {
            target.click();
          } else {
            this.callback(this._dhx_msg_cfg, true);
            preventDefault = true;
          }
        }

        if (code == 27) {
          this.callback(this._dhx_msg_cfg, false);
          preventDefault = true;
        }
      }

      if (preventDefault) {
        if (e.preventDefault)
          e.preventDefault();
        return !(e.cancelBubble = true);
      }
      return;
    }
  }

  // gantt.event(document, "keydown", modal_key, true);

  modality(mode) {
    if (!this.modalityObj.cover) {
      this.modalityObj.cover = document.createElement("div");
      //necessary for IE only
      this.modalityObj.cover.onkeydown = this.modal_key;
      this.modalityObj.cover.className = "dhx_modal_cover";
      document.body.appendChild(this.modalityObj.cover);
    }

    this.modalityObj.cover.style.display = mode ? "inline-block" : "none";
  }

  button(text, className, result) {
    var buttonAriaAttrs //= gantt._waiAria.messageButtonAttrString(text);
    var name = className.toLowerCase().replace(/ /g, "_");
    var button_css = "gantt_" + name + "_button" + " dhtmlx_" + name + "_button"; // dhtmlx_ok_button, dhtmlx_click_me_button
    return "<div " + buttonAriaAttrs + " class='gantt_popup_button dhtmlx_popup_button " + button_css + "' data-result='" + result + "' result='" + result + "' ><div>" + text + "</div></div>";
  }

  messageonclick(text) {
    this.messageBoxhide(text.id);
    text = null;
  }

  info(text) {
    if (!this.messagebox.area) {
      this.messagebox.area = document.createElement("div");
      this.messagebox.area.className = "gantt_message_area dhtmlx_message_area";
      this.messagebox.area.style[this.messagebox.position] = "5px";
      document.body.appendChild(this.messagebox.area);
    }

    this.messageBoxhide(text.id);
    var message = document.createElement("div");
    message.innerHTML = "<div>" + text.text + "</div>";
    message.className = "gantt-info dhtmlx-info gantt-" + text.type + " dhtmlx-" + text.type;
    this.messageonclick(text);

    // gantt._waiAria.messageInfoAttr(message);

    if (this.messagebox.position == "bottom" && this.messagebox.area.firstChild)
      this.messagebox.area.insertBefore(message, this.messagebox.area.firstChild);
    else
      this.messagebox.area.appendChild(message);

    if (text.expire > 0)
      this.messagebox.timers[text.id] = window.setTimeout(function () {
        this.messagebox.hide(text.id);
      }, text.expire);

    this.messagebox.pull[text.id] = message;
    message = null;

    return text.id;
  }

  getFirstDefined(...args) {
    var values = [].slice.apply(arguments, [0]);

    for (var i = 0; i < values.length; i++) {
      if (values[i]) {
        return values[i];
      }
    }

  }

  _boxStructure(config, ok, cancel) {
    var outerThis: GanttObjectService;
    var box = document.createElement("div");

    var contentId = this.utilsService.uid();
    // gantt._waiAria.messageModalAttr(box, contentId);


    box.className = " gantt_modal_box dhtmlx_modal_box gantt-" + config.type + " dhtmlx-" + config.type;
    box.setAttribute(this.boxAttribute, '1');

    var inner = '';

    if (config.width)
      box.style.width = config.width;
    if (config.height)
      box.style.height = config.height;
    if (config.title)
      inner += '<div class="gantt_popup_title dhtmlx_popup_title">' + config.title + '</div>';
    inner += '<div class="gantt_popup_text dhtmlx_popup_text" id="' + contentId + '"><span>' + (config.content ? '' : config.text) + '</span></div><div  class="gantt_popup_controls dhtmlx_popup_controls">';
    if (ok)
      inner += this.button(this.getFirstDefined(config.ok, this.localeService.locale.labels.message_ok, "OK"), "ok", true);
    if (cancel)
      inner += this.button(this.getFirstDefined(config.cancel, this.localeService.locale.labels.message_cancel, "Cancel"), "cancel", false);

    if (config.buttons) {
      for (var i = 0; i < config.buttons.length; i++) {
        var btn = config.buttons[i];
        if (typeof btn == "object") {
          // Support { label:"Save", css:"main_button", value:"save" }
          var label = btn.label;
          var css = btn.css || ("gantt_" + btn.label.toLowerCase() + "_button dhtmlx_" + btn.label.toLowerCase() + "_button");
          var value = btn.value || i;
          inner += this.button(label, css, value);
        } else {
          inner += this.button(btn, btn, i);
        }
      }
    }

    inner += '</div>';
    box.innerHTML = inner;

    if (config.content) {
      var node = config.content;
      if (typeof node == "string")
        node = document.getElementById(node);
      if (node.style.display == 'none')
        node.style.display = "";
      box.childNodes[config.title ? 1 : 0].appendChild(node);
    }

    box.onclick = function (e: Event) {
      e = e || event;
      var source: any = e.target || e.srcElement;
      if (!source.className) source = source.parentNode;
      if (source.className.split(" ")[0] == "gantt_popup_button") {
        var result = source.getAttribute("data-result");
        result = (result == "true") || (result == "false" ? false : result);
        outerThis.callback(config, result);
      }
    };
    config.box = box;
    if (ok || cancel)
      this._dhx_msg_cfg = config;

    return box;
  }

  _createBox(config, ok, cancel) {
    var box = config.tagName ? config : this._boxStructure(config, ok, cancel);

    if (!config.hidden)
      this.modality(true);
    document.body.appendChild(box);
    var x = Math.abs(Math.floor(((window.innerWidth || document.documentElement.offsetWidth) - box.offsetWidth) / 2));
    var y = Math.abs(Math.floor(((window.innerHeight || document.documentElement.offsetHeight) - box.offsetHeight) / 2));
    if (config.position == "top")
      box.style.top = "-3px";
    else
      box.style.top = y + 'px';
    box.style.left = x + 'px';
    //necessary for IE only
    box.onkeydown = this.modal_key;

    this.modalBoxFocus(box);

    if (config.hidden)
      this.modalBoxHide(box);

    gantt.callEvent("onMessagePopup", [box]);
    return box;
  }

  alertPopup(config) {
    return this._createBox(config, true, false);
  }

  confirmPopup(config) {
    return this._createBox(config, true, true);
  }

  boxPopup(config) {
    return this._createBox(config, false, false);
  }

  box_params(text, type, callback) {
    if (typeof text != "object") {
      if (typeof type == "function") {
        callback = type;
        type = "";
      }
      text = { text: text, type: type, callback: callback };
    }
    return text;
  }

  params(text, type, expire, id) {
    if (typeof text != "object")
      text = { text: text, type: type, expire: expire, id: id };
    text.id = text.id || this.utilsService.uid();
    text.expire = text.expire || this.messagebox.expire;
    return text;
  }

  alertBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "confirm";
    return this.alertPopup(text);
  }

  confirmBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "alert";
    return this.confirmPopup(text);
  }
  
  modalBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "alert";
    return this.boxPopup(text);
  }

  modalBoxHide(node) {
    while (node && node.getAttribute && !node.getAttribute(this.boxAttribute))
      node = node.parentNode;
    if (node) {
      node.parentNode.removeChild(node);
      this.modality(false);

      this.utilsService.callEvent("onAfterMessagePopup", [node], undefined);
    }
  }

  modalBoxFocus(node) {
    setTimeout(function () {
      var focusable = this.utilsService.getFocusableNodes(node);
      if (focusable.length) {
        if (focusable[0].focus) focusable[0].focus();
      }
    }, 1);
  }

  messageBox(text, type?, expire?, id?) {
    text = this.params.apply(this, arguments);
    text.type = text.type || "info";

    var subtype = text.type.split("-")[0];
    switch (subtype) {
      case "alert":
        return this.alertPopup(text);
      case "confirm":
        return this.confirmPopup(text);
      case "modalbox":
        return this.boxPopup(text);
      default:
        return this.info(text);
    }
  }

  messageBoxhideAll() {
    for (var key in this.messagebox.pull)
      this.messageBoxhide(key);
  }

  messageBoxhide(id) {
    var obj = this.messagebox.pull[id];
    if (obj && obj.parentNode) {
      window.setTimeout(function () {
        obj.parentNode.removeChild(obj);
        obj = null;
      }, 2000);
      obj.className += " hidden";

      if (this.messagebox.timers[id])
        window.clearTimeout(this.messagebox.timers[id]);
      delete this.messagebox.pull[id];
    }
  }

  popups = [];

  // gantt.attachEvent("onMessagePopup", function(box) {
  //   this.popups.push(box);
  // });

  // this.attachEvent("onAfterMessagePopup", function(box) {
  //   for (var i = 0; i < this.popups.length; i++) {
  //     if (this.popups[i] === box) {
  //       this.popups.splice(i, 1);
  //       i--;
  //     }
  //   }
  // });

  // this.attachEvent("onDestroy", function() {
  //   if (this.modalityObj.cover && this.modalityObj.cover.parentNode) {
  //     this.modalityObj.cover.parentNode.removeChild(this.modalityObj.cover);
  //   }

  //   for (var i = 0; i < this.popups.length; i++) {
  //     if (this.popups[i].parentNode) {
  //       this.popups[i].parentNode.removeChild(this.popups[i]);
  //     }
  //   }
  //   this.popups = null;

  //   if (this.messagebox.area && this.messagebox.area.parentNode) {
  //     this.messagebox.area.parentNode.removeChild(this.messagebox.area);
  //   }
  //   this.messagebox = null;
  // });


 
}
