import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import { LocaleService } from '../../locale/locale.service';
import { GanttObjectService } from '../../gantt-object.service';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  splt;
  code;
  services = {};
  constructor(private utilsService: UtilsService, private localeService: LocaleService, private gantt: GanttObjectService) { }

  // ajax() {
  createConfig(method, args) {
    var env = this.utilsService.env;
    var serialize = this.serialize;
    var result: any = {
      method: method
    };

    if (args.length === 0) {
      throw new Error("Arguments list of query is wrong.");
    }
    if (args.length === 1) {
      if (typeof args[0] === "string") {
        result.url = args[0];
        result.async = true;
      } else {
        result.url = args[0].url;
        result.async = (args[0].async || true);
        result.callback = args[0].callback;
        result.headers = args[0].headers;
      }
      if (method === "POST" || "PUT") {
        if (args[0].data) {
          if (typeof args[0].data !== "string") {
            result.data = serialize(args[0].data);
          } else {
            result.data = args[0].data;
          }
        } else {
          result.data = "";
        }
      }
      return result;
    }

    result.url = args[0];
    switch (method) {
      case "GET":
      case "DELETE":
        result.callback = args[1];
        result.headers = args[2];
        break;
      case "POST":
      case "PUT":
        if (args[1]) {
          if (typeof args[1] !== "string") {
            result.data = serialize(args[1]);
          } else {
            result.data = args[1];
          }
        } else {
          result.data = "";
        }
        result.callback = args[2];
        result.headers = args[3];
        break;
    }
    return result;
  }

  ajax(gantt) {
    var env = this.utilsService.env;
    var serialize = this.serialize;
    return {

      // if false - dhxr param will added to prevent caching on client side (default),
      // if true - do not add extra params
      cache: true,

      // default method for load/loadStruct, post/get allowed
      // get - since 4.1.1, this should fix 412 error for macos safari
      method: "get",

      parse: function (data) {
        if (typeof data !== "string") return data;

        var obj;
        var w: any = window
        data = data.replace(/^[\s]+/, "");
        if (w.DOMParser && !env.isIE) { // ff,ie9
          obj = (new w.DOMParser()).parseFromString(data, "text/xml");
        } else if (w.ActiveXObject !== w.undefined) {
          obj = new w.ActiveXObject("Microsoft.XMLDOM");
          obj.async = "false";
          obj.loadXML(data);
        }
        return obj;
      },
      xmltop: function (tagname, xhr, obj) {
        if (typeof xhr.status == "undefined" || xhr.status < 400) {
          var xml = (!xhr.responseXML) ? this.parse(xhr.responseText || xhr) : (xhr.responseXML || xhr);
          if (xml && xml.documentElement !== null && !xml.getElementsByTagName("parsererror").length) {
            return xml.getElementsByTagName(tagname)[0];
          }
        }
        if (obj !== -1) gantt.callEvent("onLoadXMLError", ["Incorrect XML", arguments[1], obj]);
        return document.createElement("DIV");
      },
      xpath: function (xpathExp, docObj) {
        if (!docObj.nodeName) docObj = docObj.responseXML || docObj;
        if (env.isIE) {
          return docObj.selectNodes(xpathExp) || [];
        } else {
          var rows = [];
          var first;
          var col = (docObj.ownerDocument || docObj).evaluate(xpathExp, docObj, null, XPathResult.ANY_TYPE, null);

          while (true) {
            first = col.iterateNext();
            if (first) {
              rows.push(first);
            } else {
              break;
            }
          }
          return rows;
        }
      },
      query: function (config) {
        return this._call(
          (config.method || "GET"),
          config.url,
          config.data || "",
          (config.async || true),
          config.callback,
          config.headers
        );
      },
      get: function (url, onLoad, headers) {
        var config = this.createConfig("GET", arguments);
        return this.query(config);
      },
      getSync: function (url, headers) {
        var config = this.createConfig("GET", arguments);
        config.async = false;
        return this.query(config);
      },
      put: function (url, postData, onLoad, headers) {
        var config = this.createConfig("PUT", arguments);
        return this.query(config);
      },
      del: function (url, onLoad, headers) {
        /**
         * https://tools.ietf.org/html/rfc7231#section-4.3.5
         * A payload within a DELETE request message has no defined semantics;
         * sending a payload body on a DELETE request might cause some existing
         * implementations to reject the request.
         */
        var config = this.createConfig("DELETE", arguments);
        return this.query(config);
      },
      post: function (url, postData, onLoad, headers) {
        if (arguments.length == 1) {
          postData = "";
        } else if (arguments.length == 2 && (typeof (postData) == "function" || typeof (window[postData]) == "function")) {
          onLoad = postData;
          postData = "";
        }
        var config = this.createConfig("POST", arguments);
        return this.query(config);
      },
      postSync: function (url, postData, headers) {
        postData = (postData === null ? "" : String(postData));

        var config = this.createConfig("POST", arguments);
        config.async = false;
        return this.query(config);
      },
      _call: function (method, url, postData, async, onLoad, headers) {
        return new gantt.Promise(function (resolve, reject) {
          var w: any = window;
          var t = (w.XMLHttpRequest && !env.isIE ? new XMLHttpRequest() : new w.ActiveXObject("Microsoft.XMLHTTP"));
          var isQt = (navigator.userAgent.match(/AppleWebKit/) !== null && navigator.userAgent.match(/Qt/) !== null && navigator.userAgent.match(/Safari/) !== null);

          if (!!async) {
            t.onreadystatechange = function () {
              if ((t.readyState == 4) || (isQt && t.readyState == 3)) { // what for long response and status 404?
                if (t.status != 200 || t.responseText === "")
                  if (!gantt.callEvent("onAjaxError", [t])) return;

                window.setTimeout(function () {
                  if (typeof (onLoad) == "function") {
                    onLoad.apply(window, [{ xmlDoc: t, filePath: url }]); // dhtmlx-compat, response.xmlDoc.responseXML/responseText
                  }
                  resolve(t);
                  if (typeof (onLoad) == "function") {
                    onLoad = null;
                    t = null;
                  }
                }, 0);
              }
            };
          }

          if (method == "GET" && !this.cache) {
            url += (url.indexOf("?") >= 0 ? "&" : "?") + "dhxr" + new Date().getTime() + "=1";
          }

          t.open(method, url, async);

          if (headers) {
            for (var key in headers)
              t.setRequestHeader(key, headers[key]);
          } else if (method.toUpperCase() == "POST" || method == "PUT" || method == "DELETE") {
            t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
          } else if (method == "GET") {
            postData = null;
          }

          t.setRequestHeader("X-Requested-With", "XMLHttpRequest");

          t.send(postData);

          if (!async) return { xmlDoc: t, filePath: url }; // dhtmlx-compat, response.xmlDoc.responseXML/responseText
        });
      },
      urlSeparator: function (str) {
        if (str.indexOf("?") != -1)
          return "&";
        else
          return "?";
      }
    };
  };

  assert(check, message) {
    if (!check) {
      if (this.config().show_errors && this.utilsService.callEvent("onError", [message], undefined) !== false) {
        this.gantt.messageBox(message, "error", -1);

        // eslint-disable-next-line no-debugger
        // debugger;
      }
    }
  }




  // config(module, exports, __webpack_require__) {



  // date(module, exports) {

  /*
   %d - the day as a number with a leading zero ( 01 to 31 );
   %j - the day as a number without a leading zero ( 1 to 31 );
   %D - the day as an abbreviation ( Sun to Sat );
   %l - the day as a full name ( Sunday to Saturday );
   %W - the ISO-8601 week number of the year. Weeks start on Monday; 1)
   %m - the month as a number without a leading zero ( 1 to 12 );
   %n - the month as a number with a leading zero ( 01 to 12);
   %M - the month as an abbreviation ( Jan to Dec );
   %F - the month as a full name ( January to December );
   %y - the year as a two-digit number ( 00 to 99 );
   %Y - the year as a four-digit number ( 1900–9999 );
   %h - the hour based on the 12-hour clock ( 00 to 11 );
   %H - the hour based on the 24-hour clock ( 00 to 23 );
   %i - the minute as a number with a leading zero ( 00 to 59 );
   %s - the second as a number without a leading zero ( 00 to 59 ); 2)
   %a - displays am (for times from midnight until noon) and pm (for times from noon until midnight);
   %A - displays AM (for times from midnight until noon) and PM (for times from noon until midnight).
  */




  init() {
    var locale: any = this.localeService.locale;

    var s = locale.date.month_short;
    var t = locale.date.month_short_hash = {};
    for (var i = 0; i < s.length; i++)
      t[s[i]] = i;

    var s = locale.date.month_full;
    var t = locale.date.month_full_hash = {};
    for (var i = 0; i < s.length; i++)
      t[s[i]] = i;
  }

  date_part(date) {
    var old = new Date(date);
    date.setHours(0);
    this.hour_start(date);
    if (date.getHours() && //shift to yesterday on dst
      (date.getDate() < old.getDate() || date.getMonth() < old.getMonth() || date.getFullYear() < old.getFullYear()))
      date.setTime(date.getTime() + 60 * 60 * 1000 * (24 - date.getHours()));
    return date;
  }

  time_part(date) {
    return (date.valueOf() / 1000 - date.getTimezoneOffset() * 60) % 86400;
  }

  week_start(date) {
    var shift = date.getDay();
    if (this.config().start_on_monday) {
      if (shift === 0) shift = 6;
      else shift--;
    }
    return this.date_part(this.add(date, -1 * shift, "day"));
  }

  month_start(date) {
    date.setDate(1);
    return this.date_part(date);
  }

  quarter_start(date) {
    this.month_start(date);
    var m = date.getMonth(),
      res_month;

    if (m >= 9) {
      res_month = 9;
    } else if (m >= 6) {
      res_month = 6;
    } else if (m >= 3) {
      res_month = 3;
    } else {
      res_month = 0;
    }

    date.setMonth(res_month);
    return date;
  }

  year_start(date) {
    date.setMonth(0);
    return this.month_start(date);
  }

  day_start(date) {
    return this.date_part(date);
  }

  hour_start(date) {
    if (date.getMinutes())
      date.setMinutes(0);
    this.minute_start(date);

    return date;
  }

  minute_start(date) {
    if (date.getSeconds())
      date.setSeconds(0);
    if (date.getMilliseconds())
      date.setMilliseconds(0);
    return date;
  }
  _add_days(date, inc) {
    var ndate = new Date(date.valueOf());

    ndate.setDate(ndate.getDate() + inc);
    if (inc >= 0 && (!date.getHours() && ndate.getHours()) &&//shift to yesterday on dst
      (ndate.getDate() <= date.getDate() || ndate.getMonth() < date.getMonth() || ndate.getFullYear() < date.getFullYear()))
      ndate.setTime(ndate.getTime() + 60 * 60 * 1000 * (24 - ndate.getHours()));
    return ndate;
  }

  add(date, inc, mode) {
    /*jsl:ignore*/
    var ndate: any = new Date(date.valueOf());
    switch (mode) {
      case "day":
        ndate = this._add_days(ndate, inc);
        break;
      case "week":
        ndate = this._add_days(ndate, inc * 7);
        break;
      case "month":
        ndate.setMonth(ndate.getMonth() + inc);
        break;
      case "year":
        ndate.setYear(ndate.getFullYear() + inc);
        break;
      case "hour":
        /*
          adding hours/minutes via setHour(getHour() + inc) gives weird result when
          adding one hour to the time before switch to a Daylight Saving time

          example: //Sun Mar 30 2014 01:00:00 GMT+0100 (W. Europe Standard Time)
          new Date(2014, 02, 30, 1).setHours(2)
          >>Sun Mar 30 2014 01:00:00 GMT+0100 (W. Europe Standard Time)

          setTime seems working as expected
         */
        ndate.setTime(ndate.getTime() + inc * 60 * 60 * 1000);
        break;
      case "minute":

        ndate.setTime(ndate.getTime() + inc * 60 * 1000);

        break;
      default:
        return this["add_" + mode](date, inc, mode);
    }
    return ndate;
    /*jsl:end*/
  }

  add_quarter(date, inc) {
    return this.add(date, inc * 3, "month");
  }

  to_fixed(num) {
    if (num < 10) return "0" + num;
    return num;
  }

  copy(date) {
    return new Date(date.valueOf());
  }

  date_to_str(format, utc) {
    format = format.replace(/%[a-zA-Z]/g, function (a) {
      switch (a) {
        case "%d":
          return "\"+to_fixed(date.getDate())+\"";
        case "%m":
          return "\"+to_fixed((date.getMonth()+1))+\"";
        case "%j":
          return "\"+date.getDate()+\"";
        case "%n":
          return "\"+(date.getMonth()+1)+\"";
        case "%y":
          return "\"+to_fixed(date.getFullYear()%100)+\"";
        case "%Y":
          return "\"+date.getFullYear()+\"";
        case "%D":
          return "\"+locale.date.day_short[date.getDay()]+\"";
        case "%l":
          return "\"+locale.date.day_full[date.getDay()]+\"";
        case "%M":
          return "\"+locale.date.month_short[date.getMonth()]+\"";
        case "%F":
          return "\"+locale.date.month_full[date.getMonth()]+\"";
        case "%h":
          return "\"+to_fixed((date.getHours()+11)%12+1)+\"";
        case "%g":
          return "\"+((date.getHours()+11)%12+1)+\"";
        case "%G":
          return "\"+date.getHours()+\"";
        case "%H":
          return "\"+to_fixed(date.getHours())+\"";
        case "%i":
          return "\"+to_fixed(date.getMinutes())+\"";
        case "%a":
          return "\"+(date.getHours()>11?\"pm\":\"am\")+\"";
        case "%A":
          return "\"+(date.getHours()>11?\"PM\":\"AM\")+\"";
        case "%s":
          return "\"+to_fixed(date.getSeconds())+\"";
        case "%W":
          return "\"+to_fixed(getISOWeek(date))+\"";
        case "%w":
          return "\"+to_fixed(getWeek(date))+\"";
        default:
          return a;
      }
    });
    if (utc) format = format.replace(/date\.get/g, "date.getUTC");
    var dateToStr = new Function("date", "to_fixed", "locale", "getISOWeek", "getWeek", "return \"" + format + "\";");

    return function (date) {
      return dateToStr(date, this.to_fixed, this.localeService.locale, this.getISOWeek, this.getWeek);
    };
  }
  str_to_date(format, utc) {
    this.splt = "var temp=date.match(/[a-zA-Z]+|[0-9]+/g);";
    var mask = format.match(/%[a-zA-Z]/g);
    for (var i = 0; i < mask.length; i++) {
      switch (mask[i]) {
        case "%j":
        case "%d":
          this.splt += "set[2]=temp[" + i + "]||1;";
          break;
        case "%n":
        case "%m":
          this.splt += "set[1]=(temp[" + i + "]||1)-1;";
          break;
        case "%y":
          this.splt += "set[0]=temp[" + i + "]*1+(temp[" + i + "]>50?1900:2000);";
          break;
        case "%g":
        case "%G":
        case "%h":
        case "%H":
          this.splt += "set[3]=temp[" + i + "]||0;";
          break;
        case "%i":
          this.splt += "set[4]=temp[" + i + "]||0;";
          break;
        case "%Y":
          this.splt += "set[0]=temp[" + i + "]||0;";
          break;
        case "%a":
        case "%A":
          this.splt += "set[3]=set[3]%12+((temp[" + i + "]||'').toLowerCase()=='am'?0:12);";
          break;
        case "%s":
          this.splt += "set[5]=temp[" + i + "]||0;";
          break;
        case "%M":
          this.splt += "set[1]=locale.date.month_short_hash[temp[" + i + "]]||0;";
          break;
        case "%F":
          this.splt += "set[1]=locale.date.month_full_hash[temp[" + i + "]]||0;";
          break;
        default:
          break;
      }
    }
    this.code = "set[0],set[1],set[2],set[3],set[4],set[5]";
    if (utc) this.code = " Date.UTC(" + this.code + ")";
    var strToDate = new Function("date", "locale", "var set=[0,0,1,0,0,0]; " + this.splt + " return new Date(" + this.code + ");");

    return function (dateString) {
      return strToDate(dateString, this.localeService.locale);
    };
  }

  // return strToDate = new Function("date", "locale", "var set=[0,0,1,0,0,0]; " + this.splt + " return new Date(" + this.code + ");");

  parse_date(dateString) {
    // this.strToDate(dateString, this.localeService.locale)
  }

  xml_date(dateString) {
    // this.strToDate(dateString, this.localeService.locale)
  }

  getISOWeek(ndate) {
    return this._getWeekNumber(ndate, true);
  }

  _getWeekNumber(ndate, isoWeek) {
    if (!ndate) return false;
    var nday = ndate.getDay();
    if (isoWeek) {
      if (nday === 0) {
        nday = 7;
      }
    }
    var first_thursday = new Date(ndate.valueOf());
    first_thursday.setDate(ndate.getDate() + (4 - nday));
    var year_number = first_thursday.getFullYear(); // year of the first Thursday
    var ordinal_date = Math.round((first_thursday.getTime() - new Date(year_number, 0, 1).getTime()) / 86400000); //ordinal date of the first Thursday - 1 (so not really ordinal date)
    var week_number = 1 + Math.floor(ordinal_date / 7);
    return week_number;
  }

  getWeek(ndate) {
    return this._getWeekNumber(ndate, this.config().start_on_monday);
  }

  getUTCISOWeek(ndate) {
    return this.getISOWeek(ndate);
  }

  convert_to_utc(date) {
    return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
  }

  parseDate(date, format) {
    // raw date may be of type string, number (timestamp) or something else
    // do not check for instanceof Date explicitly, since we may swap native date with different date implementation at some point
    if (date && !date.getFullYear) {
      if (typeof (format) !== "function") {
        if (typeof (format) === "string") {
          if (format === "parse_date") {
            format = this.parse_date;
            if (this.utilsService.defined(this.xml_date) && this.parse_date !== this.xml_date) {
              format = this.xml_date;
            }
          } else {
            format = this.utilsService.defined(this[format]) ? this[format] : this.str_to_date(format, undefined);
          }
        } else {
          format = this.xml_date !== this.parse_date ? this.xml_date : this.parse_date;
        }
      }
      if (date) {
        date = format(date);
      } else {
        date = null;
      }
    }
    return date;
  }

  import(gantt) {
    gantt.$inject = function (module) {
      return module(this.$services);
    };
  };

  // }

  serialize(data) {
    if (typeof data === "string" || typeof data === "number") {
      return data;
    }
    var result = "";
    for (var key in data) {
      var serialized = "";
      if (data.hasOwnProperty(key)) {
        if (typeof data[key] === "string") {
          serialized = encodeURIComponent(data[key]);
        }
        else if (typeof data[key] === "number") {
          serialized = data[key];
        }
        else {
          serialized = encodeURIComponent(JSON.stringify(data[key]));
        }
        serialized = key + "=" + serialized;
        if (result.length) {
          serialized = "&" + serialized;
        }
        result += serialized;
      }
    }
    return result;
  }

  // services(module, exports) {

  // services() {

  // services = {};
  register(name, getter) {
    this.services[name] = getter;
  }

  getService(name) {
    if (!this.services[name]) {
      return null;
    }
    return this.services[name]();
  }

  dropService(name) {
    if (this.services[name]) {
      delete this.services[name];
    }
  }

  config() {
    return this.getService("config");
  }

  templatesService() {
    return this.getService("templates");
  }

  locale() {
    return this.getService("locale");
  }

  destructor() {
    for (var i in this.services) {
      if (this.services[i]) {
        var service = this.services[i];
        if (service && service.destructor) {
          service.destructor();
        }
      }
    }
    this.services = null;
  }

  stateProviders = {};

  getState(name) {
    if (name) {
      return this.stateProviders[name].method();
    } else {
      var res = {};
      for (var i in this.stateProviders) {
        if (!this.stateProviders[i].internal)
          this.utilsService.mixin(res, this.stateProviders[i].method(), true);
      }
      return res;
    }
  }

  registerProvider(name, provider, internal?) {
    this.stateProviders[name] = { method: provider, internal: internal };
  }

  unregisterProvider(name) {
    delete this.stateProviders[name];
  }


  // return {
  //   getState: getState,
  //   registerProvider: registerProvider,
  //   unregisterProvider: unregisterProvider
  // };
  // }

  //   return StateService;

  //   /***/
  // }

  templates(): any {
    var outerThis: CommonService
    var regTemplates = {};

    function initTemplate(name, initial, template_name, config, templates) {
      template_name = template_name || name;
      var config: any = outerThis.config,
        templates: any = outerThis.templates;

      if (outerThis.config[name] && regTemplates[template_name] != config[name]) {
        if (!(initial && templates[template_name])) {
          templates[template_name] = outerThis.date_to_str(config[name], undefined);
          regTemplates[template_name] = config[name];
        }
      }
    }

    function initTemplates() {
      var labels: any = outerThis.localeService.locale.labels;
      labels.gantt_save_btn = labels.icon_save;
      labels.gantt_cancel_btn = labels.icon_cancel;
      labels.gantt_delete_btn = labels.icon_delete;


      // var date = gantt.date;

      //build configuration based templates
      var d: any = outerThis.date_to_str;
      var c: any = outerThis.config;
      var format_date = d(c.xml_date || c.date_format, c.server_utc);
      var parse_date = outerThis.str_to_date(c.xml_date || c.date_format, c.server_utc);

      initTemplate("date_scale", true, undefined, outerThis.config, outerThis.templates);
      initTemplate("date_grid", true, "grid_date_format", outerThis.config, outerThis.templates);
      initTemplate("task_date", true, undefined, outerThis.config, outerThis.templates);

      outerThis.utilsService.mixin(outerThis.templates, {
        xml_format: format_date, // deprecated
        format_date: format_date,

        xml_date: parse_date, // deprecated
        parse_date: parse_date,

        progress_text: function (start, end, task) {
          return "";
        },
        grid_header_class: function (column, config) {
          return "";
        },

        task_text: function (start, end, task) {
          return task.text;
        },
        task_class: function (start, end, task) {
          return "";
        },
        grid_row_class: function (start, end, task) {
          return "";
        },
        task_row_class: function (start, end, task) {
          return "";
        },
        timeline_cell_class: function (item, date) {
          return "";
        },
        scale_cell_class: function (date) {
          return "";
        },
        scale_row_class: function (date) {
          return "";
        },

        grid_indent: function (item) {
          return "<div class='gantt_tree_indent'></div>";
        },
        grid_folder: function (item) {
          return "<div class='gantt_tree_icon gantt_folder_" + (item.$open ? "open" : "closed") + "'></div>";
        },
        grid_file: function (item) {
          return "<div class='gantt_tree_icon gantt_file'></div>";
        },
        grid_open: function (item) {
          return "<div class='gantt_tree_icon gantt_" + (item.$open ? "close" : "open") + "'></div>";
        },
        grid_blank: function (item) {
          return "<div class='gantt_tree_icon gantt_blank'></div>";
        },
        date_grid: function (date, item) {
          if (item && gantt.isUnscheduledTask(item) && outerThis.config().show_unscheduled) {
            return this.task_unscheduled_time(item);
          } else {
            return this.grid_date_format(date);
          }
        },

        task_time: function (start, end, ev) {
          if (gantt.isUnscheduledTask(ev) && this.config().show_unscheduled) {
            return gantt.templates.task_unscheduled_time(ev);
          } else {
            return gantt.templates.task_date(start) + " - " + gantt.templates.task_date(end);
          }
        },

        task_unscheduled_time: function (task) {
          return "";
        },

        time_picker: d(c.time_picker),
        link_class: function (link) {
          return "";
        },
        link_description: function (link) {
          var from = gantt.getTask(link.source),
            to = gantt.getTask(link.target);

          return "<b>" + from.text + "</b> &ndash;  <b>" + to.text + "</b>";
        },

        drag_link: function (from, from_start, to, to_start) {
          from = gantt.getTask(from);
          var labels = outerThis.localeService.locale.labels;

          var text = "<b>" + from.text + "</b> " + (from_start ? labels.link_start : labels.link_end) + "<br/>";
          if (to) {
            to = gantt.getTask(to);
            text += "<b> " + to.text + "</b> " + (to_start ? labels.link_start : labels.link_end) + "<br/>";
          }
          return text;
        },
        drag_link_class: function (from, from_start, to, to_start) {
          var add = "";

          if (from && to) {
            // var allowed = gantt.isLinkAllowed(from, to, from_start, to_start);
            // add = " " + (allowed ? "gantt_link_allow" : "gantt_link_deny");
          }

          return "gantt_link_tooltip" + add;
        },

        /* used for aria-labels of bar elements and for tooltip.js */
        tooltip_date_format: outerThis.date_to_str("%Y-%m-%d", undefined),
        tooltip_text: function (start, end, event) {
          // return "<b>Task:</b> " + event.text + "<br/><b>Start date:</b> " + outerThis.templates.tooltip_date_format(start) + "<br/><b>End date:</b> " + gantt.templates.tooltip_date_format(end);
        }
      });
    }
  }

}

class DND {
  _obj: any;
  _settings: any;
  _drag_start_timer: any;
  utilServices: UtilsService;
  config: any = {};
  ganttObject: GanttObjectService;
  constructor(obj, config) {
    this._obj = obj;
    this._settings = config || {};
    this.utilServices.eventable();

    var inputMethods = this.getInputMethods();

    this._drag_start_timer = null;
    gantt.attachEvent("onGanttScroll", this.utilServices.bind(function (left, top) {
      this.clearDragTimer();
    }, this));

    for (var i = 0; i < inputMethods.length; i++) {
      (this.utilServices.bind(function (input) {

        gantt.event(obj, input.down, this.utilServices.bind(function (e) {
          if (!input.accessor(e)) {
            return;
          }

          this._settings.original_target = this.copyDomEvent(e);

          if (this.config().touch) {
            this.clearDragTimer();

            this._drag_start_timer = setTimeout(this.utilServices.bind(function () {
              this.dragStart(obj, e, input);
            }, this), this.config().touch_drag);
          }
          else {
            this.dragStart(obj, e, input);
          }
        }, this));

        gantt.event(document.body, input.up, this.utilServices.bind(function (e) {
          if (!input.accessor(e)) {
            return;
          }
          this.clearDragTimer();
        }, this));

      }, this))(inputMethods[i]);
    }


  }

  copyDomEvent(e) {
    return {
      target: e.target || e.srcElement,
      pageX: e.pageX,
      pageY: e.pageY,
      clientX: e.clientX,
      clientY: e.clientY,
      metaKey: e.metaKey,
      shiftKey: e.shiftKey,
      ctrlKey: e.ctrlKey,
      altKey: e.altKey
    };
  }

  traceDragEvents(domElement, inputMethod) {
    var mousemove = this.utilServices.bind(function (e) {
      return this.dragMove(domElement, e, inputMethod.accessor);
    }, this);
    this.utilServices.bind(function (e) {
      return this.dragScroll(domElement, e);
    }, this);

    var limited_mousemove = this.utilServices.bind(function (e) {
      if (this.config.started && this.utilServices.defined(this.config.updates_per_second)) {
        if (!this.utilServices.checkTimeout(this, this.config.updates_per_second))
          return;
      }

      var dndActive = mousemove(e);

      if (dndActive) {
        if (e && e.preventDefault) //Cancel default action on DND
          e.preventDefault();
        e.cancelBubble = true;
      }

      return dndActive;
    }, this);

    var mouseup = this.utilServices.bind(function (e) {
      gantt.eventRemove(document.body, inputMethod.move, limited_mousemove);
      gantt.eventRemove(document.body, inputMethod.up, mouseup);
      return this.dragEnd(domElement);
    }, this);

    gantt.event(document.body, inputMethod.move, limited_mousemove);
    gantt.event(document.body, inputMethod.up, mouseup);
  }

  checkPositionChange(pos) {
    var diff_x = pos.x - this.config.pos.x;
    var diff_y = pos.y - this.config.pos.y;
    var distance = Math.sqrt(Math.pow(Math.abs(diff_x), 2) + Math.pow(Math.abs(diff_y), 2));

    if (distance > this.config.sensitivity) {
      return true;
    } else {
      return false;
    }
  }
  initDnDMarker() {
    // create dnd placeholder and put it in dom
    var marker = this.config.marker = document.createElement("div");
    marker.className = "gantt_drag_marker";
    marker.innerHTML = "Dragging object";
    document.body.appendChild(marker);
  }

  backupEventTarget(domEvent, getEvent) {
    if (!this.config().touch) {
      return;
    }

    // keep original event target in DOM in order to keep dnd on touchmove event
    var e = getEvent(domEvent);

    var el = e.target || e.srcElement;
    var copy = el.cloneNode(true);
    //this.config.target.target = copy;
    this.config.original_target = this.copyDomEvent(e);
    this.config.original_target.target = copy;
    this.config.backup_element = el;
    el.parentNode.appendChild(copy);

    el.style.display = "none";
    document.body.appendChild(el);
  }

  getInputMethods() {
    // bind actions to browser events
    var inputMethods = [];

    inputMethods.push({
      "move": "mousemove",
      "down": "mousedown",
      "up": "mouseup",
      "accessor": function (e) {
        return e;
      }
    });

    if (this.config().touch) {

      var touchEventsSupported = true;
      try {
        document.createEvent("TouchEvent");
      } catch (e) {
        touchEventsSupported = false;
      }

      if (touchEventsSupported) {
        inputMethods.push({
          "move": "touchmove",
          "down": "touchstart",
          "up": "touchend",
          "accessor": function (ev) {
            if (ev.touches && ev.touches.length > 1) return null;
            if (ev.touches[0])
              return {
                target: document.elementFromPoint(ev.touches[0].clientX, ev.touches[0].clientY),
                pageX: ev.touches[0].pageX,
                pageY: ev.touches[0].pageY,
                clientX: ev.touches[0].clientX,
                clientY: ev.touches[0].clientY
              };
            else
              return ev;
          }
        });
      } else if (window.navigator.pointerEnabled) {
        inputMethods.push({
          "move": "pointermove",
          "down": "pointerdown",
          "up": "pointerup",
          "accessor": function (ev) {
            if (ev.pointerType == "mouse") return null;
            return ev;
          }
        });

      } else if (window.navigator.msPointerEnabled) {
        inputMethods.push({
          "move": "MSPointerMove",
          "down": "MSPointerDown",
          "up": "MSPointerUp",
          "accessor": function (ev) {
            if (ev.pointerType == ev.MSPOINTER_TYPE_MOUSE) return null;
            return ev;
          }
        });
      }
    }

    return inputMethods;
  }

  clearDragTimer() {
    if (this._drag_start_timer) {
      clearTimeout(this._drag_start_timer);
      this._drag_start_timer = null;
    }
  }

  dragStart(obj, e, inputMethod) {
    if (this.config && this.config.started) {
      return;
    }
    this.config = {
      obj: obj,
      marker: null,
      started: false,
      pos: this.getPosition(e),
      sensitivity: 4
    };
    if (this._settings)
      this.utilServices.mixin(this.config, this._settings, true);


    this.traceDragEvents(obj, inputMethod);

    this.ganttObject.gantt._prevent_touch_scroll = true;
    document.body.className += " gantt_noselect";

    if (this.config().touch) {
      this.dragMove(obj, e, inputMethod.accessor);
    }

  }

  dragMove(obj, e, getEvent) {
    var source = getEvent(e);
    if (!source) return false;

    if (!this.config.marker && !this.config.started) {
      var pos = this.getPosition(source);

      if (this.config().touch || this.checkPositionChange(pos)) {
        // real drag starts here,
        // when user moves mouse at first time after onmousedown
        this.config.started = true;
        this.config.ignore = false;
        if (this.ganttObject.callEvent("onBeforeDragStart", [obj, this.config.original_target], undefined) === false) {
          this.config.ignore = true;
          return false;
        }
        this.backupEventTarget(e, getEvent);
        this.initDnDMarker();
        this.ganttObject.gantt._touch_feedback();
        this.ganttObject.callEvent("onAfterDragStart", [obj, this.config.original_target], undefined);
      } else {
        this.config.ignore = true;
      }
    }

    if (!this.config.ignore) {
      source.pos = this.getPosition(source);
      this.config.marker.style.left = source.pos.x + "px";
      this.config.marker.style.top = source.pos.y + "px";
      this.ganttObject.callEvent("onDragMove", [obj, source], undefined);
      return true;
    }
    return false;
  }

  dragEnd(obj) {
    var target = this.config.backup_element;
    if (target && target.parentNode) {
      target.parentNode.removeChild(target);
    }
    this.ganttObject.gantt._prevent_touch_scroll = false;
    if (this.config.marker) {
      this.config.marker.parentNode.removeChild(this.config.marker);
      this.config.marker = null;

      this.ganttObject.callEvent("onDragEnd", [], undefined);
    }
    this.config.started = false;
    document.body.className = document.body.className.replace(" gantt_noselect", "");
  }

  getPosition(e) {
    var x = 0, y = 0;
    e = e || window.event;
    if (e.pageX || e.pageY) {
      x = e.pageX;
      y = e.pageY;
    } else if (e.clientX || e.clientY) {
      x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
      y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
    }
    return { x: x, y: y };
  }
}

