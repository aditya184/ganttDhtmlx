import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import { RenderService } from './render/render.service';
import { LayoutService, Cell, Layout } from './layout/layout.service';
import { TimelineService } from './timeline/timeline.service';
// import { GridService, Grid } from './grid/grid.service';
import { TasksGridHelpersService } from './grid/tasks-grid-helpers/tasks-grid-helpers.service';
import { GridEditorsService } from './grid/editors/grideditors.service';
import { CommonService } from '../common/common.service';
import { GanttObjectService } from '../../gantt-object.service';

@Injectable({
  providedIn: 'root'
})
export class UiService {
  eventHandlers = {
    "click": {},
    "doubleclick": {},
    "contextMenu": {}
  };
  constructor(private utilsService: UtilsService, private renderService: RenderService, private layoutService: LayoutService, private timelineService: TimelineService,
    private taskGridHelpers: TasksGridHelpersService, private gridEditorService: GridEditorsService, private commonService: CommonService, private ganttObject: GanttObjectService) { }

  configurable(obj, parent) {
    this.utilsService.mixin(obj, new Configurable(parent));
  }

  index() {

    var uiFactory = this.uiFactory(),
      mouseEvents = this.mouse(),
      createLayers = new GanttLayers(),
      cell = Cell,
      layout = Layout,
      ViewLayout = this.layoutService.viewLayout(),
      ViewCell = this.layoutService.viewCell(),
      Resizer = this.layoutService.resizerCell(),
      Scrollbar = this.layoutService.scrollbarCell(),
      Timeline = this.timelineService.timeline(),
      grid = Grid,
      ResourceGrid = Grid,
      ResourceTimeline = this.timelineService.timeline(),
      ResourceHistogram = this.timelineService.timeline();


    var gridEditorsFactory = this.gridEditorService.controller();


    var renderTaskBar = this.renderService.taskBarSmartRender(),
      renderSplitTaskBar = this.renderService.taskSplitRender(),
      renderTaskBg = this.renderService.taskBgRender(),
      renderLink = this.renderService.linkRender(),
      gridRenderer = this.renderService.taskGridLineRender();

    var mainGridInitializer = this.mainGridInitializer();
    var mainTimelineInitializer = this.timelineService.mainTimelineInitializer();
    var mainLayoutInitializer = this.main_layoutInitializer();

    function initUI(gantt) {
      function attachInitializer(view, initializer) {
        var ext = initializer(gantt);
        if (ext.onCreated)
          ext.onCreated(view);
        view.attachEvent("onReady", function () {
          if (ext.onInitialized)
            ext.onInitialized(view);
        });
        view.attachEvent("onDestroy", function () {
          if (ext.onDestroyed)
            ext.onDestroyed(view);
        });
      }

      var factory = uiFactory.createFactory(gantt);
      factory.registerView("cell", Cell);
      factory.registerView("resizer", Resizer);
      factory.registerView("scrollbar", Scrollbar);
      factory.registerView("layout", Layout, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "main") {
          attachInitializer(view, mainLayoutInitializer);
        }
      });
      factory.registerView("viewcell", ViewCell);
      factory.registerView("multiview", ViewLayout);
      factory.registerView("timeline", Timeline, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "timeline" || view.$config.bind == "task") {
          attachInitializer(view, mainTimelineInitializer);
        }
      });
      factory.registerView("grid", grid, function (view) {
        var id = view.$config ? view.$config.id : null;
        if (id === "grid" || view.$config.bind == "task") {
          attachInitializer(view, mainGridInitializer);
        }
      });

      factory.registerView("resourceGrid", ResourceGrid);
      factory.registerView("resourceTimeline", ResourceTimeline);
      factory.registerView("resourceHistogram", ResourceHistogram);

      var layersEngine = new GanttLayers();

      var inlineEditors = gridEditorsFactory(gantt);

      gantt.ext.inlineEditors = inlineEditors;
      gantt.ext._inlineEditors = inlineEditors;
      inlineEditors.init(gantt);

      return {
        factory: factory,
        mouseEvents: mouseEvents.init(gantt),
        layersApi: layersEngine.init(),
        render: {
          gridLine: function () {
            return gridRenderer(gantt);
          },
          taskBg: function () {
            return renderTaskBg(gantt);
          },
          taskBar: function () {
            return renderTaskBar(gantt);
          },
          taskSplitBar: function () {
            return renderSplitTaskBar(gantt);
          },
          link: function () {
            return renderLink(gantt);
          }
        },
        layersService: {
          getDataRender: function (name) {
            // return layersEngine.getDataRender(name, gantt);
            return layersEngine.getDataRender(name);
          },
          createDataRender: function (config) {
            // return layersEngine.createDataRender(config, gantt);
            return layersEngine.createDataRender(config);

          }
        }
      };
    }

    return {
      init: initUI
    };

    /***/
  }

  main_layoutInitializer() {

    var domHelpers = this.utilsService;

    var initializer = (function () {
      return function (gantt) {
        return {

          getVerticalScrollbar: function () {
            return gantt.$ui.getView("scrollVer");
          },
          getHorizontalScrollbar: function () {
            return gantt.$ui.getView("scrollHor");
          },

          _legacyGridResizerClass: function (layout) {
            var resizers = layout.getCellsByType("resizer");
            for (var i = 0; i < resizers.length; i++) {
              var r = resizers[i];
              var gridResizer = false;

              var prev = r.$parent.getPrevSibling(r.$id);
              if (prev && prev.$config && prev.$config.id === "grid") {
                gridResizer = true;
              } else {
                var next = r.$parent.getNextSibling(r.$id);
                if (next && next.$config && next.$config.id === "grid") {
                  gridResizer = true;
                }
              }

              if (gridResizer) {
                r.$config.css = (r.$config.css ? r.$config.css + " " : "") + "gantt_grid_resize_wrap";
              }
            }
          },

          onCreated: function (layout) {
            var first = true;

            this._legacyGridResizerClass(layout);

            layout.attachEvent("onBeforeResize", function () {
              var mainTimeline = gantt.$ui.getView("timeline");
              if (mainTimeline)
                mainTimeline.$config.hidden = mainTimeline.$parent.$config.hidden = !gantt.config.show_chart;

              var mainGrid = gantt.$ui.getView("grid");

              if (!mainGrid)
                return;

              var showGrid = gantt.config.show_grid;
              if (first) {
                var colsWidth = mainGrid._getColsTotalWidth();
                if (colsWidth !== false) {
                  gantt.config.grid_width = colsWidth;
                }
                showGrid = showGrid && !!gantt.config.grid_width;
                gantt.config.show_grid = showGrid;
              }
              mainGrid.$config.hidden = mainGrid.$parent.$config.hidden = !showGrid;

              if (!mainGrid.$config.hidden) {
                /* restrict grid width due to min_width, max_width, min_grid_column_width */
                var grid_limits = mainGrid._getGridWidthLimits();
                if (grid_limits[0] && gantt.config.grid_width < grid_limits[0])
                  gantt.config.grid_width = grid_limits[0];
                if (grid_limits[1] && gantt.config.grid_width > grid_limits[1])
                  gantt.config.grid_width = grid_limits[1];
                if (mainTimeline && gantt.config.show_chart) {

                  mainGrid.$config.width = gantt.config.grid_width - 1;
                  if (!first) {
                    if (mainTimeline && !domHelpers.isChildOf(mainTimeline.$task, layout.$view)) {
                      // timeline is being displayed after being not visible, reset grid with from full screen
                      if (!mainGrid.$config.original_grid_width) {
                        var skinSettings = gantt.skins[gantt.skin];
                        if (skinSettings && skinSettings.config && skinSettings.config.grid_width) {
                          mainGrid.$config.original_grid_width = skinSettings.config.grid_width;
                        } else {
                          mainGrid.$config.original_grid_width = 0;
                        }
                      }
                      gantt.config.grid_width = mainGrid.$config.original_grid_width;
                      mainGrid.$parent.$config.width = gantt.config.grid_width;
                    } else {
                      mainGrid.$parent._setContentSize(mainGrid.$config.width, mainGrid.$config.height);
                      gantt.$layout._syncCellSizes(mainGrid.$parent.$config.group, gantt.config.grid_width);
                    }
                  } else {
                    mainGrid.$parent.$config.width = gantt.config.grid_width;
                    if (mainGrid.$parent.$config.group) {
                      gantt.$layout._syncCellSizes(mainGrid.$parent.$config.group, mainGrid.$parent.$config.width);
                    }
                  }
                } else {
                  if (mainTimeline && domHelpers.isChildOf(mainTimeline.$task, layout.$view)) {
                    // hiding timeline, remember grid with to restore it when timeline is displayed again
                    mainGrid.$config.original_grid_width = gantt.config.grid_width;
                  }
                  if (!first) {
                    mainGrid.$parent.$config.width = 0;
                  }
                }
              }

              first = false;
            });
            this._initScrollStateEvents(layout);
          },

          _initScrollStateEvents: function (layout) {
            gantt._getVerticalScrollbar = this.getVerticalScrollbar;
            gantt._getHorizontalScrollbar = this.getHorizontalScrollbar;

            var vertical = this.getVerticalScrollbar();
            var horizontal = this.getHorizontalScrollbar();
            if (vertical) {
              vertical.attachEvent("onScroll", function (oldPos, newPos, dir) {
                var scrollState = gantt.getScrollState();
                gantt.callEvent("onGanttScroll", [scrollState.x, oldPos, scrollState.x, newPos]);
              });
            }
            if (horizontal) {
              horizontal.attachEvent("onScroll", function (oldPos, newPos, dir) {
                var scrollState = gantt.getScrollState();
                gantt.callEvent("onGanttScroll", [oldPos, scrollState.y, newPos, scrollState.y]);
              });
            }

            layout.attachEvent("onResize", function () {
              if (vertical && !gantt.$scroll_ver) {
                gantt.$scroll_ver = vertical.$scroll_ver;
              }

              if (horizontal && !gantt.$scroll_hor) {
                gantt.$scroll_hor = horizontal.$scroll_hor;
              }
            });
          },

          _findGridResizer: function (layout, grid) {
            var resizers = layout.getCellsByType("resizer");

            var gridFirst = true;
            var gridResizer;
            for (var i = 0; i < resizers.length; i++) {
              var res = resizers[i];
              res._getSiblings();
              var prev = res._behind;
              var next = res._front;
              if (prev && prev.$content === grid || (prev.isChild && prev.isChild(grid))) {
                gridResizer = res;
                gridFirst = true;
                break;
              } else if (next && next.$content === grid || (next.isChild && next.isChild(grid))) {
                gridResizer = res;
                gridFirst = false;
                break;
              }
            }
            return {
              resizer: gridResizer,
              gridFirst: gridFirst
            };
          },

          onInitialized: function (layout) {
            var grid = gantt.$ui.getView("grid");

            var resizeInfo = this._findGridResizer(layout, grid);

            // expose grid resize events
            if (resizeInfo.resizer) {
              var gridFirst = resizeInfo.gridFirst,
                next = resizeInfo.resizer;
              var initialWidth;
              next.attachEvent("onResizeStart", function (prevCellWidth, nextCellWidth) {

                var grid = gantt.$ui.getView("grid");
                var viewCell = grid ? grid.$parent : null;
                if (viewCell) {
                  var limits = grid._getGridWidthLimits();

                  // min grid width is defined by min widths of its columns, unless grid has horizontal scroll
                  if (!grid.$config.scrollable)
                    viewCell.$config.minWidth = limits[0];

                  viewCell.$config.maxWidth = limits[1];
                }
                initialWidth = gridFirst ? prevCellWidth : nextCellWidth;
                return gantt.callEvent("onGridResizeStart", [initialWidth]);
              });
              next.attachEvent("onResize", function (newBehindSize, newFrontSize) {
                var newSize = gridFirst ? newBehindSize : newFrontSize;
                return gantt.callEvent("onGridResize", [initialWidth, newSize]);
              });
              next.attachEvent("onResizeEnd", function (oldBackSize, oldFrontSize, newBackSize, newFrontSize) {

                var oldSize = gridFirst ? oldBackSize : oldFrontSize;
                var newSize = gridFirst ? newBackSize : newFrontSize;
                var grid = gantt.$ui.getView("grid");
                var viewCell = grid ? grid.$parent : null;
                if (viewCell) {
                  viewCell.$config.minWidth = undefined;
                }
                var res = gantt.callEvent("onGridResizeEnd", [oldSize, newSize]);
                if (res) {
                  gantt.config.grid_width = newSize;
                }

                return res;
              });
            }

          },
          onDestroyed: function (timeline) {

          }
        };

      };
    })();

    return initializer;

    /***/
  }



  domHelpers = this.utilsService;

  addEventTarget(event, className, handler, root) {
    if (!this.eventHandlers[event][className]) {
      this.eventHandlers[event][className] = [];
    }

    this.eventHandlers[event][className].push({
      handler: handler,
      root: root
    });
  }

  callHandler(eventName, className, root, args) {
    var handlers = this.eventHandlers[eventName][className];
    if (handlers) {
      for (var i = 0; i < handlers.length; i++) {
        if (!(root || handlers[i].root) || handlers[i].root === root) {
          handlers[i].handler.apply(this, args);
        }
      }
    }
  }

  onClick(e) {
    e = e || window.event;
    var id = this.ganttObject.locate(e);

    var handlers = this.findEventHandlers(e, this.eventHandlers.click);
    var res = true;
    if (id !== null) {
      res = !this.ganttObject.checkEvent("onTaskClick") || this.ganttObject.callEvent("onTaskClick", [id, e]);
    } else {
      this.ganttObject.callEvent("onEmptyClick", [e]);
    }

    if (res) {
      var default_action = this.callEventHandlers(handlers, e, id);
      if (!default_action)
        return;

      if (id && this.ganttObject.getTask(id) && this.ganttObject.gantt.config.select_task && !this.ganttObject.gantt.config.multiselect) {
        this.ganttObject.selectTask(id);
      }
    }
  }

  onContextMenu(e) {
    e = e || window.event;
    var linkAttribute: any = this.commonService.config()

    // tslint:disable-next-line: one-variable-per-declaration
    let src = e.target || e.srcElement;
    let taskId = this.ganttObject.locate(src);
    let linkId = this.utilsService.locateAttribute(src, 'link_id');

    var res = !this.ganttObject.checkEvent("onContextMenu") || this.utilsService.callEvent("onContextMenu", [taskId, linkId, e], undefined);
    if (!res) {
      if (e.preventDefault)
        e.preventDefault();
      else
        e.returnValue = false;
    }
    return res;
  }

  findEventHandlers(e, hash) {
    var trg = e.target || e.srcElement;
    var handlers = [];
    while (trg) {
      var css = this.utilsService.getClassName(trg);
      if (css) {
        css = css.split(" ");
        for (var i = 0; i < css.length; i++) {
          if (!css[i]) continue;
          if (hash[css[i]]) {
            var delegateHandlers = hash[css[i]];

            for (var h = 0; h < delegateHandlers.length; h++) {
              if (delegateHandlers[h].root) {
                if (!this.utilsService.isChildOf(trg, delegateHandlers[h].root)) {
                  continue;
                }
              }
              handlers.push(delegateHandlers[h].handler);
            }
          }
        }
      }
      trg = trg.parentNode;
    }
    return handlers;
  }

  callEventHandlers(handlers, e, id) {
    var res = true;

    for (var i = 0; i < handlers.length; i++) {
      var handlerResult = handlers[i].call(this.ganttObject.gantt, e, id, e.target || e.srcElement);
      res = res && !(typeof handlerResult != "undefined" && handlerResult !== true);
    }

    return res;
  }

  gridResize() {

    function createResizer(gantt, grid) {
      return {
        init: function () { },
        doOnRender: function () { }
      };
    }

    return createResizer;

    /***/
  }

  mainGridInitializer() {

    var outerThis: UiService
    var utils = this.utilsService;
    var rowDnd = this.tasksGridDnd();
    var rowDndMarker = this.tasksGridDndMarker();

    var initializer = (function () {
      return function (gantt) {
        return {
          onCreated: function (grid) {
            grid.$config = utils.mixin(grid.$config, {
              bind: "task"
            });
            if (grid.$config.id == "grid") {
              this.extendGantt(grid);
              gantt.ext.inlineEditors = gantt.ext._inlineEditors.createEditors(grid);
              gantt.ext.inlineEditors.init();
            }

            this._mouseDelegates = outerThis.mouseEventContainer(gantt);
          },
          onInitialized: function (grid) {
            var config = grid.$getConfig();
            if (config.order_branch) {
              if (config.order_branch == "marker") {
                rowDndMarker.init(grid.$gantt, grid);
              } else {
                rowDnd.init(grid.$gantt, grid);
              }
            }

            this.initEvents(grid, gantt);
            if (grid.$config.id == "grid") {
              this.extendDom(grid);
            }
          },
          onDestroyed: function (grid) {
            if (grid.$config.id == "grid") {
              gantt.ext.inlineEditors.destructor();
            }
            this.clearEvents(grid, gantt);
          },

          initEvents: function (grid, gantt) {
            this._mouseDelegates.delegate("click", "gantt_row", gantt.bind(function (e, id, trg) {
              var config = grid.$getConfig();
              if (id !== null) {
                var task = this.getTask(id);
                if (config.scroll_on_click && !gantt._is_icon_open_click(e))
                  this.showDate(task.start_date);
                gantt.callEvent("onTaskRowClick", [id, trg]);
              }
            }, gantt), grid.$grid);

            this._mouseDelegates.delegate("click", "gantt_grid_head_cell", gantt.bind(function (e, id, trg) {
              var column = trg.getAttribute("data-column-id");

              if (!gantt.callEvent("onGridHeaderClick", [column, e]))
                return;

              var config = grid.$getConfig();

              if (column == "add") {
                var mouseEvents = gantt.$services.getService("mouseEvents");
                mouseEvents.callHandler("click", "gantt_add", grid.$grid, [e, config.root_id]);
                return;
              }

              if (config.sort) {
                var sorting_method = column,
                  conf;

                for (var i = 0; i < config.columns.length; i++) {
                  if (config.columns[i].name == column) {
                    conf = config.columns[i];
                    break;
                  }
                }

                if (conf && conf.sort !== undefined && conf.sort !== true) {
                  sorting_method = conf.sort;

                  if (!sorting_method) { // column sort property 'false', no sorting
                    return;
                  }
                }

                var sort = (this._sort && this._sort.direction && this._sort.name == column) ? this._sort.direction : "desc";
                // invert sort direction
                sort = (sort == "desc") ? "asc" : "desc";
                this._sort = {
                  name: column,
                  direction: sort
                };
                this.sort(sorting_method, sort == "desc");
              }
            }, gantt), grid.$grid);

            this._mouseDelegates.delegate("click", "gantt_add", gantt.bind(function (e, id, trg) {
              var config = grid.$getConfig();
              if (config.readonly) return;

              var item = {};
              this.createTask(item, id ? id : gantt.config.root_id);

              return false;
            }, gantt), grid.$grid);

          },

          clearEvents: function (grid, gantt) {
            this._mouseDelegates.destructor();
            this._mouseDelegates = null;
          },

          extendDom: function (grid) {
            gantt.$grid = grid.$grid;
            gantt.$grid_scale = grid.$grid_scale;
            gantt.$grid_data = grid.$grid_data;
          },
          extendGantt: function (grid) {
            gantt.getGridColumns = gantt.bind(grid.getGridColumns, grid);

            grid.attachEvent("onColumnResizeStart", function () {
              return gantt.callEvent("onColumnResizeStart", arguments);
            });
            grid.attachEvent("onColumnResize", function () {
              return gantt.callEvent("onColumnResize", arguments);
            });
            grid.attachEvent("onColumnResizeEnd", function () {
              return gantt.callEvent("onColumnResizeEnd", arguments);
            });

            grid.attachEvent("onColumnResizeComplete", function (columns, totalWidth) {
              gantt.config.grid_width = totalWidth;
            });
          }
        };
      };
    })();

    return initializer;

    /***/
  }

  tasksGridDnd() {

    var domHelpers = this.utilsService;

    function _init_dnd(gantt, grid) {
      var DnD = gantt.$services.getService("dnd");

      if (!grid.$config.bind || !gantt.getDatastore(grid.$config.bind)) {
        return;
      }

      function locate(e) {
        return domHelpers.locateAttribute(e, grid.$config.item_attribute);
      }

      function getStore() {
        return gantt.getDatastore(grid.$config.bind);
      }

      var dnd = new DnD(grid.$grid_data, { updates_per_second: 60 });
      if (gantt.defined(grid.$getConfig().dnd_sensitivity))
        dnd.config.sensitivity = grid.$getConfig().dnd_sensitivity;

      dnd.attachEvent("onBeforeDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);
        if (!el) return false;
        if (gantt.hideQuickInfo) gantt._hideQuickInfo();

        if (domHelpers.closest(e.target, ".gantt_grid_editor_placeholder")) {
          return false;
        }

        var id = el.getAttribute(grid.$config.item_attribute);

        var datastore = getStore();

        var task = datastore.getItem(id);

        if (gantt.isReadonly(task))
          return false;

        dnd.config.initial_open_state = task.$open;
        if (!gantt.callEvent("onRowDragStart", [id, e.target || e.srcElement, e])) {
          return false;
        }

      }, gantt));

      dnd.attachEvent("onAfterDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);
        dnd.config.marker.innerHTML = el.outerHTML;
        var element = dnd.config.marker.firstChild;
        if (element) {
          element.style.position = "static";
        }

        dnd.config.id = el.getAttribute(grid.$config.item_attribute);

        var store = getStore();

        var task = store.getItem(dnd.config.id);
        dnd.config.index = store.getBranchIndex(dnd.config.id);
        dnd.config.parent = task.parent;
        task.$open = false;
        task.$transparent = true;
        this.refreshData();
      }, gantt));

      dnd.lastTaskOfLevel = function (level) {
        var last_item = null;
        var store = getStore();
        var tasks = store.getItems();
        for (var i = 0, len = tasks.length; i < len; i++) {
          if (tasks[i].$level == level) {
            last_item = tasks[i];
          }
        }
        return last_item ? last_item.id : null;
      };
      dnd._getGridPos = gantt.bind(function (e) {
        var pos = domHelpers.elementPosition(grid.$grid_data);
        var store = getStore();
        // row offset
        var x = pos.x;
        var y = e.pos.y - 10;

        var config = grid.$getConfig();
        // prevent moving row out of grid_data container
        if (y < pos.y) y = pos.y;
        var gridHeight = store.countVisible() * config.row_height;
        if (y > pos.y + gridHeight - config.row_height) y = pos.y + gridHeight - config.row_height;

        pos.x = x;
        pos.y = y;
        return pos;
      }, gantt);
      dnd._getTargetY = gantt.bind(function (e) {
        var pos = domHelpers.elementPosition(grid.$grid_data);

        var y = e.pageY - pos.y + (grid.$state.scrollTop || 0);
        if (y < 0)
          y = 0;
        return y;
      }, gantt);
      dnd._getTaskByY = gantt.bind(function (y, dropIndex) {

        var config = grid.$getConfig(),
          store = getStore();

        y = y || 0;

        var index = Math.floor(y / config.row_height);
        index = dropIndex < index ? index - 1 : index;

        if (index > store.countVisible() - 1)
          return null;

        return store.getIdByIndex(index);
      }, gantt);
      dnd.attachEvent("onDragMove", gantt.bind(function (obj, e) {
        var dd = dnd.config;
        var pos = dnd._getGridPos(e);

        var config = grid.$getConfig(),
          store = getStore();

        // setting position of row
        dd.marker.style.left = pos.x + 10 + "px";
        dd.marker.style.top = pos.y + "px";

        // highlight row when mouseover
        var item = store.getItem(dnd.config.id);
        var targetY = dnd._getTargetY(e);
        var el = dnd._getTaskByY(targetY, store.getIndexById(item.id));

        if (!store.exists(el)) {
          el = dnd.lastTaskOfLevel(config.order_branch_free ? item.$level : 0);
          if (el == dnd.config.id) {
            el = null;
          }
        }

        function allowedLevel(next, item) {
          return (!(store.isChildOf(over.id, item.id)) && (next.$level == item.$level || config.order_branch_free));
        }

        if (store.exists(el)) {
          var over = store.getItem(el);

          if (store.getIndexById(over.id) * config.row_height + config.row_height / 2 < targetY) {
            //hovering over bottom part of item, check can be drop to bottom
            var index = store.getIndexById(over.id);
            var nextId = store.getNext(over.id);//adds +1 when hovering over placeholder
            var next = store.getItem(nextId);
            if (next) {
              if (next.id != item.id) {
                over = next; //there is a valid target
              }
              else {
                if (config.order_branch_free) {
                  if (!(store.isChildOf(item.id, over.id) && store.getChildren(over.id).length == 1))
                    return;
                  else {
                    store.move(item.id, store.getBranchIndex(over.id) + 1, store.getParent(over.id));
                    return;
                  }
                }
                else {
                  return;
                }
              }
            } else {
              //we at end of the list, check and drop at the end of list
              nextId = store.getIdByIndex(index);
              next = store.getItem(nextId);

              if (allowedLevel(next, item) && next.id != item.id) {
                store.move(item.id, -1, store.getParent(next.id));
                return;
              }
            }
          }
          else if (config.order_branch_free) {
            if (over.id != item.id && allowedLevel(over, item)) {
              if (!store.hasChild(over.id)) {
                over.$open = true;
                store.move(item.id, -1, over.id);
                return;
              }
              if (store.getIndexById(over.id) || config.row_height / 3 < targetY) return;
            }
          }
          //if item is on different level, check the one before it
          var index = store.getIndexById(over.id),
            prevId = store.getIdByIndex(index - 1);

          var prev = store.getItem(prevId);

          var shift = 1;
          while ((!prev || prev.id == over.id) && index - shift >= 0) {

            prevId = store.getIdByIndex(index - shift);
            prev = store.getItem(prevId);
            shift++;
          }

          if (item.id == over.id) return;
          //replacing item under cursor
          if (allowedLevel(over, item) && item.id != over.id) {
            store.move(item.id, 0, 0, over.id);

          } else if (over.$level == item.$level - 1 && !store.getChildren(over.id).length) {
            store.move(item.id, 0, over.id);

          } else if (prev && (allowedLevel(prev, item)) && (item.id != prev.id)) {
            store.move(item.id, -1, store.getParent(prev.id));

          }
        }
        return true;
      }, gantt));

      dnd.attachEvent("onDragEnd", gantt.bind(function () {
        var store = getStore();
        var task = store.getItem(dnd.config.id);
        task.$transparent = false;
        task.$open = dnd.config.initial_open_state;

        if (this.callEvent("onBeforeRowDragEnd", [dnd.config.id, dnd.config.parent, dnd.config.index]) === false) {
          store.move(dnd.config.id, dnd.config.index, dnd.config.parent);
          task.$drop_target = null;
        } else {
          this.callEvent("onRowDragEnd", [dnd.config.id, task.$drop_target]);
        }

        this.refreshData();
      }, gantt));
    }

    return {
      init: _init_dnd
    };

    /***/
  }

  tasksGridDndMarker() {

    var domHelpers = this.utilsService;
    var dropTarget = this.taskGridHelpers.dropTarget();
    var getLockedLevelTarget = this.taskGridHelpers.lockedLevel();
    var getMultiLevelTarget = this.taskGridHelpers.multiLevel();
    var higlighter = this.taskGridHelpers.highlight();

    function _init_dnd(gantt, grid) {
      var DnD = gantt.$services.getService("dnd");

      if (!grid.$config.bind || !gantt.getDatastore(grid.$config.bind)) {
        return;
      }

      function locate(e) {
        return domHelpers.locateAttribute(e, grid.$config.item_attribute);
      }

      var dnd = new DnD(grid.$grid_data, { updates_per_second: 60 });
      if (gantt.defined(grid.$getConfig().dnd_sensitivity))
        dnd.config.sensitivity = grid.$getConfig().dnd_sensitivity;

      dnd.attachEvent("onBeforeDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);
        if (!el) return false;
        if (gantt.hideQuickInfo) gantt._hideQuickInfo();
        if (domHelpers.closest(e.target, ".gantt_grid_editor_placeholder")) {
          return false;
        }

        var id = el.getAttribute(grid.$config.item_attribute);
        var datastore = grid.$config.rowStore;
        var task = datastore.getItem(id);

        if (gantt.isReadonly(task))
          return false;

        dnd.config.initial_open_state = task.$open;
        if (!gantt.callEvent("onRowDragStart", [id, e.target || e.srcElement, e])) {
          return false;
        }

      }, gantt));

      dnd.attachEvent("onAfterDragStart", gantt.bind(function (obj, e) {
        var el = locate(e);

        dnd.config.marker.innerHTML = el.outerHTML;
        var element = dnd.config.marker.firstChild;
        if (element) {
          dnd.config.marker.style.opacity = 0.4;
          element.style.position = "static";
          element.style.pointerEvents = "none";
        }

        dnd.config.id = el.getAttribute(grid.$config.item_attribute);

        var store = grid.$config.rowStore;

        var task = store.getItem(dnd.config.id);
        dnd.config.level = store.calculateItemLevel(task);
        dnd.config.drop_target = dropTarget.createDropTargetObject({
          targetParent: store.getParent(task.id),
          targetIndex: store.getBranchIndex(task.id),
          targetId: task.id,
          nextSibling: true
        });

        task.$open = false;
        task.$transparent = true;
        this.refreshData();
      }, gantt));

      function getTargetTaskId(e) {
        var y = domHelpers.getRelativeEventPosition(e, grid.$grid_data).y;
        var store = grid.$config.rowStore;

        y = y || 0;

        if (y < 0) {
          return store.$getRootId();
        }

        var index = Math.floor(y / grid.getItemHeight());

        if (index > store.countVisible() - 1)
          return store.$getRootId();

        return store.getIdByIndex(index);
      }

      function getDropPosition(e) {
        var targetTaskId = getTargetTaskId(e);
        var relTargetPos = null;
        var store = grid.$config.rowStore;
        var config = grid.$getConfig();
        var lockLevel = !config.order_branch_free;

        var eventTop = domHelpers.getRelativeEventPosition(e, grid.$grid_data).y;

        if (targetTaskId !== store.$getRootId()) {
          var rowTop = grid.getItemTop(targetTaskId);
          var rowHeight = grid.getItemHeight();
          relTargetPos = (eventTop - rowTop) / rowHeight;
        }

        var result;
        if (!lockLevel) {
          result = getMultiLevelTarget(dnd.config.id, targetTaskId, relTargetPos, eventTop, store);
        } else {
          result = getLockedLevelTarget(dnd.config.id, targetTaskId, relTargetPos, eventTop, store, dnd.config.level);
        }

        return result;
      }

      dnd.attachEvent("onDragMove", gantt.bind(function (obj, e) {
        var target = getDropPosition(e);

        if (!target ||
          gantt.callEvent("onBeforeRowDragMove", [dnd.config.id, target.targetParent, target.targetIndex]) === false) {
          target = dropTarget.createDropTargetObject(dnd.config.drop_target);
        }

        higlighter.highlightPosition(target, dnd.config, grid);
        dnd.config.drop_target = target;

        this.callEvent("onRowDragMove", [dnd.config.id, target.targetParent, target.targetIndex]);
        return true;
      }, gantt));

      dnd.attachEvent("onDragEnd", gantt.bind(function () {
        var store = grid.$config.rowStore;
        var task = store.getItem(dnd.config.id);

        higlighter.removeLineHighlight(dnd.config);

        task.$transparent = false;
        task.$open = dnd.config.initial_open_state;
        var target = dnd.config.drop_target;

        if (this.callEvent("onBeforeRowDragEnd", [dnd.config.id, target.targetParent, target.targetIndex]) === false) {
          task.$drop_target = null;
        } else {
          store.move(dnd.config.id, target.targetIndex, target.targetParent);
          this.callEvent("onRowDragEnd", [dnd.config.id, target.targetParent, target.targetIndex]);
        }
        store.refresh(task.id);
      }, gantt));
    }

    return {
      init: _init_dnd
    };

    /***/
  }


  onDoubleClick(e) {
    e = e || window.event;
    var id = this.ganttObject.locate(e);

    var handlers = this.findEventHandlers(e, this.eventHandlers.doubleclick);
    // when doubleclick fired not on task, id === null
    var res = !this.ganttObject.checkEvent("onTaskDblClick") || id === null || this.ganttObject.callEvent("onTaskDblClick", [id, e]);
    if (res) {
      var default_action = this.callEventHandlers(handlers, e, id);
      if (!default_action)
        return;

      if (id !== null && this.ganttObject.getTask(id)) {
        if (res && this.ganttObject.gantt.config.details_on_dblclick) {
          this.ganttObject.showLightbox(id);
        }
      }
    }
  }

  onMouseMove(e) {
    if (this.ganttObject.checkEvent("onMouseMove")) {
      var id = this.ganttObject.locate(e);
      this.commonService.config()._last_move_event = e;
      this.ganttObject.callEvent("onMouseMove", [id, e]);
    }
  }

  detach(eventName, className, handler, root) {
    if (this.eventHandlers[eventName] && this.eventHandlers[eventName][className]) {
      var handlers = this.eventHandlers[eventName];
      var elementHandlers = handlers[className];
      for (var i = 0; i < elementHandlers.length; i++) {
        if (elementHandlers[i].root == root) {
          elementHandlers.splice(i, 1);
          i--;
        }
      }
      if (!elementHandlers.length) {
        delete handlers[className];
      }

    }
  }


  reset(node?) {
    var domEvents: any = this.utilsService;

    domEvents.detachAll();

    if (node) {
      domEvents.attach(node, "click", this.onClick);
      domEvents.attach(node, "dblclick", this.onDoubleClick);
      domEvents.attach(node, "mousemove", this.onMouseMove);
      domEvents.attach(node, "contextmenu", this.onContextMenu);
    }
  }



  mouse() {

    var domHelpers = this.utilsService;


    var createMouseHandler = (function (domHelpers) {
      return function (gantt) {
        var eventHandlers = {
          "click": {},
          "doubleclick": {},
          "contextMenu": {}
        };

        function addEventTarget(event, className, handler, root) {
          if (!eventHandlers[event][className]) {
            eventHandlers[event][className] = [];
          }

          eventHandlers[event][className].push({
            handler: handler,
            root: root
          });
        }

        function callHandler(eventName, className, root, args) {
          var handlers = eventHandlers[eventName][className];
          if (handlers) {
            for (var i = 0; i < handlers.length; i++) {
              if (!(root || handlers[i].root) || handlers[i].root === root) {
                handlers[i].handler.apply(this, args);
              }
            }
          }
        }

        function onClick(e) {
          e = e || window.event;
          var id = gantt.locate(e);

          var handlers = findEventHandlers(e, eventHandlers.click);
          var res = true;
          if (id !== null) {
            res = !gantt.checkEvent("onTaskClick") || gantt.callEvent("onTaskClick", [id, e]);
          } else {
            gantt.callEvent("onEmptyClick", [e]);
          }

          if (res) {
            var default_action = callEventHandlers(handlers, e, id);
            if (!default_action)
              return;

            if (id && gantt.getTask(id) && gantt.config.select_task && !gantt.config.multiselect) {
              gantt.selectTask(id);
            }
          }
        }

        function onContextMenu(e) {
          e = e || window.event;
          var src = e.target || e.srcElement,
            taskId = gantt.locate(src),
            linkId = gantt.locate(src, gantt.config.link_attribute);

          var res = !gantt.checkEvent("onContextMenu") || gantt.callEvent("onContextMenu", [taskId, linkId, e]);
          if (!res) {
            if (e.preventDefault)
              e.preventDefault();
            else
              e.returnValue = false;
          }
          return res;
        }

        function findEventHandlers(e, hash) {
          var trg = e.target || e.srcElement;
          var handlers = [];
          while (trg) {
            var css = domHelpers.getClassName(trg);
            if (css) {
              css = css.split(" ");
              for (var i = 0; i < css.length; i++) {
                if (!css[i]) continue;
                if (hash[css[i]]) {
                  var delegateHandlers = hash[css[i]];

                  for (var h = 0; h < delegateHandlers.length; h++) {
                    if (delegateHandlers[h].root) {
                      if (!domHelpers.isChildOf(trg, delegateHandlers[h].root)) {
                        continue;
                      }
                    }
                    handlers.push(delegateHandlers[h].handler);
                  }
                }
              }
            }
            trg = trg.parentNode;
          }
          return handlers;
        }

        function callEventHandlers(handlers, e, id) {
          var res = true;

          for (var i = 0; i < handlers.length; i++) {
            var handlerResult = handlers[i].call(gantt, e, id, e.target || e.srcElement);
            res = res && !(typeof handlerResult != "undefined" && handlerResult !== true);
          }

          return res;
        }


        function onDoubleClick(e) {
          e = e || window.event;
          var id = gantt.locate(e);

          var handlers = findEventHandlers(e, eventHandlers.doubleclick);
          // when doubleclick fired not on task, id === null
          var res = !gantt.checkEvent("onTaskDblClick") || id === null || gantt.callEvent("onTaskDblClick", [id, e]);
          if (res) {
            var default_action = callEventHandlers(handlers, e, id);
            if (!default_action)
              return;

            if (id !== null && gantt.getTask(id)) {
              if (res && gantt.config.details_on_dblclick) {
                gantt.showLightbox(id);
              }
            }
          }
        }

        function onMouseMove(e) {
          if (gantt.checkEvent("onMouseMove")) {
            var id = gantt.locate(e);
            gantt._last_move_event = e;
            gantt.callEvent("onMouseMove", [id, e]);
          }
        }

        function detach(eventName, className, handler, root) {
          if (eventHandlers[eventName] && eventHandlers[eventName][className]) {
            var handlers = eventHandlers[eventName];
            var elementHandlers = handlers[className];
            for (var i = 0; i < elementHandlers.length; i++) {
              if (elementHandlers[i].root == root) {
                elementHandlers.splice(i, 1);
                i--;
              }
            }
            if (!elementHandlers.length) {
              delete handlers[className];
            }

          }
        }

        var domEvents = gantt._createDomEventScope();

        function reset(node?) {

          domEvents.detachAll();

          if (node) {
            domEvents.attach(node, "click", onClick);
            domEvents.attach(node, "dblclick", onDoubleClick);
            domEvents.attach(node, "mousemove", onMouseMove);
            domEvents.attach(node, "contextmenu", onContextMenu);
          }
        }



        return {
          reset: reset,
          global: function (event, classname, handler) {
            addEventTarget(event, classname, handler, null);
          },
          delegate: addEventTarget,
          detach: detach,
          callHandler: callHandler,
          onDoubleClick: onDoubleClick,
          onMouseMove: onMouseMove,
          onContextMenu: onContextMenu,
          onClick: onClick,
          destructor: function () {
            reset();
            eventHandlers = null;
            domEvents = null;
          }

        };
      };

    })(domHelpers);


    return {
      init: createMouseHandler
    };

    /***/
  }

  // mouseEventContainer() {

  mouseEventContainer(gantt) {
    var events = [];

    return {
      delegate: function (event, className, handler, root) {
        events.push([event, className, handler, root]);

        var helper = gantt.$services.getService("mouseEvents");
        helper.delegate(event, className, handler, root);
      },
      destructor: function () {
        var mouseEvents = gantt.$services.getService("mouseEvents");
        for (var i = 0; i < events.length; i++) {
          var h = events[i];
          mouseEvents.detach(h[0], h[1], h[2], h[3]);
        }
        events = [];
      }
    };
  }

  // return create;

  /***/
  // }

  rowPositionMixin() {

    function createMixin() {
      var topCache = {};
      return {
        _resetTopPositionHeight: function () {
          topCache = {};
        },

        /**
         * Get top coordinate by row index (order)
         * @param {number} index
         */
        getRowTop: function (index) {
          return index * this.$getConfig().row_height;
        },

        /**
         * Get top coordinate by item id
         * @param {*} task_id
         */
        getItemTop: function (taskId) {
          if (this.$config.rowStore) {
            if (topCache[taskId] !== undefined) {
              return topCache[taskId];
            }
            var store = this.$config.rowStore;
            if (!store) return 0;

            var itemIndex = store.getIndexById(taskId);

            if (itemIndex === -1 && store.getParent && store.exists(taskId)) {
              var parentId = store.getParent(taskId);
              if (store.exists(parentId)) {
                // if task is not found in list - maybe it's parent is a split task and we should use parents index instead
                var parent = store.getItem(parentId);
                if (this.$gantt.isSplitTask(parent)) {
                  return this.getRowTop(store.getIndexById(parent.id));
                }
              }
            }
            topCache[taskId] = this.getRowTop(itemIndex);
            return topCache[taskId];
          } else {
            return 0;
          }

        }
      };
    }

    return createMixin;

    /***/
  }

  uiFactory() {

    var utils = this.utilsService

    var uiFactory = function createFactory(gantt) {
      var views = {};

      function ui(cell, parentView) {
        var content;
        var view = "cell";
        if (cell.view) {
          view = "viewcell";
        } else if (cell.resizer) {
          view = "resizer";
        }
        else if (cell.rows || cell.cols) {
          view = "layout";
        }
        else if (cell.views) {
          view = "multiview";
        }

        content = createView.call(this, view, null, cell, parentView);
        return content;
      }

      var createdViews = {};

      function createView(name, parent, config, parentView) {
        var creator = views[name];

        if (!creator || !creator.create)
          return false;

        if (name == "resizer" && !config.mode) {
          if (parentView.$config.cols) {
            config.mode = "x";
          } else {
            config.mode = "y";
          }
        }

        if (name == "viewcell" && config.view == "scrollbar" && !config.scroll) {
          if (parentView.$config.cols) {
            config.scroll = "y";
          } else {
            config.scroll = "x";
          }
        }

        var config = utils.copy(config);

        if (!config.id && !createdViews[config.view]) {
          config.id = config.view;
        }

        if (config.id && !config.css) {
          config.css = config.id + "_cell";
        }

        var view = new creator.create(parent, config, this, gantt);

        if (creator.configure) {
          creator.configure(view);
        }

        this.configurable(view, parentView);
        if (!view.$id) {
          view.$id = config.id || gantt.uid();
        }

        if (!view.$parent && typeof parent == "object") {
          view.$parent = parent;
        }
        if (!view.$config) {
          view.$config = config;
        }

        if (createdViews[view.$id]) {
          view.$id = gantt.uid();
        }

        createdViews[view.$id] = view;

        return view;
      }

      function reset() {
        createdViews = {};
      }

      function register(name, viewConstructor, configure?) {
        views[name] = { create: viewConstructor, configure: configure };
      }

      function getView(id) {
        return createdViews[id];
      }

      var factory = {
        initUI: ui,
        reset: reset,
        registerView: register,
        createView: createView,
        getView: getView
      };

      return factory;
    };

    return {
      createFactory: uiFactory
    };



    /***/
  }
}

export class Configurable {

  utils: UtilsService;
  parentConfig;
  parentTemplates;
  $gantt: any;
  $config: any;

  constructor(parentView?) {
    this.$getConfig(parentView);
    this.$getTemplates(parentView);
  }

  $getConfig(parentView?) {
    if (!this.parentConfig) {
      this.parentConfig = parentView ? parentView.$getConfig() : this.$gantt.config;
    }
    if (!this.$config.config) {
      return this.parentConfig;
    } else {
      return extendSettings.call(this, "config", this.parentConfig);
    }
  }

  $getTemplates(parentView?) {
    if (!this.parentTemplates) {
      this.parentTemplates = parentView ? parentView.$getTemplates() : this.$gantt.templates;
    }
    if (!this.$config.templates) {
      return this.parentTemplates;
    } else {
      return extendSettings.call(this, "templates", this.parentTemplates);
    }
  }

}

export class ViewSettings {
  utils: UtilsService;

  constructor(config) {
    this.utils.mixin(this, config, true);
  }
}

export class extendSettings {
  $config: any;

  constructor(store, parentSettings) {
    var own = this.$config[store];

    if (own) {
      if (own instanceof ViewSettings) {
        // tslint:disable-next-line: no-unused-expression
        // return own;
        own;
      } else {
        ViewSettings.prototype = parentSettings;
        this.$config[store] = new ViewSettings(own);
        return this.$config[store];
      }
    } else {
      return parentSettings;
    }
  }
}

export class Grid {
  $config: any;
  $gantt: any;
  $parent: any;
  $state: any;

  domHelpers: UtilsService;
  utils: UtilsService;
  eventable: UtilsService;
  outerthis: UiService
  ganttObject: GanttObjectService
  gridResize = this.outerthis.gridResize();
  $grid: any;
  $grid_scale: any;
  $grid_data: any;
  _renderHeaderResizers: () => void;
  _mouseDelegates: { delegate: (event: any, className: any, handler: any, root: any) => void; destructor: () => void; };
  _taskLayers: any[];
  $rowsPlaceholder: any;
  _staticBgHandler: any;
  window: any;

  constructor(parent, config, factory, gantt) {
    this.$config = this.utils.mixin({}, config || {});
    this.$gantt = gantt;
    this.$parent = parent;
    this.eventable.eventable();
    this.$state = {};
    this.utils.mixin(this, this.outerthis.rowPositionMixin());
  }

  init(container) {
    var gantt = this.$gantt;
    var gridAriaAttr = gantt._waiAria.gridAttrString();
    var gridDataAriaAttr = gantt._waiAria.gridDataAttrString();


    container.innerHTML = "<div class='gantt_grid' style='height:inherit;width:inherit;' " + gridAriaAttr + "></div>";
    this.$grid = container.childNodes[0];

    this.$grid.innerHTML = "<div class='gantt_grid_scale' " +
      gantt._waiAria.gridScaleRowAttrString() + "></div><div class='gantt_grid_data' " + gridDataAriaAttr + "></div>";

    this.$grid_scale = this.$grid.childNodes[0];
    this.$grid_data = this.$grid.childNodes[1];

    var attr = new Configurable().$getConfig()[this.$config.bind + "_attribute"];
    if (!attr && this.$config.bind) {
      attr = this.$config.bind + "_id";
    }
    this.$config.item_attribute = attr || null;

    if (!this.$config.layers) {
      var layers = this._createLayerConfig();
      this.$config.layers = layers;
    }

    var resizer = this.gridResize(gantt, this);
    resizer.init();
    this._renderHeaderResizers = resizer.doOnRender;
    this._mouseDelegates = this.outerthis.mouseEventContainer(gantt);

    this._addLayers(this.$gantt);
    this._initEvents();
    this.ganttObject.callEvent("onReady", []);
    //this.refresh();
  }

  _validateColumnWidth(column, property) {
    // user can set {name:"text", width:"200",...} for some reason,
    // check and convert it to number when possible
    var value = column[property];
    if (value && value != "*") {
      var gantt = this.$gantt;
      var numericWidth = value * 1;
      if (isNaN(numericWidth)) {
        gantt.assert(false, "Wrong " + property + " value of column " + column.name);
      } else {
        column[property] = numericWidth;
      }
    }
  }

  setSize(width, height) {
    this.$config.width = this.$state.width = width;
    this.$config.height = this.$state.height = height;

    // TODO: maybe inherit and override in a subclass instead of extending here

    var columns = this.getGridColumns(),
      innerWidth = 0;

    for (var i = 0, l = columns.length; i < l; i++) {
      this._validateColumnWidth(columns[i], "min_width");
      this._validateColumnWidth(columns[i], "max_width");
      this._validateColumnWidth(columns[i], "width");

      innerWidth += columns[i].width * 1;
    }

    var outerWidth;
    if (isNaN(innerWidth) || !this.$config.scrollable) {
      outerWidth = this._setColumnsWidth(width + 1);
      innerWidth = outerWidth;
    }

    if (this.$config.scrollable) {
      this.$grid_scale.style.width = innerWidth + "px";
      this.$grid_data.style.width = innerWidth + "px";
    } else {
      this.$grid_scale.style.width = "inherit";
      this.$grid_data.style.width = "inherit";
    }
    this.$config.width -= 1;

    var config = new Configurable().$getConfig();
    if (outerWidth !== width) {
      config.grid_width = outerWidth;
      this.$config.width = outerWidth - 1;
    }

    var dataHeight = Math.max(this.$state.height - config.scale_height, 0);
    this.$grid_data.style.height = dataHeight + "px";
    this.refresh();
  }

  getSize() {

    var config = new Configurable().$getConfig();

    var store = this.$config.rowStore;

    var contentHeight = store ? config.row_height * store.countVisible() : 0,
      contentWidth = this._getGridWidth();

    var size = {
      x: this.$state.width,
      y: this.$state.height,
      contentX: this.isVisible() ? contentWidth : 0,
      contentY: this.isVisible() ? (config.scale_height + contentHeight) : 0,
      scrollHeight: this.isVisible() ? contentHeight : 0,
      scrollWidth: this.isVisible() ? contentWidth : 0
    };

    return size;
  }

  _bindStore() {
    if (this.$config.bind) {
      var rowStore = this.$gantt.getDatastore(this.$config.bind);
      this.$config.rowStore = rowStore;
      if (rowStore && !rowStore._gridCacheAttached) {
        var self = this;
        rowStore._gridCacheAttached = rowStore.attachEvent("onBeforeFilter", function () {
          self._resetTopPositionHeight();
        });
      }
    }
  }

  _unbindStore() {
    if (this.$config.bind) {
      var rowStore = this.$gantt.getDatastore(this.$config.bind);
      if (rowStore._gridCacheAttached) {
        rowStore.detachEvent(rowStore._gridCacheAttached);
        rowStore._gridCacheAttached = false;
      }
    }
  }

  _resetTopPositionHeight() {
    const topCache = {};
  }

  refresh() {
    this._bindStore();

    this._resetTopPositionHeight();
    this._initSmartRenderingPlaceholder();

    this._calculateGridWidth();
    this._renderGridHeader();
  }

  getViewPort() {
    var scrollLeft = this.$config.scrollLeft || 0;
    var scrollTop = this.$config.scrollTop || 0;
    var height = this.$config.height || 0;
    var width = this.$config.width || 0;
    return {
      y: scrollTop,
      y_end: scrollTop + height,
      x: scrollLeft,
      x_end: scrollLeft + width,
      height: height,
      width: width
    };
  }

  scrollTo(left, top) {
    if (!this.isVisible())
      return;

    var scrolled = false;

    this.$config.scrollTop = this.$config.scrollTop || 0;
    this.$config.scrollLeft = this.$config.scrollLeft || 0;

    if (left * 1 == left) {
      this.$config.scrollLeft = this.$state.scrollLeft = this.$grid.scrollLeft = left;
      scrolled = true;
    }

    var config = new Configurable().$getConfig();
    if (top * 1 == top) {
      this.$config.scrollTop = this.$state.scrollTop = this.$grid_data.scrollTop = top;
      scrolled = true;
    }

    if (scrolled) {
      this.ganttObject.callEvent("onScroll", [this.$config.scrollLeft, this.$config.scrollTop]);
    }
  }

  getColumnIndex(name) {
    var columns = new Configurable().$getConfig().columns;

    for (var i = 0; i < columns.length; i++) {
      if (columns[i].name == name) {
        return i;
      }
    }
    return null;
  }

  getColumn(name) {
    var index = this.getColumnIndex(name);
    if (index === null) {
      return null;
    }
    return new Configurable().$getConfig().columns[index];
  }

  getGridColumns() {
    var config = new Configurable().$getConfig();
    return config.columns.slice();
  }

  isVisible() {
    if (this.$parent && this.$parent.$config) {
      return !this.$parent.$config.hidden;
    } else {
      return this.$grid.offsetWidth;
    }
  }

  getItemHeight() {
    var config = new Configurable().$getConfig();
    return config.row_height;
  }

  _createLayerConfig() {
    var gantt = this.$gantt;
    var self = this;
    var layers = [
      {
        renderer: gantt.$ui.layers.gridLine(),
        container: this.$grid_data,
        filter: [function () {
          return self.isVisible();
        }]
      }
    ];
    return layers;
  }

  _addLayers(gantt) {
    if (!this.$config.bind)
      return;

    this._taskLayers = [];

    var self = this;

    var layers = this.$gantt.$services.getService("layers");
    var taskRenderer = layers.getDataRender(this.$config.bind);
    var getViewPort = function () {
      return self.getViewPort();
    };
    if (!taskRenderer) {
      taskRenderer = layers.createDataRender({
        name: this.$config.bind,
        defaultContainer: function () { return self.$grid_data; }
      });
    }

    var taskLayers = this.$config.layers;
    for (var i = 0; taskLayers && i < taskLayers.length; i++) {
      var layer = taskLayers[i];
      layer.host = this;
      layer.getViewPort = getViewPort;
      var bar_layer = taskRenderer.addLayer(layer);
      this._taskLayers.push(bar_layer);
      this.ganttObject.attachEvent("onScroll", (function (layer) {
        return function () {
          if (layer.requestUpdate) {
            layer.requestUpdate();
          }
        };
      })(layer));
    }

    this._bindStore();

    this._initSmartRenderingPlaceholder();
  }

  _refreshPlaceholderOnStoreUpdate(id) {
    var config = new Configurable().$getConfig(),
      store = this.$config.rowStore;

    if (!store || id !== null || !this.isVisible() || !config.smart_rendering) {
      return;
    }

    var contentHeight;
    if (this.$config.scrollY) {
      var scroll = this.$gantt.$ui.getView(this.$config.scrollY);
      if (scroll)
        contentHeight = scroll.getScrollState().scrollSize;
    }

    if (!contentHeight) {
      contentHeight = store ? config.row_height * store.countVisible() : 0;
    }

    if (contentHeight) {
      if (this.$rowsPlaceholder && this.$rowsPlaceholder.parentNode) {
        this.$rowsPlaceholder.parentNode.removeChild(this.$rowsPlaceholder);
      }

      var placeholder = this.$rowsPlaceholder = document.createElement("div");
      placeholder.style.visibility = "hidden";
      placeholder.style.height = contentHeight + "px";
      placeholder.style.width = "1px";
      this.$grid_data.appendChild(placeholder);
    }
  }

  _initSmartRenderingPlaceholder() {
    var store = this.$config.rowStore;
    if (!store) {
      return;
    } else {
      this._initSmartRenderingPlaceholder = function () { };
    }
    this._staticBgHandler = store.attachEvent("onStoreUpdated", this.utils.bind(this._refreshPlaceholderOnStoreUpdate, this));
  }

  _initEvents() {
    var gantt = this.$gantt;
    this._mouseDelegates.delegate("click", "gantt_close", gantt.bind(function (e, id, trg) {
      var store = this.$config.rowStore;
      if (!store) return true;

      var target = this.domHelpers.locateAttribute(e, this.$config.item_attribute);
      if (target) {
        store.close(target.getAttribute(this.$config.item_attribute));

      }
      return false;
    }, this), this.$grid);

    this._mouseDelegates.delegate("click", "gantt_open", gantt.bind(function (e, id, trg) {
      var store = this.$config.rowStore;
      if (!store) return true;

      var target = this.domHelpers.locateAttribute(e, this.$config.item_attribute);
      if (target) {
        store.open(target.getAttribute(this.$config.item_attribute));

      }
      return false;
    }, this), this.$grid);
  }

  _clearLayers(gantt) {
    var layers = this.$gantt.$services.getService("layers");
    var taskRenderer = layers.getDataRender(this.$config.bind);

    if (this._taskLayers) {
      for (var i = 0; i < this._taskLayers.length; i++) {
        taskRenderer.removeLayer(this._taskLayers[i]);
      }
    }

    this._taskLayers = [];
  }

  _getColumnWidth(column, config, width) {
    var min_width = column.min_width || config.min_grid_column_width;
    var new_width = Math.max(width, min_width || 10);
    if (column.max_width)
      new_width = Math.min(new_width, column.max_width);
    return new_width;
  }

  // return min and max possible grid width according to restricts
  _getGridWidthLimits() {
    var config = new Configurable().$getConfig(),
      columns = this.getGridColumns(),
      min_limit = 0,
      max_limit = 0;

    for (var i = 0; i < columns.length; i++) {
      min_limit += columns[i].min_width ? columns[i].min_width : config.min_grid_column_width;
      if (max_limit !== undefined) {
        max_limit = columns[i].max_width ? (max_limit + columns[i].max_width) : undefined;
      }
    }

    return [min_limit, max_limit];
  }

  // resize columns to get total newWidth, starting from columns[start_index]
  _setColumnsWidth(newWidth, start_index?) {
    var config = new Configurable().$getConfig();
    var columns = this.getGridColumns(),
      columns_width = 0,
      final_width = newWidth;


    start_index = !this.window.isNaN(start_index) ? start_index : -1;

    for (var i = 0, l = columns.length; i < l; i++) {
      columns_width += columns[i].width * 1;
    }

    if (this.window.isNaN(columns_width)) {
      this._calculateGridWidth();
      columns_width = 0;
      for (var i = 0, l = columns.length; i < l; i++) {
        columns_width += columns[i].width * 1;
      }
    }

    var extra_width = final_width - columns_width;

    var start_width = 0;
    for (var i = 0; i < start_index + 1; i++) {
      start_width += columns[i].width;
    }

    columns_width -= start_width;

    for (let i = start_index + 1; i < columns.length; i++) {

      var col = columns[i];
      var share = Math.round(extra_width * (col.width / columns_width));

      // columns have 2 additional restrict fields - min_width & max_width that are set by user
      if (extra_width < 0) {
        if (col.min_width && col.width + share < col.min_width)
          share = col.min_width - col.width;
        else if (!col.min_width && config.min_grid_column_width && col.width + share < config.min_grid_column_width)
          share = config.min_grid_column_width - col.width;
      } else if (col.max_width && col.width + share > col.max_width)
        share = col.max_width - col.width;

      columns_width -= col.width;
      col.width += share;
      extra_width -= share;

    }

    var iterator = extra_width > 0 ? 1 : -1;
    while ((extra_width > 0 && iterator === 1) || (extra_width < 0 && iterator === -1)) {
      var curExtra = extra_width;
      for (i = start_index + 1; i < columns.length; i++) {
        var new_width = columns[i].width + iterator;

        if (new_width == this._getColumnWidth(columns[i], config, new_width)) {
          extra_width -= iterator;
          columns[i].width = new_width;
        }

        if (!extra_width)
          break;

      }

      if (curExtra == extra_width)
        break;
    }

    // if impossible to resize the right-side columns, resize the start column
    if (extra_width && start_index > -1) {
      var new_width = columns[start_index].width + extra_width;
      if (new_width == this._getColumnWidth(columns[start_index], config, new_width))
        columns[start_index].width = new_width;
    }

    //if (this.callEvent("onGridResizeEnd", [config.grid_width, final_width]) === false)
    //	return;

    return this._getColsTotalWidth();
  }

  _getColsTotalWidth() {
    var columns = this.getGridColumns();
    var cols_width = 0;

    for (var i = 0; i < columns.length; i++) {
      var v = parseFloat(columns[i].width);
      if (this.window.isNaN(v)) {
        return false;
      }
      cols_width += v;
    }
    return cols_width;
  }

  _calculateGridWidth() {
    var config = new Configurable().$getConfig();
    var columns = this.getGridColumns();
    var cols_width = 0;
    var unknown = [];
    var width = [];

    for (var i = 0; i < columns.length; i++) {
      var v = parseFloat(columns[i].width);
      if (this.window.isNaN(v)) {
        v = config.min_grid_column_width || 10;
        unknown.push(i);
      }
      width[i] = v;
      cols_width += v;
    }
    var gridWidth = this._getGridWidth() + 1;
    if (config.autofit || unknown.length) {
      var diff = gridWidth - cols_width;
      // TODO: logic may be improved for proportional changing of width
      if (config.autofit) {
        // delta must be added for all columns
        for (var i = 0; i < width.length; i++) {
          var delta = Math.round(diff / (width.length - i));
          width[i] += delta;
          var new_width = this._getColumnWidth(columns[i], config, width[i]);

          if (new_width != width[i]) {
            delta = new_width - width[i];
            width[i] = new_width;
          }
          diff -= delta;
        }
      } else if (unknown.length) {
        // there are several columns with undefined width
        for (var i = 0; i < unknown.length; i++) {
          var delta = Math.round(diff / (unknown.length - i)); // no float values, just integer
          var index = unknown[i];
          width[index] += delta;
          var new_width = this._getColumnWidth(columns[index], config, width[index]);
          if (new_width != width[index]) {
            delta = new_width - width[index];
            width[index] = new_width;
          }
          diff -= delta;
        }
      }

      for (var i = 0; i < width.length; i++) {
        columns[i].width = width[i];
      }
    } else {
      var changed = (gridWidth != cols_width);
      this.$config.width = cols_width - 1;
      config.grid_width = cols_width;
      if (changed) {
        this.$parent._setContentSize(this.$config.width, this.$config.height);
        //				this.$parent.$config.width = cols_width;
      }
    }

  }

  _renderGridHeader() {
    var gantt = this.$gantt;
    var config = new Configurable().$getConfig();
    var locale = this.$gantt.locale;
    var templates = this.$gantt.templates;

    var columns = this.getGridColumns();
    if (config.rtl) {
      columns = columns.reverse();
    }
    var cells = [];
    var width = 0,
      labels = locale.labels;

    var lineHeigth = config.scale_height - 1;

    for (var i = 0; i < columns.length; i++) {
      var last = i == columns.length - 1;
      var col = columns[i];

      // ensure columns have non-empty names
      if (!col.name) {
        col.name = gantt.uid() + "";
      }

      var colWidth = col.width * 1;

      var gridWidth = this._getGridWidth();
      if (last && gridWidth > width + colWidth)
        col.width = colWidth = gridWidth - width;
      width += colWidth;
      var sort = (gantt._sort && col.name == gantt._sort.name) ? ("<div class='gantt_sort gantt_" + gantt._sort.direction + "'></div>") : "";
      var cssClass = ["gantt_grid_head_cell",
        ("gantt_grid_head_" + col.name),
        (last ? "gantt_last_cell" : ""),
        templates.grid_header_class(col.name, col)].join(" ");

      var style = "width:" + (colWidth - (last ? 1 : 0)) + "px;";
      var label = (col.label || labels["column_" + col.name] || labels[col.name]);
      label = label || "";

      var ariaAttrs = gantt._waiAria.gridScaleCellAttrString(col, label);

      var cell = "<div class='" + cssClass + "' style='" + style + "' " + ariaAttrs + " data-column-id='" + col.name + "' column_id='" + col.name + "'>" + label + sort + "</div>";
      cells.push(cell);
    }
    this.$grid_scale.style.height = (config.scale_height) + "px";
    this.$grid_scale.style.lineHeight = lineHeigth + "px";
    //this.$grid_scale.style.width = "inherit";
    this.$grid_scale.innerHTML = cells.join("");

    if (this._renderHeaderResizers) {
      this._renderHeaderResizers();
    }
  }

  _getGridWidth() {
    // TODO: refactor/remove/comment some of _getGridWidth/this.$config.width/this.$state.width, it's not clear what they do
    return this.$config.width;
  }

  destructor() {
    this._clearLayers(this.$gantt);
    if (this._mouseDelegates) {
      this._mouseDelegates.destructor();
      this._mouseDelegates = null;
    }
    this._unbindStore();
    this.$grid = null;
    this.$grid_scale = null;
    this.$grid_data = null;
    this.$gantt = null;
    if (this.$config.rowStore) {
      this.$config.rowStore.detachEvent(this._staticBgHandler);
      this.$config.rowStore = null;
    }

    this.ganttObject.callEvent("onDestroy", []);
    this.ganttObject.detachAllEvents();
  }

}


export class GanttLayers {

  renderService: RenderService;
  ganttObject: GanttObjectService;
  taskLayers;
  linkLayers;
  factory;
  constructor() { }

  createLayerFactory = this.renderService.layerEngine();

  createLayerEngine(gantt) {
    this.factory = this.createLayerFactory(gantt);
  };

  getDataRender(name) {
    return this.ganttObject.gantt.$services.getService("layer:" + name) || null;
  }

  createDataRender(config) {
    var name = config.name,
      defaultContainer = config.defaultContainer,
      previusSiblingContainer = config.defaultContainerSibling;

    var layers = this.factory.createGroup(
      defaultContainer,
      previusSiblingContainer,
      function (itemId, item) {
        if (layers.filters) {
          for (var i = 0; i < layers.filters.length; i++) {
            if (layers.filters[i](itemId, item) === false) {
              return false;
            }
          }
        } else {
          return true;
        }
      }
    );

    this.ganttObject.gantt.$services.setService("layer:" + name, function () {
      return layers;
    });

    this.ganttObject.attachEvent("onGanttReady", function () {
      layers.addLayer(); // init layers on start
    });

    return layers;
  }

  init() {
    var ganttObject: GanttObjectService
    this.taskLayers = this.createDataRender({
      name: "task",
      defaultContainer() {
        if (ganttObject.gantt.$task_data) {
          return ganttObject.gantt.$task_data;
        } else if (ganttObject.gantt.$ui.getView("timeline")) {
          return ganttObject.gantt.$ui.getView("timeline").$task_data;
        }
      },
      defaultContainerSibling() {
        if (ganttObject.gantt.$task_links) {
          return ganttObject.gantt.$task_links;
        } else if (ganttObject.gantt.$ui.getView("timeline")) {
          return ganttObject.gantt.$ui.getView("timeline").$task_links;
        }
      },
      filter(item) {

      }
    });

    this.linkLayers = this.createDataRender({
      name: "link",
      defaultContainer() {
        if (ganttObject.gantt.$task_data) {
          return ganttObject.gantt.$task_data;
        } else if (ganttObject.gantt.$ui.getView("timeline")) {
          return ganttObject.gantt.$ui.getView("timeline").$task_data;
        }
      }
    });
  }

  addTaskLayer(config) {
    return this.taskLayers.addLayer(config);
  }

  /*getTaskLayer: function(id){
    return this.taskLayers.getLayer(id);
  }*/

  _getTaskLayers() {
    return this.taskLayers.getLayers();
  }
  removeTaskLayer(id) {
    this.taskLayers.removeLayer(id);
  }
  /*eachTaskLayer: function(code){
    this.taskLayers.eachLayer(code);
  }*/
  _clearTaskLayers() {
    this.taskLayers.clear();
  }
  addLinkLayer(config) {
    return this.linkLayers.addLayer(config);
  }
  /*getLinkLayer: function(id){
    return this.linkLayers.getLayer(id);
  }*/
  _getLinkLayers() {
    return this.linkLayers.getLayers();
  }
  removeLinkLayer(id) {
    this.linkLayers.removeLayer(id);
  }
  /*eachLinkLayer: function(code){
    this.linkLayers.eachLayer(code);
  }*/
  _clearLinkLayers() {
    this.linkLayers.clear();
  }

  // return createLayerEngine;

  /***/
}
