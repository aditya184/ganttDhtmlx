import { TestBed } from '@angular/core/testing';

import { DataprocessorService } from './dataprocessor.service';

describe('DataprocessorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataprocessorService = TestBed.get(DataprocessorService);
    expect(service).toBeTruthy();
  });
});
