import { Injectable } from '@angular/core';
import { UtilsService } from './utils/utils.service';
import { LocaleService } from './locale/locale.service';
import { TasksGridHelpersService } from './core/ui/grid/tasks-grid-helpers/tasks-grid-helpers.service';
import { CommonService } from './core/common/common.service';
import { SkinsService } from './css/skins/skins.service';
import { UiService } from './core/ui/ui.service';
// import { PowerArray } from './core/datastore/datastore.service';
// import { DataRange } from './core/core.service';

@Injectable({
  providedIn: 'root'
})

export class GanttObjectService {
  boxAttribute = "data-dhxbox";
  _dhx_msg_cfg = null;
  eventHost;
  _lightbox: any;
  _lightbox_type: string;
  _lightbox_template: any;
  _cover: any;
  $parentProperty: any;
  _branches: any;
  pull: any;
  $data: any;
  _max_date: any;
  _min_date: any;
  $services: any;
  _tasks: any;
  config: any;
  getState: any;
  _custom_lightbox: any;
  _lightbox_id: any;
  _tasks_dnd: any;
  $layout: any;
  $grid_data: any;
  _posFromDateCache: any;
  _sort: boolean;

  constructor(private utilsService: UtilsService, private localeService: LocaleService, private ganttObject: GanttObjectService) { }

  messagebox: any = {
    seed: (new Date()).valueOf(),
    uid: this.utilsService.uid,
    expire: 4000,
    keyboard: true,
    position: "top",
    pull: {},
    timers: {}
  }



  modalityObj: any = {}
  gantt: any = {
    locale: {
      date: {
        month_full: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        month_short: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        day_full: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        day_short: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      labels: {
        new_task: "New task",
        icon_save: "Save",
        icon_cancel: "Cancel",
        icon_details: "Details",
        icon_edit: "Edit",
        icon_delete: "Delete",
        confirm_closing: "",//Your changes will be lost, are you sure?
        confirm_deleting: "Task will be deleted permanently, are you sure?",
        section_description: "Description",
        section_time: "Time period",
        section_type: "Type",

        /* grid columns */
        column_wbs: "WBS",
        column_text: "Task name",
        column_start_date: "Start time",
        column_duration: "Duration",
        column_add: "",

        /* link confirmation */
        link: "Link",
        confirm_link_deleting: "will be deleted",
        link_start: " (start)",
        link_end: " (end)",

        type_task: "Task",
        type_project: "Project",
        type_milestone: "Milestone",

        minutes: "Minutes",
        hours: "Hours",
        days: "Days",
        weeks: "Week",
        months: "Months",
        years: "Years",

        /* message popup */
        message_ok: "OK",
        message_cancel: "Cancel",

        /* constraints */
        section_constraint: "Constraint",
        constraint_type: "Constraint type",
        constraint_date: "Constraint date",
        asap: "As Soon As Possible",
        alap: "As Late As Possible",
        snet: "Start No Earlier Than",
        snlt: "Start No Later Than",
        fnet: "Finish No Earlier Than",
        fnlt: "Finish No Later Than",
        mso: "Must Start On",
        mfo: "Must Finish On",

        /* resource control */
        resources_filter_placeholder: "type to filter",
        resources_filter_label: "hide empty"
      }
    }
  }

  form_blocks: any = {
    getTimePicker(sns, hidden) {
      let outerThis: GanttObjectService
      let html = "";
      let cfg = this.config;
      let i;
      let options;
      let ariaAttrs;
      let readonly;
      let display;
      let settings = {
        first: 0,
        last: 24 * 60,
        date: this.date.date_part(new Date(outerThis.gantt._min_date.valueOf())),
        timeFormat: outerThis.getTimeFormat(sns)
      };

      // map: default order => real one
      sns._time_format_order = { size: 0 };

      if (outerThis.gantt.config.limit_time_select) {
        settings.first = 60 * cfg.first_hour;
        settings.last = 60 * cfg.last_hour + 1;
        settings.date.setHours(cfg.first_hour);
      }

      for (i = 0; i < settings.timeFormat.length; i++) {
        // adding spaces between selects
        if (i > 0) {
          html += " ";
        }

        options = outerThis.getHtmlTimePickerOptions(sns, i, settings);

        if (options) {
          ariaAttrs = outerThis.lightboxSelectAttrString(settings.timeFormat[i]);
          readonly = sns.readonly ? "disabled='disabled'" : "";
          display = hidden ? " style='display:none' " : "";
          html += "<select " + readonly + display + ariaAttrs + ">" + options + "</select>";
        }
      }
      return html;
    },
    getTimePickerValue(selects, config, offset) {
      let outerThis: GanttObjectService
      let map = config._time_format_order;
      let needSetTime = outerThis.utilsService.defined(map[3]);

      let time;
      let hours = 0;
      let minutes = 0;

      let mapOffset = offset || 0;

      if (needSetTime) {
        time = parseInt(selects[map[3] + mapOffset].value, 10);
        hours = Math.floor(time / 60);
        minutes = time % 60;
      }
      return new Date(selects[map[2] + mapOffset].value, selects[map[1] + mapOffset].value, selects[map[0] + mapOffset].value, hours, minutes);
    },

    _fill_lightbox_select(s, i, d, map) {
      let outerThis: GanttObjectService;
      s[i + map[0]].value = d.getDate();
      s[i + map[1]].value = d.getMonth();
      s[i + map[2]].value = d.getFullYear();
      if (outerThis.utilsService.defined(map[3])) {
        let v = d.getHours() * 60 + d.getMinutes();
        v = Math.round(v / outerThis._get_timepicker_step()) * outerThis._get_timepicker_step();
        let input = s[i + map[3]];
        input.value = v;
        //in case option not shown
        input.setAttribute("data-value", v);
      }
    },
    // template: new TemplateControl(),
    // textarea: new TextareaControl(),
    // select: new SelectControl(),
    // time: new TimeControl(),
    // duration: new DurationControl(),
    // parent: new ParentControl(),
    // radio: new RadioControl(),
    // checkbox: new CheckboxControl(),
    // resources: new ResourcesControl(),
    // constraint: new ConstraintControl()
  }

  createEventStorage(obj) {
    var dhx_catch = [];
    var z: any = function () {
      var res = true;
      for (var i = 0; i < dhx_catch.length; i++) {
        if (dhx_catch[i]) {
          var zr = dhx_catch[i].apply(obj, arguments);
          res = res && zr;
        }
      }
      return res;
    };
    z.addEvent = function (ev) {
      if (typeof (ev) == "function")
        return dhx_catch.push(ev) - 1;
      return false;
    };
    z.removeEvent = function (id) {
      dhx_catch[id] = null;
    };
    return z;
  }

  locate(e) {
    var trg = this.utilsService.getTargetNode(e);

    //ignore empty cells
    var className = this.utilsService.getClassName(trg);
    if ((className || "").indexOf("gantt_task_cell") >= 0) return null;

    var targetAttribute = arguments[1] || this.gantt.config.task_attribute;

    var node = this.utilsService.locateAttribute(trg, targetAttribute);
    if (node) {
      return node.getAttribute(targetAttribute);
    } else {
      return null;
    }
  }

  attachEvent(name, catcher, callObj?) {
    name = 'ev_' + name.toLowerCase();
    if (!this.eventHost[name])
      this.eventHost[name] = this.createEventStorage(callObj || this);

    return (name + ':' + this.eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
  };

  attachAll(callback, callObj) {
    this.attachEvent('listen_all', callback, callObj);
  }

  checkEvent(name) {
    return (!!this.eventHost['ev_' + name.toLowerCase()]);
  }

  detachEvent(id) {
    if (id) {
      var list = id.split(':');//get EventName and ID
      var eventName = list[0];
      var eventId = list[1];

      if (this.eventHost[eventName]) {
        this.eventHost[eventName].removeEvent(eventId); //remove event
      }
    }
  }

  detachAllEvents() {
    for (var name in this.eventHost) {
      if (name.indexOf("ev_") === 0)
        delete this.eventHost[name];
    }
  }

  callEvent(name, arg0, callObj?) {
    if (this.eventHost._silent_mode) return true;

    var handlerName = 'ev_' + name.toLowerCase();

    if (this.eventHost['ev_listen_all']) {
      this.eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
    }

    if (this.eventHost[handlerName])
      return this.eventHost[handlerName].apply(callObj || this, arg0);
    return true;
  }

  extends() {

    return function (d, b) {
      for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };

    /***/
  }

  callback(config, result) {
    var usercall = config.callback;
    this.modalBoxHide(config.box);

    this._dhx_msg_cfg = config.box = null;
    if (usercall)
      usercall(result);
  }

  modal_key(e) {
    if (this._dhx_msg_cfg) {
      e = e || event;
      var code = e.which || e.keyCode; // event.keyCode
      var preventDefault = false;

      if (this.messagebox.keyboard) {
        if (code == 13 || code == 32) {
          // default behavior is to confirm/submit popup on space/enter
          // if browser focus is set on button element - do button click instead of default behavior
          var target = e.target || e.srcElement;
          if (this.utilsService.getClassName(target).indexOf("gantt_popup_button") > -1 && target.click) {
            target.click();
          } else {
            this.callback(this._dhx_msg_cfg, true);
            preventDefault = true;
          }
        }

        if (code == 27) {
          this.callback(this._dhx_msg_cfg, false);
          preventDefault = true;
        }
      }

      if (preventDefault) {
        if (e.preventDefault)
          e.preventDefault();
        return !(e.cancelBubble = true);
      }
      return;
    }
  }

  // gantt.event(document, "keydown", modal_key, true);

  modality(mode) {
    if (!this.modalityObj.cover) {
      this.modalityObj.cover = document.createElement("div");
      //necessary for IE only
      this.modalityObj.cover.onkeydown = this.modal_key;
      this.modalityObj.cover.className = "dhx_modal_cover";
      document.body.appendChild(this.modalityObj.cover);
    }

    this.modalityObj.cover.style.display = mode ? "inline-block" : "none";
  }

  button(text, className, result) {
    var buttonAriaAttrs //= gantt._waiAria.messageButtonAttrString(text);
    var name = className.toLowerCase().replace(/ /g, "_");
    var button_css = "gantt_" + name + "_button" + " dhtmlx_" + name + "_button"; // dhtmlx_ok_button, dhtmlx_click_me_button
    return "<div " + buttonAriaAttrs + " class='gantt_popup_button dhtmlx_popup_button " + button_css + "' data-result='" + result + "' result='" + result + "' ><div>" + text + "</div></div>";
  }

  messageonclick(text) {
    this.messageBoxhide(text.id);
    text = null;
  }

  info(text) {
    if (!this.messagebox.area) {
      this.messagebox.area = document.createElement("div");
      this.messagebox.area.className = "gantt_message_area dhtmlx_message_area";
      this.messagebox.area.style[this.messagebox.position] = "5px";
      document.body.appendChild(this.messagebox.area);
    }

    this.messageBoxhide(text.id);
    var message = document.createElement("div");
    message.innerHTML = "<div>" + text.text + "</div>";
    message.className = "gantt-info dhtmlx-info gantt-" + text.type + " dhtmlx-" + text.type;
    this.messageonclick(text);

    // gantt._waiAria.messageInfoAttr(message);

    if (this.messagebox.position == "bottom" && this.messagebox.area.firstChild)
      this.messagebox.area.insertBefore(message, this.messagebox.area.firstChild);
    else
      this.messagebox.area.appendChild(message);

    if (text.expire > 0)
      this.messagebox.timers[text.id] = window.setTimeout(function () {
        this.messagebox.hide(text.id);
      }, text.expire);

    this.messagebox.pull[text.id] = message;
    message = null;

    return text.id;
  }

  getFirstDefined(...args) {
    var values = [].slice.apply(arguments, [0]);

    for (var i = 0; i < values.length; i++) {
      if (values[i]) {
        return values[i];
      }
    }

  }

  _boxStructure(config, ok, cancel) {
    var outerThis: GanttObjectService;
    var box = document.createElement("div");

    var contentId = this.utilsService.uid();
    // gantt._waiAria.messageModalAttr(box, contentId);


    box.className = " gantt_modal_box dhtmlx_modal_box gantt-" + config.type + " dhtmlx-" + config.type;
    box.setAttribute(this.boxAttribute, '1');

    var inner = '';

    if (config.width)
      box.style.width = config.width;
    if (config.height)
      box.style.height = config.height;
    if (config.title)
      inner += '<div class="gantt_popup_title dhtmlx_popup_title">' + config.title + '</div>';
    inner += '<div class="gantt_popup_text dhtmlx_popup_text" id="' + contentId + '"><span>' + (config.content ? '' : config.text) + '</span></div><div  class="gantt_popup_controls dhtmlx_popup_controls">';
    if (ok)
      inner += this.button(this.getFirstDefined(config.ok, this.localeService.locale.labels.message_ok, "OK"), "ok", true);
    if (cancel)
      inner += this.button(this.getFirstDefined(config.cancel, this.localeService.locale.labels.message_cancel, "Cancel"), "cancel", false);

    if (config.buttons) {
      for (var i = 0; i < config.buttons.length; i++) {
        var btn = config.buttons[i];
        if (typeof btn == "object") {
          // Support { label:"Save", css:"main_button", value:"save" }
          var label = btn.label;
          var css = btn.css || ("gantt_" + btn.label.toLowerCase() + "_button dhtmlx_" + btn.label.toLowerCase() + "_button");
          var value = btn.value || i;
          inner += this.button(label, css, value);
        } else {
          inner += this.button(btn, btn, i);
        }
      }
    }

    inner += '</div>';
    box.innerHTML = inner;

    if (config.content) {
      var node = config.content;
      if (typeof node == "string")
        node = document.getElementById(node);
      if (node.style.display == 'none')
        node.style.display = "";
      box.childNodes[config.title ? 1 : 0].appendChild(node);
    }

    box.onclick = function (e: Event) {
      e = e || event;
      var source: any = e.target || e.srcElement;
      if (!source.className) source = source.parentNode;
      if (source.className.split(" ")[0] == "gantt_popup_button") {
        var result = source.getAttribute("data-result");
        result = (result == "true") || (result == "false" ? false : result);
        outerThis.callback(config, result);
      }
    };
    config.box = box;
    if (ok || cancel)
      this._dhx_msg_cfg = config;

    return box;
  }

  _createBox(config, ok, cancel) {
    var box = config.tagName ? config : this._boxStructure(config, ok, cancel);

    if (!config.hidden)
      this.modality(true);
    document.body.appendChild(box);
    var x = Math.abs(Math.floor(((window.innerWidth || document.documentElement.offsetWidth) - box.offsetWidth) / 2));
    var y = Math.abs(Math.floor(((window.innerHeight || document.documentElement.offsetHeight) - box.offsetHeight) / 2));
    if (config.position == "top")
      box.style.top = "-3px";
    else
      box.style.top = y + 'px';
    box.style.left = x + 'px';
    //necessary for IE only
    box.onkeydown = this.modal_key;

    this.modalBoxFocus(box);

    if (config.hidden)
      this.modalBoxHide(box);

    this.callEvent("onMessagePopup", [box]);
    return box;
  }

  alertPopup(config) {
    return this._createBox(config, true, false);
  }

  confirmPopup(config) {
    return this._createBox(config, true, true);
  }

  boxPopup(config) {
    return this._createBox(config, false, false);
  }

  box_params(text, type, callback) {
    if (typeof text != "object") {
      if (typeof type == "function") {
        callback = type;
        type = "";
      }
      text = { text: text, type: type, callback: callback };
    }
    return text;
  }

  params(text, type, expire, id) {
    if (typeof text != "object")
      text = { text: text, type: type, expire: expire, id: id };
    text.id = text.id || this.utilsService.uid();
    text.expire = text.expire || this.messagebox.expire;
    return text;
  }

  alertBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "confirm";
    return this.alertPopup(text);
  }

  confirmBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "alert";
    return this.confirmPopup(text);
  }

  modalBox() {
    var text = this.box_params.apply(this, arguments);
    text.type = text.type || "alert";
    return this.boxPopup(text);
  }

  modalBoxHide(node) {
    while (node && node.getAttribute && !node.getAttribute(this.boxAttribute))
      node = node.parentNode;
    if (node) {
      node.parentNode.removeChild(node);
      this.modality(false);

      this.utilsService.callEvent("onAfterMessagePopup", [node], undefined);
    }
  }

  modalBoxFocus(node) {
    setTimeout(function () {
      var focusable = this.utilsService.getFocusableNodes(node);
      if (focusable.length) {
        if (focusable[0].focus) focusable[0].focus();
      }
    }, 1);
  }

  messageBox(text, type?, expire?, id?) {
    text = this.params.apply(this, arguments);
    text.type = text.type || "info";

    var subtype = text.type.split("-")[0];
    switch (subtype) {
      case "alert":
        return this.alertPopup(text);
      case "confirm":
        return this.confirmPopup(text);
      case "modalbox":
        return this.boxPopup(text);
      default:
        return this.info(text);
    }
  }

  messageBoxhideAll() {
    for (var key in this.messagebox.pull)
      this.messageBoxhide(key);
  }

  messageBoxhide(id) {
    var obj = this.messagebox.pull[id];
    if (obj && obj.parentNode) {
      window.setTimeout(function () {
        obj.parentNode.removeChild(obj);
        obj = null;
      }, 2000);
      obj.className += " hidden";

      if (this.messagebox.timers[id])
        window.clearTimeout(this.messagebox.timers[id]);
      delete this.messagebox.pull[id];
    }
  }

  getTask(id) {
    this.assert(id, "Invalid argument for gantt.getTask");
    var task = this.$data.tasksStore.getItem(id);
    this.assert(task, "Task not found id=" + id);
    return task;
  }

  selectTask(id) {
    var store = this.$data.tasksStore;
    if (!this.gantt.config.select_task)
      return false;
    if (id) {

      store.select(id);
    }
    return store.getSelectedId();
  }

  assert(check, message) {
    if (!check) {
      if (this.gantt.show_errors && this.gantt.callEvent("onError", [message], undefined) !== false) {
        this.gantt.messageBox(message, "error", -1);

        // eslint-disable-next-line no-debugger
        // debugger;
      }
    }
  }

  showLightbox(id) {
    if (!id || this.isReadonly(this.getTask(id))) return;
    if (!this.callEvent("onBeforeLightbox", [id])) return;

    var task = this.getTask(id);

    var box = this.getLightbox(this.getTaskType(task.type));
    this._center_lightbox(box);
    this.showCover();
    this._fill_lightbox(id, box);

    this.lightboxVisibleAttr(box);

    this.callEvent("onLightbox", [id]);
  }

  _fill_lightbox(id, box) {
    var task = this.getTask(id);
    this._set_lightbox_values(task, box);
  }

  _set_lightbox_values(data, box) {
    var task = data;
    var s = box.getElementsByTagName("span");
    var lightboxHeader = [];
    if (this.gantt.templates.lightbox_header) {
      lightboxHeader.push("");
      lightboxHeader.push(this.gantt.templates.lightbox_header(task.start_date, task.end_date, task));
      s[1].innerHTML = "";
      s[2].innerHTML = this.gantt.templates.lightbox_header(task.start_date, task.end_date, task);
    } else {
      lightboxHeader.push(this.gantt.templates.task_time(task.start_date, task.end_date, task));
      lightboxHeader.push(String(this.gantt.templates.task_text(task.start_date, task.end_date, task) || "").substr(0, 70)); //IE6 fix
      s[1].innerHTML = this.gantt.templates.task_time(task.start_date, task.end_date, task);
      s[2].innerHTML = String(this.gantt.templates.task_text(task.start_date, task.end_date, task) || "").substr(0, 70); //IE6 fix
    }
    s[1].innerHTML = lightboxHeader[0];
    s[2].innerHTML = lightboxHeader[1];

    this.lightboxHeader(box, lightboxHeader.join(" "));

    var sns = this._get_typed_lightbox_config(this.getLightboxType());
    for (var i = 0; i < sns.length; i++) {
      var section = sns[i];

      if (!this.form_blocks[section.type]) {
        continue;//skip incorrect sections, same check is done during rendering
      }


      var node = document.getElementById(section.id).nextSibling;
      var block = this.form_blocks[section.type];
      var map_to = this.gantt._resolve_default_mapping(sns[i]);
      var value = this.utilsService.defined(task[map_to]) ? task[map_to] : section.default_value;
      block.set_value.call(this.gantt, node, value, task, section);

      if (section.focus)
        block.focus.call(this.gantt, node);
    }
    if (data.id)
      this.gantt._lightbox_id = data.id;
  }

  showCover() {
    let document: any
    if (this._cover) return;
    this._cover = document.createElement("DIV");
    this._cover.className = "gantt_cal_cover";
    var _document_height = ((document.height !== undefined) ? document.height : document.body.offsetHeight);
    var _scroll_height = ((document.documentElement) ? document.documentElement.scrollHeight : 0);
    this._cover.style.height = Math.max(_document_height, _scroll_height) + "px";
    document.body.appendChild(this._cover);
  }

  _center_lightbox(box) {
    if (box) {
      box.style.display = "block";

      var scroll_top = window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop;
      var scroll_left = window.pageXOffset || document.body.scrollLeft || document.documentElement.scrollLeft;

      var view_height = window.innerHeight || document.documentElement.clientHeight;

      if (scroll_top) // if vertical scroll on window
        box.style.top = Math.round(scroll_top + Math.max((view_height - box.offsetHeight) / 2, 0)) + "px";
      else // vertical scroll on body
        box.style.top = Math.round(Math.max(((view_height - box.offsetHeight) / 2), 0) + 9) + "px"; // +9 for compatibility with auto tests

      // not quite accurate but used for compatibility reasons
      if (document.documentElement.scrollWidth > document.body.offsetWidth) // if horizontal scroll on the window
        box.style.left = Math.round(scroll_left + (document.body.offsetWidth - box.offsetWidth) / 2) + "px";
      else // horizontal scroll on the body
        box.style.left = Math.round((document.body.offsetWidth - box.offsetWidth) / 2) + "px";
    }
  }

  isReadonly(item) {
    if (item && item[this.gantt.config.editable_property]) {
      return false;
    } else {
      return (item && item[this.gantt.config.readonly_property]) || this.gantt.config.readonly;
    }
  }

  getLightboxType() {
    return this.getTaskType(this._lightbox_type);
  }

  getTaskType(type) {
    return "task";
  };

  _is_lightbox_timepicker() {
    var s = this._get_typed_lightbox_config(undefined);
    for (var i = 0; i < s.length; i++)
      if (s[i].name == "time" && s[i].type == "time")
        return true;
    return false;
  }

  getTimeFormat(sns) {
    var scale;
    var unit;
    var result;

    if (sns.time_format) return sns.time_format;

    // default order
    result = ["%d", "%m", "%Y"];
    scale = this.getScale();
    unit = scale ? scale.unit : this.gantt.config.duration_unit;
    if (this.utilsService.getSecondsInUnit(unit) < this.utilsService.getSecondsInUnit("day")) {
      result.push("%H:%i");
    }
    return result;
  }

  getScale() {
    return this._tasks;
  }

  getHtmlTimePickerOptions(sns, index, settings) {
    var range;
    var offset;
    var start_year;
    var end_year;
    var i;
    var time;
    var diff;
    var tdate;
    var html = "";

    switch (settings.timeFormat[index]) {
      case "%Y":
        sns._time_format_order[2] = index;
        sns._time_format_order.size++;
        //year

        if (sns.year_range) {
          if (!isNaN(sns.year_range)) {
            range = sns.year_range;
          } else if (sns.year_range.push) {
            // if
            start_year = sns.year_range[0];
            end_year = sns.year_range[1];
          }
        }

        range = range || 10;
        offset = offset || Math.floor(range / 2);
        start_year = start_year || settings.date.getFullYear() - offset;
        end_year = end_year || start_year + range;

        for (i = start_year; i < end_year; i++)
          html += "<option value='" + (i) + "'>" + (i) + "</option>";
        break;
      case "%m":
        sns._time_format_order[1] = index;
        sns._time_format_order.size++;
        //month
        for (i = 0; i < 12; i++)
          html += "<option value='" + i + "'>" + this.gantt.locale.date.month_full[i] + "</option>";
        break;
      case "%d":
        sns._time_format_order[0] = index;
        sns._time_format_order.size++;
        //days
        for (i = 1; i < 32; i++)
          html += "<option value='" + i + "'>" + i + "</option>";
        break;
      case "%H:%i":
        //  var last = 24*60, first = 0;
        sns._time_format_order[3] = index;
        sns._time_format_order.size++;
        //hours
        i = settings.first;
        tdate = settings.date.getDate();
        sns._time_values = [];

        while (i < settings.last) {
          time = this.gantt.templates.time_picker(settings.date);
          html += "<option value='" + i + "'>" + time + "</option>";
          sns._time_values.push(i);
          settings.date.setTime(settings.date.valueOf() + this._get_timepicker_step() * 60 * 1000);
          diff = (settings.date.getDate() != tdate) ? 1 : 0; // moved or not to the next day
          i = diff * 24 * 60 + settings.date.getHours() * 60 + settings.date.getMinutes();
        }
        break;
      default:
        break;
    }
    return html;
  }

  _is_chart_visible(gantt) {
    var timeline = gantt.$ui.getView("timeline");
    if (timeline && timeline.isVisible()) {
      return true;
    } else {
      return false;
    }
  }

  _get_timepicker_step() {
    if (this.config.round_dnd_dates) {
      var step;
      if (this._is_chart_visible(this)) {
        var scale = this.getScale();
        step = (this.utilsService.getSecondsInUnit(scale.unit) * scale.step) / 60;//timepicker step is measured in minutes
      }

      if (!step || step >= 60 * 24) {
        step = this.config.time_step;
      }
      return step;
    }
    return this.config.time_step;
  }

  _get_typed_lightbox_config(type) {
    if (type === undefined) {
      type = this.getLightboxType();
    }

    var field = this._get_type_name.call(this, type);

    if (this.gantt.config.lightbox[field + "_sections"]) {
      return this.gantt.config.lightbox[field + "_sections"];
    } else {
      return this.gantt.config.lightbox.sections;
    }
  }

  _init_dnd_events() {
    this.utilsService.event(document.body, "mousemove", this.gantt._move_while_dnd, undefined);
    this.utilsService.event(document.body, "mouseup", this.gantt._finish_dnd, undefined);
    this._init_dnd_events = (() => {
    });
  }

  getLightbox(type?) {
    let lightboxDiv;
    let fullWidth;
    let html;
    let sns;
    let ds;
    let classNames = "";

    if (type === undefined)
      type = this.getLightboxType();

    if (!this._lightbox || this.getLightboxType() != this.getTaskType(type)) {
      this._lightbox_type = this.getTaskType(type);
      lightboxDiv = document.createElement("div");
      classNames = "gantt_cal_light";
      fullWidth = this._is_lightbox_timepicker();

      if (this.gantt.config.wide_form || fullWidth)
        classNames += " gantt_cal_light_wide";

      if (fullWidth) {
        this.gantt.config.wide_form = true;
        classNames += " gantt_cal_light_full";
      }

      lightboxDiv.className = classNames;

      lightboxDiv.style.visibility = "hidden";
      html = this._lightbox_template;

      html += this.getHtmlButtons(this.gantt.config.buttons_left, false);
      html += this.getHtmlButtons(this.gantt.config.buttons_right, true);

      lightboxDiv.innerHTML = html;

      this.lightboxAttr(lightboxDiv);

      if (this.gantt.config.drag_lightbox) {
        lightboxDiv.firstChild.onmousedown = this.gantt._ready_to_dnd;
        lightboxDiv.firstChild.onselectstart = function () {
          return false;
        };
        lightboxDiv.firstChild.style.cursor = "pointer";
        this._init_dnd_events();
      }

      document.body.insertBefore(lightboxDiv, document.body.firstChild);
      this._lightbox = lightboxDiv;

      sns = this._get_typed_lightbox_config(type);
      html = this._render_sections(sns);

      ds = lightboxDiv.querySelector("div.gantt_cal_larea");
      ds.innerHTML = html;

      this.bindLabelsToInputs(sns);

      //sizes
      this.resizeLightbox();

      this._init_lightbox_events();
      lightboxDiv.style.display = "none";
      lightboxDiv.style.visibility = "visible";
    }
    return this._lightbox;
  }

  bindLabelsToInputs(sns) {
    var section;
    var label;
    var labelBlock;
    var inputBlock;
    var input;
    var i;

    for (i = 0; i < sns.length; i++) {
      section = sns[i];
      labelBlock = document.getElementById(section.id);

      if (!section.id || !labelBlock) continue;

      label = labelBlock.querySelector("label");
      inputBlock = labelBlock.nextSibling;

      if (!inputBlock) continue;

      input = inputBlock.querySelector("input, select, textarea");
      if (input) {
        input.id = input.id || "input_" + this.utilsService.uid();
        section.inputId = input.id;
        label.setAttribute("for", section.inputId);
      }
    }
  }

  _resolve_default_mapping(section) {
    var mapping = section.map_to;
    var time_controls = { "time": true, "time_optional": true, "duration": true, "duration_optional": true };
    if (time_controls[section.type]) {
      if (section.map_to == "auto") {
        mapping = { start_date: "start_date", end_date: "end_date", duration: "duration" };
      } else if (typeof (section.map_to) === "string") {
        mapping = { start_date: section.map_to };
      }
    } else if (section.type === "constraint") {
      if (!section.map_to || typeof (section.map_to) === "string") {
        mapping = { constraint_type: "constraint_type", constraint_date: "constraint_date" };
      }
    }

    return mapping;
  }

  getLightboxValues() {
    var task = {};

    if (this.isTaskExists(this.gantt._lightbox_id)) {
      task = this.utilsService.mixin({}, this.getTask(this.gantt._lightbox_id));
    }

    var sns = this._get_typed_lightbox_config(undefined);
    for (var i = 0; i < sns.length; i++) {
      var node: any = document.getElementById(sns[i].id);
      node = (node ? node.nextSibling : node);
      var block = this.form_blocks[sns[i].type];
      if (!block) continue;
      var res = block.get_value.call(this, node, task, sns[i]);
      var map_to = this._resolve_default_mapping(sns[i]);
      if (typeof map_to == "string" && map_to != "auto") {
        task[map_to] = res;
      } else if (typeof map_to == "object") {
        for (var property in map_to) {
          if (map_to[property])
            task[map_to[property]] = res[property];
        }
      }
    }
    return task;
  };

  _save_lightbox() {
    var task: any = this.getLightboxValues();
    if (!this.callEvent("onLightboxSave", [this.gantt._lightbox_id, task, !!task.$new]))
      return;

    if (task.$new) {
      delete task.$new;
      this.addTask(task, task.parent, this.getTaskIndex(task.id));
    } else if (this.isTaskExists(task.id)) {
      this.utilsService.mixin(this.getTask(task.id), task, true);
      this.refreshTask(task.id);
      this.updateTask(task.id);
    }
    this.refreshData();

    // TODO: do we need any blockable events here to prevent closing lightbox?
    this.hideLightbox();
  }

  updateTask(id, item?) {
    if (!this.utilsService.defined(item)) item = this.getTask(id);
    this.$data.tasksStore.updateItem(id, item);
    if (this.isTaskExists(id))
      this.refreshTask(id);
  }

  isTaskVisible(id) {
    if (!this.isTaskExists(id))
      return false;

    var task = this.getTask(id);

    var taskStart = task.start_date ? task.start_date.valueOf() : null;
    var taskEnd = task.end_date ? task.end_date.valueOf() : null;

    // tslint:disable-next-line: max-line-length
    if (!(this.gantt._isAllowedUnscheduledTask(task) || (taskStart && taskEnd && taskStart <= this._max_date.valueOf() && taskEnd >= this._min_date.valueOf()))) {
      return false;
    }

    return !!(this.gantt.getGlobalTaskIndex(id) >= 0);
  }

  refreshLink(linkId) {
    this.$data.linksStore.refresh(linkId, !!this.getState.drag_id);// do quick refresh during drag and drop
  }

  refreshTask(taskId, refresh_links?) {
    var task = this.getTask(taskId);
    if (task && this.isTaskVisible(taskId)) {

      this.$data.tasksStore.refresh(taskId, !!this.getState.drag_id);// do quick refresh during drag and drop

      if (refresh_links !== undefined && !refresh_links)
        return;
      for (var i = 0; i < task.$source.length; i++) {
        this.refreshLink(task.$source[i]);
      }
      for (var i = 0; i < task.$target.length; i++) {
        this.refreshLink(task.$target[i]);
      }
    } else if (this.isTaskExists(taskId) && this.isTaskExists(this.getParent(taskId))) {
      this.refreshTask(this.getParent(taskId));
    }

  }

  resetLightbox() {
    if (this._lightbox && !this._custom_lightbox)
      this._lightbox.parentNode.removeChild(this._lightbox);
    this._lightbox = null;
    this.hideCover();
  }

  getTaskIndex(id) {
    return this.$data.tasksStore.getBranchIndex(id);
  }

  isTaskExists(id) {
    if (!this.$data || !this.$data.tasksStore) {
      return false;
    }
    return this.$data.tasksStore.exists(id);
  }

  addTask(item, parent, index) {
    if (!this.utilsService.defined(item.id))
      item.id = this.utilsService.uid();

    if (!this.utilsService.defined(parent)) parent = this.getParent(item) || 0;
    if (!this.isTaskExists(parent)) parent = this.gantt.config.root_id;
    this.setParent(item, parent);

    return this.$data.tasksStore.addItem(item, index, parent);
  }

  setParent(item, new_pid, silent?) {
    this._setParentInner(item, new_pid, silent);

    item[this.$parentProperty] = new_pid;
  }

  _setParentInner(item, new_pid, silent) {
    if (!silent) {
      if (item.hasOwnProperty("$rendered_parent")) {
        this._move_branch(item, item.$rendered_parent, new_pid);
      } else {
        this._move_branch(item, item[this.$parentProperty], new_pid);
      }
    }
  }

  _replace_branch_child(node, old_id, new_id?) {
    var branch = this.getChildren(node);
    if (branch && node !== undefined) {
      var newbranch = new PowerArray().$create();
      for (var i = 0; i < branch.length; i++) {
        if (branch[i] != old_id)
          newbranch.push(branch[i]);
        else if (new_id)
          newbranch.push(new_id);
      }
      this._branches[node] = newbranch;
    }
  }

  getChildren(id) {
    if (!this.hasChild(id)) {
      return [];
    } else {
      return this.$data.tasksStore.getChildren(id).slice();
    }
  }

  hasChild(id) {
    return this.$data.tasksStore.hasChild(id);
  }

  exists(id) {
    return !!(this.pull[id]);
  }

  $getRootId(val?) {
    return (() => { return val; });
  } // (this.gantt.config.rootId || 0)

  _move_branch(item, old_parent, new_parent) {
    //this.setParent(item, new_parent);
    //this._sync_parent(task);
    this._replace_branch_child(old_parent, item.id);
    if (this.exists(new_parent) || new_parent == this.$getRootId()) {

      this._add_branch(item, undefined, new_parent);
    } else {
      delete this._branches[item.id];
    }
    item.$level = this.calculateItemLevel(item);
    this.eachItem((child) => {
      child.$level = this.calculateItemLevel(child);
    }, item.id);
  }

  eachItem(code, parent) {
    parent = parent || this.$getRootId();
    let branch = this.getChildren(parent);
    if (branch)
      for (var i = 0; i < branch.length; i++) {
        var item = this.pull[branch[i]];
        code.call(this, item);
        if (this.hasChild(item.id))
          this.eachItem(code, item.id);
      }
  }

  eachParent(code, startItem) {
    let parentsHash = {};
    var item = startItem;
    var parent = this.getParent(item);

    while (this.exists(parent)) {
      if (parentsHash[parent]) {
        throw new Error("Invalid tasks tree. Cyclic reference has been detected on task " + parent);
      }
      parentsHash[parent] = true;
      item = this.getItem(parent);
      code.call(this, item);
      parent = this.getParent(item);
    }
  }

  getItem(id) {
    return this.pull[id];
  }

  calculateItemLevel(item) {
    let level = 0;
    this.eachParent(() => {
      level++;
    }, item);
    return level;
  }

  _add_branch(item, index, parent) {
    var pid = parent === undefined ? this.getParent(item) : parent;
    if (!this.hasChild(pid))
      this._branches[pid] = new PowerArray().$create();
    var branch = this.getChildren(pid);
    var added_already = false;
    for (var i = 0, length = branch.length; i < length; i++) {
      if (branch[i] == item.id) {
        added_already = true;
        break;
      }
    }
    if (!added_already) {
      if (index * 1 == index) {

        branch.splice(index, 0, item.id);
      } else {
        branch.push(item.id);
      }

      item.$rendered_parent = pid;
    }
  }

  getParent(id) {
    var item = null;
    if (id.id !== undefined) {
      item = id;
    } else {
      item = this.getItem(id);
    }

    var parent;
    if (item) {
      parent = item[this.$parentProperty];
    } else {
      parent = this.$getRootId();
    }
    return parent;

  }

  getScrollState() {
    var state = this._scroll_state();
    return { x: state.x_pos, y: state.y_pos, inner_width: state.x, inner_height: state.y, width: state.x_inner, height: state.y_inner };
  }

  getVerticalScrollbar() {
    return this.gantt.$ui.getView("scrollVer");
  }

  getHorizontalScrollbar() {
    return this.gantt.$ui.getView("scrollHor");
  }

  _scroll_state() {
    var result = {
      x: false,
      y: false,
      x_pos: 0,
      y_pos: 0,
      scroll_size: this.gantt.config.scroll_size + 1,//1px for inner content
      x_inner: 0,
      y_inner: 0
    };

    var scrollVer = this.getVerticalScrollbar(),
      scrollHor = this.getHorizontalScrollbar();
    if (scrollHor) {
      var horState = scrollHor.getScrollState();
      if (horState.visible) {
        result.x = horState.size;
        result.x_inner = horState.scrollSize;
      }
      result.x_pos = horState.position || 0;
    }

    if (scrollVer) {
      var verState = scrollVer.getScrollState();
      if (verState.visible) {
        result.y = verState.size;

        result.y_inner = verState.scrollSize;
      }
      result.y_pos = verState.position || 0;
    }

    return result;
  }

  refreshData() {
    var scrollState = this.getScrollState();
    this.callEvent("onBeforeDataRender", []);

    var stores = this.getDatastores.call(this);
    for (var i = 0; i < stores.length; i++) {
      stores[i].refresh();
    }

    if (scrollState.x || scrollState.y) {
      this.scrollTo(scrollState.x, scrollState.y);
    }
    this.callEvent("onDataRender", []);
  }

  scrollTo(left, top?) {
    var vertical = this.getVerticalScrollbar();
    var horizontal = this.getHorizontalScrollbar();

    var oldH = { position: 0 },
      oldV = { position: 0 };

    if (vertical) {
      oldV = vertical.getScrollState();
    }
    if (horizontal) {
      oldH = horizontal.getScrollState();
    }

    if (horizontal && left * 1 == left) {
      horizontal.scroll(left);
    }
    if (vertical && top * 1 == top) {
      vertical.scroll(top);
    }

    var newV = { position: 0 },
      newH = { position: 0 };
    if (vertical) {
      newV = vertical.getScrollState();
    }
    if (horizontal) {
      newH = horizontal.getScrollState();
    }

    this.callEvent("onGanttScroll", [oldH.position, oldV.position, newH.position, newV.position]);
  }

  getDatastores() {
    var storeNames = this.$services.getService("datastores");
    var res = [];
    for (var i = 0; i < storeNames.length; i++) {
      res.push(this.getDatastore(storeNames[i]));
    }
    return res;
  }

  getDatastore(name) {
    return this.$services.getService("datastore:" + name);
  }

  hideLightbox() {
    var box = this.getLightbox();
    if (box) box.style.display = "none";

    this.lightboxHiddenAttr(box);
    this.gantt._lightbox_id = null;

    this.hideCover();
    this.callEvent("onAfterLightbox", []);
  }

  _cancel_lightbox() {
    var task: any = this.getLightboxValues();
    this.callEvent("onLightboxCancel", [this.gantt._lightbox_id, task.$new]);
    if (this.isTaskExists(task.id) && task.$new) {
      this.silent = (() => {
        this.$data.tasksStore.removeItem(task.id);
        this._update_flags(task.id, null);
      });
    }

    this.refreshData();
    this.hideLightbox();
  }

  _update_flags(oldid?, newid?) {
    //  TODO: need a proper way to update all possible flags
    var store = this.gantt.$data.tasksStore;
    if (oldid === undefined) {
      this._lightbox_id = null;

      store.silent(function () {
        store.unselect();
      });

      if (this._tasks_dnd && this._tasks_dnd.drag) {
        this._tasks_dnd.drag.id = null;
      }
    } else {
      if (this._lightbox_id == oldid)
        this._lightbox_id = newid;

      // TODO: probably can be removed
      if (store.getSelectedId() == oldid) {
        store.silent(function () {
          store.unselect(oldid);
          store.select(newid);
        });
      }
      if (this._tasks_dnd && this._tasks_dnd.drag && this._tasks_dnd.drag.id == oldid) {
        this._tasks_dnd.drag.id = newid;
      }
    }
  }

  silent() {
    var gantt = this;
    // gantt.$data.tasksStore.silent(() => {
    //   gantt.$data.linksStore.silent(() => {
    //     code();
    //   });
    // });
  }

  hideCover() {
    if (this._cover)
      this._cover.parentNode.removeChild(this._cover);
    this._cover = null;
  }

  _init_lightbox_events() {
    this.gantt.lightbox_events = {};


    this.gantt.lightbox_events.gantt_save_btn(() => {
      this._save_lightbox();
    });


    this.gantt.lightbox_events.gantt_delete_btn(() => {
      if (!this.callEvent("onLightboxDelete", [this.gantt._lightbox_id]))
        return;

      if (this.isTaskExists(this.gantt._lightbox_id)) {
        this.gantt.$click.buttons["delete"](this.gantt._lightbox_id);
      } else {
        this.hideLightbox();
      }

    });


    this.gantt.lightbox_events.gantt_cancel_btn(() => {
      this._cancel_lightbox();
    });

    this.gantt.lightbox_events["default"]((e, src) => {
      if (src.getAttribute("data-dhx-button")) {
        this.callEvent("onLightboxButton", [src.className, src, e]);
      } else {
        var index, block, sec;

        var className = this.utilsService.getClassName(src);
        if (className.indexOf("gantt_custom_button") != -1) {
          if (className.indexOf("gantt_custom_button_") != -1) {
            index = src.parentNode.getAttribute("data-index");
            sec = src;
            while (sec && this.utilsService.getClassName(sec).indexOf("gantt_cal_lsection") == -1) {
              sec = sec.parentNode;
            }
          } else {
            index = src.getAttribute("data-index");
            sec = src.parentNode;
            src = src.firstChild;
          }
        }

        var sections = this._get_typed_lightbox_config(undefined);

        if (index) {
          index = index * 1;
          block = this.form_blocks[sections[index * 1].type];
          block.button_click(index, src, sec, sec.nextSibling);
        }
      }
    });

    this.utilsService.event(this.getLightbox(), "click", ((e) => {
      e = e || window.event;
      var src = e.target ? e.target : e.srcElement;

      var className = this.utilsService.getClassName(src);
      if (!className) {
        src = src.previousSibling;
        className = this.utilsService.getClassName(src);
      }
      if (src && className && className.indexOf("gantt_btn_set") === 0) {
        src = src.firstChild;
        className = this.utilsService.getClassName(src);
      }
      if (src && className) {
        var func = this.utilsService.defined(this.gantt.lightbox_events[src.className]) ? this.gantt.lightbox_events[src.className] : this.gantt.lightbox_events["default"];
        return func(e, src);
      }
      return false;
    }), undefined);

    this.getLightbox().onkeydown((e) => {
      var event = e || window.event;
      var target = e.target || e.srcElement;
      var buttonTarget = this.utilsService.getClassName(target).indexOf("gantt_btn_set") > -1;

      switch ((e || event).keyCode) {
        case this.gantt.constants.KEY_CODES.SPACE: {
          if ((e || event).shiftKey) return;
          if (buttonTarget && target.click) {
            target.click();
          }
          break;
        }
        case this.gantt.keys.edit_save:
          if ((e || event).shiftKey) return;
          if (buttonTarget && target.click) {
            target.click();
          } else {
            this._save_lightbox();
          }
          break;
        case this.gantt.keys.edit_cancel:
          this._cancel_lightbox();
          break;
        default:
          break;
      }
    })
  };

  resizeLightbox() {
    if (!this._lightbox) return;

    var con = this._lightbox.childNodes[1];
    con.style.height = "0px";
    con.style.height = con.scrollHeight + "px";
    this._lightbox.style.height = con.scrollHeight + this.gantt.config.lightbox_additional_height + "px";
    con.style.height = con.scrollHeight + "px"; //it is incredible , how ugly IE can be
  }

  _get_type_name(type_value) {
    for (var i in this.gantt.config.types) {
      if (this.gantt.config.types[i] == type_value) {
        return i;
      }
    }
    return "task";
  }

  _render_sections(sns) {
    var html = "";
    for (var i = 0; i < sns.length; i++) {
      var block = this.form_blocks[sns[i].type];
      if (!block) continue; //ignore incorrect blocks
      sns[i].id = "area_" + this.utilsService.uid();

      var display = sns[i].hidden ? " style='display:none'" : "";
      var button = "";
      if (sns[i].button) {
        button = "<div class='gantt_custom_button' data-index='" + i + "'><div class='gantt_custom_button_" + sns[i].button + "'></div><div class='gantt_custom_button_label'>" + this.gantt.locale.labels["button_" + sns[i].button] + "</div></div>";
      }
      if (this.gantt.config.wide_form) {
        html += "<div class='gantt_wrap_section' " + display + ">";
      }
      html += "<div id='" + sns[i].id + "' class='gantt_cal_lsection'><label>" + button + this.gantt.locale.labels["section_" + sns[i].name] + "</label></div>" + block.render.call(this, sns[i]);
      html += "</div>";
    }
    return html;
  }

  getHtmlButtons(buttons, floatRight) {
    var button;
    var ariaAttr;
    var html = "";
    var i;

    for (i = 0; i < buttons.length; i++) {
      // needed to migrate from 'dhx_something' to 'gantt_something' naming in a lightbox
      button = this.gantt.config._migrate_buttons[buttons[i]] ? this.gantt.config._migrate_buttons[buttons[i]] : buttons[i];

      ariaAttr = this.lightboxButtonAttrString(button);
      html += "<div " + ariaAttr + " class='gantt_btn_set gantt_left_btn_set " + button + "_set'" + (floatRight ? " style='float:right;'" : "") + "><div dhx_button='1' data-dhx-button='1' class='" + button + "'></div><div>" + this.gantt.locale.labels[button] + "</div></div>";
    }
    return html;
  }

  htmlTags = new RegExp("<(?:.|\n)*?>", "gm");
  extraSpaces = new RegExp(" +", "gm");

  stripHTMLLite(htmlText) {
    return (htmlText + "")
      .replace(this.htmlTags, " ").
      replace(this.extraSpaces, " ");
  }

  singleQuotes = new RegExp("'", "gm");

  escapeQuotes(text) {
    return (text + "").replace(this.singleQuotes, "&#39;");
  }

  //gantt._waiAria = {
  getAttributeString(attr) {
    var attributes = [" "];
    for (var i in attr) {
      var text = this.escapeQuotes(this.stripHTMLLite(attr[i]));
      attributes.push(i + "='" + text + "'");
    }
    attributes.push(" ");
    return attributes.join(" ");

  }

  getTimelineCellAttr(dateString) {

    return this.getAttributeString({ "aria-label": dateString });
  }

  _taskCommonAttr(task, div) {

    if (!(task.start_date && task.end_date))
      return;

    div.setAttribute("aria-label", this.stripHTMLLite(this.gantt.templates.tooltip_text(task.start_date, task.end_date, task)));

    if (this.isReadonly(task)) {
      div.setAttribute("aria-readonly", true);
    }

    if (task.$dataprocessor_class) {
      div.setAttribute("aria-busy", true);
    }

    div.setAttribute("aria-selected", this.isSelectedTask(task.id) ? "true" : "false");
  }

  isSelectedTask(id) {
    return this.$data.tasksStore.isSelected(id);
  }

  setTaskBarAttr(task, div) {
    this._taskCommonAttr(task, div);

    if (!this.isReadonly(task) && this.gantt.config.drag_move) {
      if (task.id != this.getState.drag_id) {
        div.setAttribute("aria-grabbed", false);
      } else {
        div.setAttribute("aria-grabbed", true);
      }
    }
  }

  taskRowAttr(task, div) {

    this._taskCommonAttr(task, div);

    if (!this.isReadonly(task) && this.gantt.config.order_branch) {
      div.setAttribute("aria-grabbed", false);
    }

    div.setAttribute("role", "row");

    div.setAttribute("aria-level", task.$level);

    if (this.hasChild(task.id)) {
      div.setAttribute("aria-expanded", task.$open ? "true" : "false");
    }
  }

  linkAttr(link, div) {

    var linkTypes = this.gantt.config.links;

    var toStart = link.type == linkTypes.finish_to_start || link.type == linkTypes.start_to_start;
    var fromStart = link.type == linkTypes.start_to_start || link.type == linkTypes.start_to_finish;

    var content = this.gantt.locale.labels.link + " " + this.gantt.templates.drag_link(link.source, fromStart, link.target, toStart);

    div.setAttribute("aria-label", this.stripHTMLLite(content));
    if (this.isReadonly(link)) {
      div.setAttribute("aria-readonly", true);
    }
  }

  gridSeparatorAttr(div) {
    div.setAttribute("role", "separator");
  }

  lightboxHiddenAttr(div) {
    div.setAttribute("aria-hidden", "true");
  }

  lightboxVisibleAttr(div) {
    div.setAttribute("aria-hidden", "false");
  }

  lightboxAttr(div) {
    div.setAttribute("role", "dialog");
    div.setAttribute("aria-hidden", "true");
    div.firstChild.setAttribute("role", "heading");
  }

  lightboxButtonAttrString(buttonName) {
    return this.getAttributeString({ "role": "button", "aria-label": this.gantt.locale.labels[buttonName], "tabindex": "0" });
  }

  lightboxHeader(div, headerText) {
    div.setAttribute("aria-label", headerText);
  }

  lightboxSelectAttrString(time_option) {
    var label = "";

    switch (time_option) {
      case "%Y":
        label = this.gantt.locale.labels.years;
        break;
      case "%m":
        label = this.gantt.locale.labels.months;
        break;
      case "%d":
        label = this.gantt.locale.labels.days;
        break;
      case "%H:%i":
        label = this.gantt.locale.labels.hours + this.gantt.locale.labels.minutes;
        break;
      default:
        break;
    }

    return this.getAttributeString({ "aria-label": label });
  }

  lightboxDurationInputAttrString(section) {
    return this.getAttributeString({ "aria-label": this.gantt.locale.labels.column_duration, "aria-valuemin": "0" });
  }

  gridAttrString() {
    return [" role='treegrid'", this.gantt.config.multiselect ? "aria-multiselectable='true'" : "aria-multiselectable='false'", " "].join(" ");
  }


  gridScaleRowAttrString() {
    return "role='row'";
  }

  gridScaleCellAttrString(column, label) {
    var attrs = "";
    if (column.name == "add") {
      attrs = this.getAttributeString({ "role": "button", "aria-label": this.gantt.locale.labels.new_task });
    } else {

      var attributes = {
        "role": "columnheader",
        "aria-label": label
      };

      if (this.gantt._sort && this.gantt._sort.name == column.name) {
        if (this.gantt._sort.direction == "asc") {
          attributes["aria-sort"] = "ascending";
        } else {
          attributes["aria-sort"] = "descending";
        }
      }

      attrs = this.getAttributeString(attributes);
    }
    return attrs;
  }

  gridDataAttrString() {
    return "role='rowgroup'";
  }

  gridCellAttrString(column, textValue) {
    return this.getAttributeString({ "role": "gridcell", "aria-label": textValue });
  }

  gridAddButtonAttrString(column) {
    return this.getAttributeString({ "role": "button", "aria-label": this.gantt.locale.labels.new_task });
  }

  messageButtonAttrString(buttonLabel) {
    return "tabindex='0' role='button' aria-label='" + buttonLabel + "'";
  }

  messageInfoAttr(div) {
    div.setAttribute("role", "alert");
    //div.setAttribute("tabindex", "-1");
  }

  messageModalAttr(div, uid) {
    div.setAttribute("role", "dialog");
    if (uid) {
      div.setAttribute("aria-labelledby", uid);
    }

    //	div.setAttribute("tabindex", "-1");
  }

  quickInfoAttr(div) {
    div.setAttribute("role", "dialog");
  }

  quickInfoHeaderAttrString() {
    return " role='heading' ";
  }

  quickInfoHeader(div, header) {
    div.setAttribute("aria-label", header);
  }

  quickInfoButtonAttrString(label) {
    return this.getAttributeString({ "role": "button", "aria-label": label, "tabindex": "0" });
  }

  tooltipAttr(div) {
    div.setAttribute("role", "tooltip");
  }

  tooltipVisibleAttr(div) {
    div.setAttribute("aria-hidden", "false");
  }

  tooltipHiddenAttr(div) {
    div.setAttribute("aria-hidden", "true");
  }
  // };

  isDisabled() {
    return !this.gantt.config.wai_aria_attributes;
  }

  // for(var i in gantt._waiAria) {
  // gantt._waiAria[i] = (function (payload) {
  //   return function () {
  //     if (isDisabled()) {
  //       return "";
  //     }
  //     return payload.apply(this, arguments);
  //   };
  // })(gantt._waiAria[i]);
  //}


  // $click = {
  //   buttons: {
  //     "edit": function (id) {
  //       gantt.showLightbox(id);
  //     },
  //     "delete": function (id) {
  //       var question = gantt.locale.labels.confirm_deleting;
  //       var title = gantt.locale.labels.confirm_deleting_title;

  //       _dhtmlx_confirm(question, title, function () {
  //         if (!gantt.isTaskExists(id)) {
  //           gantt.hideLightbox();
  //           return;
  //         }

  //         var task = gantt.getTask(id);
  //         if (task.$new) {
  //           gantt.silent(function () {
  //             gantt.deleteTask(id, true);
  //           });
  //           gantt.refreshData();
  //         } else {
  //           gantt.deleteTask(id);
  //         }

  //         gantt.hideLightbox();
  //       });
  //     }
  //   }
  // };

  dateFromPos(x) {
    var scale = this._tasks;
    if (x < 0 || x > scale.full_width || !scale.full_width) {
      return null;
    }

    var ind = this._findBinary(this._tasks.left, x);
    var summ = this._tasks.left[ind];

    var col_width = scale.width[ind] || scale.col_width;
    var part = 0;
    if (col_width) {
      part = (x - summ) / col_width;
      if (scale.rtl) {
        part = 1 - part;
      }

    }

    var unit = 0;
    if (part) {
      unit = this._getColumnDuration(scale, scale.trace_x[ind]);
    }

    var date = new Date(scale.trace_x[ind].valueOf() + Math.round(part * unit));
    return date;
  }

  _findBinary(array, target) {
    // modified binary search, target value not exactly match array elements, looking for closest one

    var low = 0, high = array.length - 1, i, item, prev;
    while (low <= high) {

      i = Math.floor((low + high) / 2);
      item = +array[i];
      prev = +array[i - 1];
      if (item < target) {
        low = i + 1;
        continue;
      }
      if (item > target) {
        if (!(!isNaN(prev) && prev < target)) {
          high = i - 1;
          continue;
        } else {
          // if target is between 'i' and 'i-1' return 'i - 1'
          return i - 1;
        }

      }
      while (+array[i] == +array[i + 1]) i++;

      return i;
    }
    return array.length - 1;
  }

  //renders self
  render() {
    this.callEvent("onBeforeGanttRender", []);

    if (!this.config.sort && this._sort) {
      this._sort = undefined;
    }

    var pos = this.getScrollState();
    var posX = pos ? pos.x : 0;
    if (this.getHorizontalScrollbar()) {
      var scrollbar = this.getHorizontalScrollbar();
      posX = scrollbar.$config.codeScrollLeft || posX || 0;
    }


    var visible_date = null;
    if (posX) {
      visible_date = this.dateFromPos(posX + this.config.task_scroll_offset);
    }

    new DataRange().updateTasksRange(this.gantt);

    this.$layout.$config.autosize = this.config.autosize;
    this.$layout.resize();

    if (this.config.preserve_scroll && pos) {

      if (posX) {
        var new_pos = this.getScrollState();
        var new_date = this.dateFromPos(new_pos.x);
        if (!(+visible_date == +new_date && new_pos.y == pos.y)) {
          if (visible_date) {
            this.showDate(visible_date);
          }
          if (pos.y)
            this.scrollTo(undefined, pos.y);
        }
      }
    }

    this.callEvent("onGanttRender", []);
  };

  //TODO: add layout.resize method that wouldn't trigger data repaint
  setSizes = this.render();

  _locate_css(e, classname, strict) {
    return this.utilsService.locateClassName(e, classname, strict);
  };

  _locateHTML(e, attribute) {
    return this.utilsService.locateAttribute(e, attribute || this.config.task_attribute);
  };

  posFromDate(date) {
    // if (!this.isVisible())
    //   return 0;

    // if (!date) {
    //   return 0;
    // }

    var dateValue = String(date.valueOf());

    if (this._posFromDateCache[dateValue] !== undefined) {
      return this._posFromDateCache[dateValue];
    }
    var ind = this.columnIndexByDate(date);
    this.assert(ind >= 0, "Invalid day index");

    var wholeCells = Math.floor(ind);
    var partCell = ind % 1;

    var pos = this._tasks.left[Math.min(wholeCells, this._tasks.width.length - 1)];
    if (wholeCells == this._tasks.width.length)
      pos += this._tasks.width[this._tasks.width.length - 1];
    //for(var i=1; i <= wholeCells; i++)
    //	pos += gantt._tasks.width[i-1];

    if (partCell) {
      if (wholeCells < this._tasks.width.length) {
        pos += this._tasks.width[wholeCells] * (partCell % 1);
      } else {
        pos += 1;
      }

    }

    var roundPos = Math.round(pos);
    this._posFromDateCache[dateValue] = roundPos;
    return Math.round(roundPos);
  }

  showDate(date) {
    var date_x = this.posFromDate(date);
    var scroll_to = Math.max(date_x - this.config.task_scroll_offset, 0);
    this.scrollTo(scroll_to);
  }

  columnIndexByDate(date) {
    var pos = new Date(date).valueOf();
    var days = this._tasks.trace_x_ascending,
      ignores = this._tasks.ignore_x;

    var state = this.ganttObject.gantt.getState();

    if (pos <= state.min_date) {
      if (this._tasks.rtl) {
        return days.length;
      } else {
        return 0;
      }

    }

    if (pos >= state.max_date) {
      if (this._tasks.rtl) {
        return 0;
      } else {
        return days.length;
      }
    }

    var dateIndex = this._findBinary(days, pos);

    var visibleIndex = this._getClosestVisibleColumn(dateIndex, days, ignores);
    var visibleDate = days[visibleIndex];
    var transition = this._tasks.trace_index_transition;

    if (!visibleDate) {
      if (transition) {
        return transition[0];
      } else {
        return 0;
      }
    }

    var part = ((date - days[visibleIndex]) / this._getColumnDuration(this._tasks, days[visibleIndex]));
    if (transition) {
      return transition[visibleIndex] + (1 - part);
    } else {
      return visibleIndex + part;
    }
  }

  _getClosestVisibleColumn(startIndex, columns, ignores) {
    var visibleDateIndex = this._getNextVisibleColumn(startIndex, columns, ignores);
    if (!columns[visibleDateIndex]) {
      visibleDateIndex = this._getPrevVisibleColumn(startIndex, columns, ignores);
    }
    return visibleDateIndex;
  }

  _getPrevVisibleColumn(startIndex, columns, ignores) {
    // iterate columns to the left
    var date = +columns[startIndex];
    var visibleDateIndex = startIndex;
    while (ignores[date]) {
      visibleDateIndex--;
      date = +columns[visibleDateIndex];
    }
    return visibleDateIndex;
  }

  _getNextVisibleColumn(startIndex, columns, ignores) {
    // iterate columns to the right
    var date = +columns[startIndex];
    var visibleDateIndex = startIndex;
    while (ignores[date]) {
      visibleDateIndex++;
      date = +columns[visibleDateIndex];
    }

    return visibleDateIndex;
  }

  _getColumnDuration(scale, date) {
    return this.gantt.date.add(date, scale.step, scale.unit) - date;
  }

  getTaskRowNode(id) {
    var els = this.$grid_data.childNodes;
    var attribute = this.config.task_attribute;
    for (var i = 0; i < els.length; i++) {
      if (els[i].getAttribute) {
        var value = els[i].getAttribute(attribute);
        if (value == id) return els[i];
      }
    }
    return null;
  };

  changeLightboxType(type) {
    if (this.getLightboxType() == type)
      return true;
    this._silent_redraw_lightbox(type);
  };

  _silent_redraw_lightbox(type) {
    var oldType = this.getLightboxType();

    if (this.getState().lightbox) {
      var taskId = this.getState().lightbox;
      var formData = this.getLightboxValues(),
        task = this.utilsService.copy(this.getTask(taskId));

      this.resetLightbox();

      var updTask = this.utilsService.mixin(task, formData, true);
      var box = this.getLightbox(type ? type : undefined);
      this._center_lightbox(this.getLightbox());
      this._set_lightbox_values(updTask, box);
      this.showCover();
    } else {
      this.resetLightbox();
      this.getLightbox(type ? type : undefined);
    }
    this.callEvent("onLightboxChange", [oldType, this.getLightboxType()]);
  }


  _get_link_type(from_start, to_start) {
    var type = null;
    if (from_start && to_start) {
      type = this.config.links.start_to_start;
    } else if (!from_start && to_start) {
      type = this.config.links.finish_to_start;
    } else if (!from_start && !to_start) {
      type = this.config.links.finish_to_finish;
    } else if (from_start && !to_start) {
      type = this.config.links.start_to_finish;
    }
    return type;
  };

  isLinkAllowed(from, to, from_start, to_start) {
    var link = null;
    if (typeof (from) == "object") {
      link = from;
    } else {
      link = { source: from, target: to, type: this._get_link_type(from_start, to_start) };
    }

    if (!link) return false;
    if (!(link.source && link.target && link.type)) return false;
    if (link.source == link.target) return false;

    var res = true;
    //any custom rules
    if (this.checkEvent("onLinkValidation"))
      res = this.callEvent("onLinkValidation", [link]);

    return res;
  };


  _correct_dst_change(date, prevOffset, step, unit) {
    var time_unit = this.utilsService.getSecondsInUnit(unit) * step;
    if (time_unit > 60 * 60 && time_unit < 60 * 60 * 24) {
      //correct dst change only if current unit is more than one hour and less than day (days have own checking), e.g. 12h
      var offsetChanged = date.getTimezoneOffset() - prevOffset;
      if (offsetChanged) {
        date = this.ganttObject.gantt.date.add(date, offsetChanged, "minute");
      }
    }
    return date;
  };

  isSplitTask(task) {
    this.ganttObject.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isSplitTask. Task object was expected");
    return this.$data.tasksStore._isSplitItem(task);
  };

  _is_icon_open_click(e) {
    if (!e)
      return false;
    var target = e.target || e.srcElement;
    if (!(target && target.className))
      return false;
    var className = this.utilsService.getClassName(target);
    if (className.indexOf("gantt_tree_icon") !== -1 && (className.indexOf("gantt_close") !== -1 || className.indexOf("gantt_open") !== -1))
      return true;
    return false;
  };







  popups = [];

  // gantt.attachEvent("onMessagePopup", function(box) {
  //   this.popups.push(box);
  // });

  // this.attachEvent("onAfterMessagePopup", function(box) {
  //   for (var i = 0; i < this.popups.length; i++) {
  //     if (this.popups[i] === box) {
  //       this.popups.splice(i, 1);
  //       i--;
  //     }
  //   }
  // });

  // this.attachEvent("onDestroy", function() {
  //   if (this.modalityObj.cover && this.modalityObj.cover.parentNode) {
  //     this.modalityObj.cover.parentNode.removeChild(this.modalityObj.cover);
  //   }

  //   for (var i = 0; i < this.popups.length; i++) {
  //     if (this.popups[i].parentNode) {
  //       this.popups[i].parentNode.removeChild(this.popups[i]);
  //     }
  //   }
  //   this.popups = null;

  //   if (this.messagebox.area && this.messagebox.area.parentNode) {
  //     this.messagebox.area.parentNode.removeChild(this.messagebox.area);
  //   }
  //   this.messagebox = null;
  // });



}

export class DataRange {
  config: any;

  dateRangeResolver(gantt) {
    //reset project timing
    //_get_tasks_data(gantt);
    return gantt.getSubtaskDates();
  }

  defaultRangeResolver() {
    return {
      start_date: new Date(),
      end_date: new Date()
    };
  }

  resolveConfigRange(unit, gantt) {
    var range = {
      start_date: null,
      end_date: null
    };

    if (this.config.start_date && this.config.end_date) {
      range.start_date = gantt.date[unit + "_start"](new Date(this.config.start_date));

      var end = new Date(this.config.end_date);
      var start_interval = gantt.date[unit + "_start"](new Date(end));
      if (+end != +start_interval) {
        end = gantt.date.add(start_interval, 1, unit);
      } else {
        end = start_interval;
      }

      range.end_date = end;
    }
    return range;
  }

  _scale_range_unit(gantt) {
    var primaryScale = (new ScaleHelper()).primaryScale();
    var unit = primaryScale.unit;
    var step = primaryScale.step;
    if (this.config.scale_offset_minimal) {

      var helper = new ScaleHelper();
      var scales = [helper.primaryScale()].concat(helper.getSubScales());

      helper.sortScales(scales);
      unit = scales[scales.length - 1].unit;
      step = scales[scales.length - 1].step || 1;
    }
    return { unit: unit, step: step };
  }

  _init_tasks_range(gantt) {
    var cfg = this._scale_range_unit(gantt);
    var unit = cfg.unit,
      step = cfg.step;
    var range = this.resolveConfigRange(unit, gantt);

    if (!(range.start_date && range.end_date)) {
      range = this.dateRangeResolver(gantt);
      if (!range.start_date || !range.end_date) {
        // range = defaultRangeResolver(gantt);
        range = this.defaultRangeResolver();
      }

      range.start_date = gantt.date[unit + "_start"](range.start_date);
      range.start_date = gantt.calculateEndDate({
        start_date: gantt.date[unit + "_start"](range.start_date),
        duration: -1,
        unit: unit,
        step: step
      });//one free column before first task

      range.end_date = gantt.date[unit + "_start"](range.end_date);
      range.end_date = gantt.calculateEndDate({ start_date: range.end_date, duration: 2, unit: unit, step: step });//one free column after last task
    }

    gantt._min_date = range.start_date;
    gantt._max_date = range.end_date;
  }

  _adjust_scales(gantt) {
    if (this.config.fit_tasks) {
      var old_min = +gantt._min_date,
        old_max = +gantt._max_date;
      //this._init_tasks_range();
      if (+gantt._min_date != old_min || +gantt._max_date != old_max) {
        gantt.render();

        gantt.callEvent("onScaleAdjusted", []);
        return true;
      }
    }
    return false;
  }

  updateTasksRange(gantt) {
    this._init_tasks_range(gantt);
    this._adjust_scales(gantt);
  };
}

export class DataStore {
  pull: {};
  $initItem: any;
  visibleOrder: any;
  fullOrder: any;
  _skip_refresh: boolean;
  _filterRule: any;
  _searchVisibleOrder: {};
  $config: any;
  utilsService: UtilsService
  ganttObject: GanttObjectService
  // dataStoreService: DatastoreService;
  constructor(config) {
    this.pull = {};
    this.$initItem = config.initItem;
    this.visibleOrder = new PowerArray().$create();
    this.fullOrder = new PowerArray().$create();
    this._skip_refresh = false;
    this._filterRule = null;
    this._searchVisibleOrder = {};
    this.$config = config;
    // eventable(this);
    return this;
  }


  _parseInner(data) {
    var item = null,
      loaded = [];
    for (var i = 0, len = data.length; i < len; i++) {
      item = data[i];
      if (this.$initItem) {
        item = this.$initItem(item);
      }
      if (this.ganttObject.callEvent("onItemLoading", [item])) {
        if (!this.pull.hasOwnProperty(item.id)) {
          this.fullOrder.push(item.id);
        }
        loaded.push(item);
        this.pull[item.id] = item;
      }
    }
    return loaded;
  }

  parse(data) {
    this.ganttObject.callEvent("onBeforeParse", [data]);
    var loaded = this._parseInner(data);
    this.refresh();
    this.ganttObject.callEvent("onParse", [loaded]);
  }

  getItem(id) {
    return this.pull[id];
  }

  _updateOrder(code) {
    code.call(this.visibleOrder);
    code.call(this.fullOrder);
  }

  updateItem(id, item) {
    if (!this.utilsService.defined(item)) item = this.getItem(id);

    if (!this._skip_refresh) {
      if (this.ganttObject.callEvent("onBeforeUpdate", [item.id, item]) === false) return false;
    }
    this.pull[id] = item;
    if (!this._skip_refresh) {
      this.ganttObject.callEvent("onAfterUpdate", [item.id, item]);
      this.ganttObject.callEvent("onStoreUpdated", [item.id, item, "update"]);
    }
  }

  _removeItemInner(id) {
    //clear from collections
    //this.visibleOrder.$remove(id);
    this._updateOrder(function () { this.$remove(id); });
    delete this.pull[id];
  }

  removeItem(id) {
    //utils.assert(this.exists(id), "Not existing ID in remove command"+id);

    var obj = this.getItem(id);	//save for later event
    if (!this._skip_refresh) {
      if (this.ganttObject.callEvent("onBeforeDelete", [obj.id, obj]) === false) return false;
    }

    this._removeItemInner(id);

    if (!this._skip_refresh) {
      this.filter();
      this.ganttObject.callEvent("onAfterDelete", [obj.id, obj]);
      //repaint signal
      this.ganttObject.callEvent("onStoreUpdated", [obj.id, obj, "delete"]);
    }
  }

  _addItemInner(item, index) {
    //in case of treetable order is sent as 3rd parameter
    //var order = index;

    if (this.exists(item.id)) {
      this.silent(function () { this.updateItem(item.id, item); });
    } else {
      var order = this.visibleOrder;

      //by default item is added to the end of the list
      var data_size = order.length;

      if (!this.utilsService.defined(index) || index < 0)
        index = data_size;
      //check to prevent too big indexes
      if (index > data_size) {
        //dhx.log("Warning","DataStore:add","Index of out of bounds");
        index = Math.min(order.length, index);
      }
    }


    //gantt.assert(!this.exists(id), "Not unique ID");

    this.pull[item.id] = item;
    if (!this._skip_refresh) {
      this._updateOrder(function () {
        if (this.$find(item.id) === -1)
          this.$insertAt(item.id, index);
      });
    }
    this.filter();
    //order.$insertAt(item.id,index);
  }


  isVisible(id) {
    return this.visibleOrder.$find(id) > -1;
  }

  getVisibleItems() {
    return this.getIndexRange();
  }

  addItem(item, index) {
    if (!this.utilsService.defined(item.id))
      item.id = this.utilsService.uid();

    if (this.$initItem) {
      item = this.$initItem(item);
    }

    if (!this._skip_refresh) {
      if (this.ganttObject.callEvent("onBeforeAdd", [item.id, item]) === false) return false;
    }


    this._addItemInner(item, index);

    if (!this._skip_refresh) {
      this.ganttObject.callEvent("onAfterAdd", [item.id, item]);
      //repaint signal
      this.ganttObject.callEvent("onStoreUpdated", [item.id, item, "add"]);
    }
    return item.id;
  }

  _changeIdInner(oldId, newId) {
    if (this.pull[oldId])
      this.pull[newId] = this.pull[oldId];

    var visibleOrder = this._searchVisibleOrder[oldId];
    this.pull[newId].id = newId;
    this._updateOrder(function () {
      this[this.$find(oldId)] = newId;
    });
    this._searchVisibleOrder[newId] = visibleOrder;
    delete this._searchVisibleOrder[oldId];

    //this.visibleOrder[this.visibleOrder.$find(oldId)]=newId;
    delete this.pull[oldId];
  }

  changeId(oldId, newId) {
    this._changeIdInner(oldId, newId);

    this.ganttObject.callEvent("onIdChange", [oldId, newId]);

  }

  exists(id) {
    return !!(this.pull[id]);
  }

  _moveInner(sindex, tindex) {
    var id = this.getIdByIndex(sindex);

    this._updateOrder(function () {
      this.$removeAt(sindex);
      this.$insertAt(id, Math.min(this.length, tindex));
    });
    //this.visibleOrder.$removeAt(sindex);	//remove at old position
    //if (sindex<tindex) tindex--;	//correct shift, caused by element removing
    //this.visibleOrder.$insertAt(id,Math.min(this.visibleOrder.length, tindex));	//insert at new position
  }

  move(sindex, tindex) {
    //gantt.assert(sindex>=0 && tindex>=0, "DataStore::move","Incorrect indexes");

    var id = this.getIdByIndex(sindex);
    var obj = this.getItem(id);
    this._moveInner(sindex, tindex);


    if (!this._skip_refresh) {
      //repaint signal
      this.ganttObject.callEvent("onStoreUpdated", [obj.id, obj, "move"]);
    }
  }

  clearAll() {
    this.pull = {};
    this.visibleOrder = new PowerArray().$create();
    this.fullOrder = new PowerArray().$create();
    if (this._skip_refresh) return;
    this.ganttObject.callEvent("onClearAll", []);
    this.refresh();
  }

  silent(code, master?) {
    this._skip_refresh = true;
    code.call(master || this);
    this._skip_refresh = false;
  }

  arraysEqual(arr1, arr2) {
    if (arr1.length !== arr2.length)
      return false;
    for (var i = 0; i < arr1.length; i++) {
      if (arr1[i] !== arr2[i])
        return false;
    }

    return true;
  }

  refresh(id?, quick?) {
    if (this._skip_refresh) return;

    var args;
    if (id) {
      args = [id, this.pull[id], "paint"];
    } else {
      args = [null, null, null];
    }

    if (this.ganttObject.callEvent("onBeforeStoreUpdate", args) === false) {
      return;
    }

    if (id) {
      // if item changes visible order (e.g. expand-collapse branch) - do a complete repaint
      if (!quick) {
        var oldOrder = this.visibleOrder;
        this.filter();
        if (!this.arraysEqual(oldOrder, this.visibleOrder)) {
          id = undefined;
        }
      }

    } else {
      this.filter();
    }

    if (id) {
      args = [id, this.pull[id], "paint"];
    } else {
      args = [null, null, null];
    }

    this.ganttObject.callEvent("onStoreUpdated", args);
  }

  count() {
    return this.fullOrder.length;
  }

  countVisible() {
    return this.visibleOrder.length;
  }

  sort(sort) { }

  serialize() { }

  eachItem(code) {
    for (var i = 0; i < this.fullOrder.length; i++) {
      var item = this.pull[this.fullOrder[i]];
      code.call(this, item);
    }
  }

  filter(rule?) {
    this.ganttObject.callEvent("onBeforeFilter", []);
    var filteredOrder = new PowerArray().$create();
    this.eachItem(function (item) {
      if (this.ganttObject.callEvent("onFilterItem", [item.id, item])) {
        filteredOrder.push(item.id);
      }
    });

    this.visibleOrder = filteredOrder;
    this._searchVisibleOrder = {};
    for (var i = 0; i < this.visibleOrder.length; i++) {
      this._searchVisibleOrder[this.visibleOrder[i]] = i;
    }
    this.ganttObject.callEvent("onFilter", []);
  }

  getIndexRange(from?, to?) {
    to = Math.min((to || Infinity), this.countVisible() - 1);

    var ret = [];
    for (var i = (from || 0); i <= to; i++)
      ret.push(this.getItem(this.visibleOrder[i]));
    return ret;
  }

  getItems() {
    var res = [];
    for (var i in this.pull) {
      res.push(this.pull[i]);
    }
    /*	for(var i = 0; i < this.fullOrder.length; i++){
  
      }*/
    return res;
  }

  getIdByIndex(index) {
    return this.visibleOrder[index];
  }

  getIndexById(id) {
    var res = this._searchVisibleOrder[id];
    if (res === undefined) {
      res = -1;
    }
    return res;
  }

  _getNullIfUndefined(value) {
    if (value === undefined) {
      return null;
    } else {
      return value;
    }
  }

  getFirst() {
    return this._getNullIfUndefined(this.visibleOrder[0]);
  }

  getLast() {
    return this._getNullIfUndefined(this.visibleOrder[this.visibleOrder.length - 1]);
  }

  getNext(id) {
    return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(id) + 1]);
  }

  getPrev(id) {
    return this._getNullIfUndefined(this.visibleOrder[this.getIndexById(id) - 1]);
  }

  destructor() {
    this.ganttObject.detachAllEvents();
    this.pull = null;
    this.$initItem = null;
    this.visibleOrder = null;
    this.fullOrder = null;
    this._skip_refresh = null;
    this._filterRule = null;
    this._searchVisibleOrder = null;
  }
}

export class TreeDataStore {
  _branches: {};
  pull: {};
  $initItem: any;
  $parentProperty: any;
  $getRootId: () => any;
  $openInitially: any;
  visibleOrder: any;
  fullOrder: any;
  _searchVisibleOrder: {};
  _skip_refresh: boolean;
  _ganttConfig: any;
  dataStore: DataStore;

  // dataStoreService: DatastoreService;
  ganttObject: GanttObjectService
  utilsService: UtilsService;

  constructor(config) {
    DataStore.apply(this, [config]);
    this._branches = {};

    this.pull = {};
    this.$initItem = config.initItem;
    this.$parentProperty = config.parentProperty || "parent";

    if (typeof config.rootId !== "function") {
      this.$getRootId = (function (val) {
        return function () { return val; };
      })(config.rootId || 0);
    } else {
      this.$getRootId = config.rootId;
    }

    // TODO: replace with live reference to gantt config
    this.$openInitially = config.openInitially;

    this.visibleOrder = new PowerArray().$create();
    this.fullOrder = new PowerArray().$create();
    this._searchVisibleOrder = {};
    this._skip_refresh = false;

    this._ganttConfig = null;
    if (config.getConfig) {
      this._ganttConfig = config.getConfig();
    }

    this.ganttObject.attachEvent("onFilterItem", function (id, item) {

      var canOpenSplitTasks: any = false;
      if (this._ganttConfig) {
        var canOpenSplitTasks = this._ganttConfig.open_split_tasks;
      }

      var open = true;
      this.eachParent(function (parent) {
        open = open && parent.$open && (canOpenSplitTasks || !this._isSplitItem(parent));
      }, item);
      return !!open;
    });

    return this;
  }

  // utils.mixin({

  _buildTree(data) {
    var item = null;
    var rootId = this.$getRootId();
    for (var i = 0, len = data.length; i < len; i++) {
      item = data[i];
      this.setParent(item, this.getParent(item) || rootId);
    }

    // calculating $level for each item
    for (var i = 0, len = data.length; i < len; i++) {
      item = data[i];
      this._add_branch(item);
      item.$level = this.calculateItemLevel(item);

      if (!this.utilsService.defined(item.$open)) {
        item.$open = this.utilsService.defined(item.open) ? item.open : this.$openInitially();
      }

    }
    this._updateOrder();
  }
  _isSplitItem(item) {
    return (item.render == "split" && this.hasChild(item.id));
  }
  parse(data) {
    this.ganttObject.callEvent("onBeforeParse", [data]);
    var loaded = this.dataStore._parseInner(data);
    this._buildTree(loaded);
    this.filter();
    this.ganttObject.callEvent("onParse", [loaded]);
  }

  _addItemInner(item, index) {

    var parent = this.getParent(item);

    if (!this.utilsService.defined(parent)) {
      parent = this.$getRootId();
      this.setParent(item, parent);
    }

    var parentIndex = this.dataStore.getIndexById(parent);
    var targetIndex = parentIndex + Math.min(Math.max(index, 0), this.visibleOrder.length);

    if (targetIndex * 1 !== targetIndex) {
      targetIndex = undefined;
    }
    this._addItemInner.call(this, item, targetIndex);
    this.setParent(item, parent);

    if (item.hasOwnProperty("$rendered_parent")) {
      this._move_branch(item, item.$rendered_parent);
    }
    this._add_branch(item, index);
  }
  _changeIdInner(oldId, newId) {
    var children = this.getChildren(oldId);
    var visibleOrder = this._searchVisibleOrder[oldId];

    this._changeIdInner.call(this, oldId, newId);

    var parent = this.getParent(newId);

    this._replace_branch_child(parent, oldId, newId);
    for (var i = 0; i < children.length; i++) {
      this.setParent(this.dataStore.getItem(children[i]), newId);
    }

    this._searchVisibleOrder[newId] = visibleOrder;
    delete this._branches[oldId];
  }

  _traverseBranches(code, parent?) {
    parent = parent || this.$getRootId();
    var branch = this._branches[parent];
    if (branch) {
      for (var i = 0; i < branch.length; i++) {
        var itemId = branch[i];
        code.call(this, itemId);
        if (this._branches[itemId])
          this._traverseBranches(code, itemId);
      }
    }
  }

  _updateOrder(code?) {

    this.fullOrder = new PowerArray().$create();
    this._traverseBranches(function (taskId) {
      this.fullOrder.push(taskId);
    });

    if (code)
      this._updateOrder.call(this, code);
  }

  _removeItemInner(id) {

    var items = [];
    this.eachItem(function (child) {
      items.push(child);
    }, id);

    items.push(this.dataStore.getItem(id));

    for (var i = 0; i < items.length; i++) {

      this._move_branch(items[i], this.getParent(items[i]), null);
      DataStore.prototype._removeItemInner.call(this, items[i].id);
      this._move_branch(items[i], this.getParent(items[i]), null);
    }
  }

  move(sid, tindex, parent) {
    //target id as 4th parameter
    var id = arguments[3];
    if (id) {
      if (id === sid) return;

      parent = this.getParent(id);
      tindex = this.getBranchIndex(id);
    }
    if (sid == parent) {
      return;
    }
    parent = parent || this.$getRootId();
    var source = this.dataStore.getItem(sid);
    var source_pid = this.getParent(source.id);

    var tbranch = this.getChildren(parent);

    if (tindex == -1)
      tindex = tbranch.length + 1;
    if (source_pid == parent) {
      var sindex = this.getBranchIndex(sid);
      if (sindex == tindex) return;
    }

    if (this.ganttObject.callEvent("onBeforeItemMove", [sid, parent, tindex]) === false)
      return false;

    this._replace_branch_child(source_pid, sid);
    tbranch = this.getChildren(parent);

    var tid = tbranch[tindex];
    if (!tid) //adding as last element
      tbranch.push(sid);
    else
      tbranch = tbranch.slice(0, tindex).concat([sid]).concat(tbranch.slice(tindex));

    this.setParent(source, parent);
    this._branches[parent] = tbranch;

    var diff = this.calculateItemLevel(source) - source.$level;
    source.$level += diff;
    this.eachItem(function (item) {
      item.$level += diff;
    }, source.id)// , this);


    this.dataStore._moveInner(this.dataStore.getIndexById(sid), this.dataStore.getIndexById(parent) + tindex);

    this.ganttObject.callEvent("onAfterItemMove", [sid, parent, tindex]);
    this.dataStore.refresh();
  }

  getBranchIndex(id) {
    var branch = this.getChildren(this.getParent(id));
    for (var i = 0; i < branch.length; i++)
      if (branch[i] == id)
        return i;

    return -1;
  }
  hasChild(id) {
    return (this.utilsService.defined(this._branches[id]) && this._branches[id].length);
  }
  getChildren(id) {
    return this.utilsService.defined(this._branches[id]) ? this._branches[id] : new PowerArray().$create();
  }

  isChildOf(childId, parentId) {
    if (!this.dataStore.exists(childId))
      return false;
    if (parentId === this.$getRootId())
      return true;

    if (!this.hasChild(parentId))
      return false;

    var item = this.dataStore.getItem(childId);
    var pid = this.getParent(childId);

    var parent = this.dataStore.getItem(parentId);
    if (parent.$level >= item.$level) {
      return false;
    }

    while (item && this.dataStore.exists(pid)) {
      item = this.dataStore.getItem(pid);

      if (item && item.id == parentId)
        return true;
      pid = this.getParent(item);
    }
    return false;
  }

  getSiblings(id) {
    if (!this.dataStore.exists(id)) {
      return new PowerArray().$create();
    }
    var parent = this.getParent(id);
    return this.getChildren(parent);

  }
  getNextSibling(id) {
    var siblings = this.getSiblings(id);
    for (var i = 0, len = siblings.length; i < len; i++) {
      if (siblings[i] == id)
        return siblings[i + 1] || null;
    }
    return null;
  }
  getPrevSibling(id) {
    var siblings = this.getSiblings(id);
    for (var i = 0, len = siblings.length; i < len; i++) {
      if (siblings[i] == id)
        return siblings[i - 1] || null;
    }
    return null;
  }
  getParent(id) {
    var item = null;
    if (id.id !== undefined) {
      item = id;
    } else {
      item = this.dataStore.getItem(id);
    }

    var parent;
    if (item) {
      parent = item[this.$parentProperty];
    } else {
      parent = this.$getRootId();
    }
    return parent;

  }

  clearAll() {
    this._branches = {};
    DataStore.prototype.clearAll.call(this);
  }

  calculateItemLevel(item) {
    var level = 0;
    this.eachParent(function () {
      level++;
    }, item);
    return level;
  }

  _setParentInner(item, new_pid, silent) {
    if (!silent) {
      if (item.hasOwnProperty("$rendered_parent")) {
        this._move_branch(item, item.$rendered_parent, new_pid);
      } else {
        this._move_branch(item, item[this.$parentProperty], new_pid);
      }
    }
  }
  setParent(item, new_pid, silent?) {
    this._setParentInner(item, new_pid, silent);

    item[this.$parentProperty] = new_pid;
  }
  eachItem(code, parent) {
    parent = parent || this.$getRootId();


    var branch = this.getChildren(parent);
    if (branch)
      for (var i = 0; i < branch.length; i++) {
        var item = this.pull[branch[i]];
        code.call(this, item);
        if (this.hasChild(item.id))
          this.eachItem(code, item.id);
      }
  }
  eachParent(code, startItem) {
    var parentsHash = {};
    var item = startItem;
    var parent = this.getParent(item);

    while (this.dataStore.exists(parent)) {
      if (parentsHash[parent]) {
        throw new Error("Invalid tasks tree. Cyclic reference has been detected on task " + parent);
      }
      parentsHash[parent] = true;
      item = this.dataStore.getItem(parent);
      code.call(this, item);
      parent = this.getParent(item);
    }
  }
  _add_branch(item, index?, parent?) {
    var pid = parent === undefined ? this.getParent(item) : parent;
    if (!this.hasChild(pid))
      this._branches[pid] = new PowerArray().$create();
    var branch = this.getChildren(pid);
    var added_already = false;
    for (var i = 0, length = branch.length; i < length; i++) {
      if (branch[i] == item.id) {
        added_already = true;
        break;
      }
    }
    if (!added_already) {
      if (index * 1 == index) {

        branch.splice(index, 0, item.id);
      } else {
        branch.push(item.id);
      }

      item.$rendered_parent = pid;
    }
  }
  _move_branch(item, old_parent, new_parent?) {
    //this.setParent(item, new_parent);
    //this._sync_parent(task);
    this._replace_branch_child(old_parent, item.id);
    if (this.dataStore.exists(new_parent) || new_parent == this.$getRootId()) {

      this._add_branch(item, undefined, new_parent);
    } else {
      delete this._branches[item.id];
    }
    item.$level = this.calculateItemLevel(item);
    this.eachItem(function (child) {
      child.$level = this.calculateItemLevel(child);
    }, item.id);
  }

  _replace_branch_child(node, old_id, new_id?) {
    var branch = this.getChildren(node);
    if (branch && node !== undefined) {
      var newbranch = new PowerArray().$create();
      for (var i = 0; i < branch.length; i++) {
        if (branch[i] != old_id)
          newbranch.push(branch[i]);
        else if (new_id)
          newbranch.push(new_id);
      }
      this._branches[node] = newbranch;
    }

  }

  sort(field, desc, parent) {
    if (!this.dataStore.exists(parent)) {
      parent = this.$getRootId();
    }

    if (!field) field = "order";
    var criteria = (typeof (field) == "string") ? (function (a, b) {
      if (a[field] == b[field]) {
        return 0;
      }

      var result = a[field] > b[field];
      return result ? 1 : -1;
    }) : field;

    if (desc) {
      var original_criteria = criteria;
      criteria = function (a, b) {
        return original_criteria(b, a);
      };
    }

    var els = this.getChildren(parent);

    if (els) {
      var temp = [];
      for (var i = els.length - 1; i >= 0; i--)
        temp[i] = this.dataStore.getItem(els[i]);

      temp.sort(criteria);

      for (var i = 0; i < temp.length; i++) {
        els[i] = temp[i].id;
        this.sort(field, desc, els[i]);
      }
    }
  }

  filter(rule?) {
    for (var i in this.pull) {
      if (this.pull[i].$rendered_parent !== this.getParent(this.pull[i])) {
        this._move_branch(this.pull[i], this.pull[i].$rendered_parent, this.getParent(this.pull[i]));
      }
    }
    return DataStore.prototype.filter.apply(this, arguments);
  }

  open(id) {
    if (this.dataStore.exists(id)) {
      this.dataStore.getItem(id).$open = true;
      this.ganttObject.callEvent("onItemOpen", [id]);
    }
  }

  close(id) {
    if (this.dataStore.exists(id)) {
      this.dataStore.getItem(id).$open = false;
      this.ganttObject.callEvent("onItemClose", [id]);
    }
  }

  destructor() {
    DataStore.prototype.destructor.call(this);
    this._branches = null;
  }

}

export class PowerArray {
  utils: UtilsService;
  $create(array?) {
    return this.utils.mixin(array || [], this);
  }

  //remove element at specified position
  $removeAt = function (pos, len?) {
    if (pos >= 0) { this.splice(pos, (len || 1)); }
  }

  //find element in collection and remove it
  $remove(value) {
    this.$removeAt(this.$find(value));
  }

  //add element to collection at specific position
  $insertAt = function (data, pos) {
    if (!pos && pos !== 0) 	//add to the end by default
      this.push(data);
    else {
      var b = this.splice(pos, (this.length - pos));
      this[pos] = data;
      this.push.apply(this, b); //reconstruct array without loosing this pointer
    }
  }

  //return index of element, -1 if it doesn't exists
  $find = function (data) {
    for (var i = 0; i < this.length; i++)
      if (data == this[i]) return i;
    return -1;
  }

  //execute some method for each element of array
  $each = function (functor, master) {
    for (var i = 0; i < this.length; i++)
      functor.call((master || this), this[i]);
  }

  //create new array from source, by using results of functor
  $map = function (functor, master) {
    for (var i = 0; i < this.length; i++)
      this[i] = functor.call((master || this), this[i]);
    return this;
  }

  $filter = function (functor, master) {
    for (var i = 0; i < this.length; i++)
      if (!functor.call((master || this), this[i])) {
        this.splice(i, 1);
        i--;
      }
    return this;
  }

}

export class ScaleHelper {
  //  ScaleHelper(gantt) {
  ganttObject: GanttObjectService;
  utils: UtilsService;
  dateHelper = this.ganttObject.gantt.date;
  services = this.ganttObject.gantt.$services;


  getSum(sizes, from?, to?) {
    if (to === undefined)
      to = sizes.length - 1;
    if (from === undefined)
      from = 0;

    var summ = 0;
    for (var i = from; i <= to; i++)
      summ += sizes[i];

    return summ;
  }

  setSumWidth(sum_width, scale, from, to) {
    var parts = scale.width;

    if (to === undefined)
      to = parts.length - 1;
    if (from === undefined)
      from = 0;
    var length = to - from + 1;

    if (from > parts.length - 1 || length <= 0 || to > parts.length - 1)
      return;

    var oldWidth = this.getSum(parts, from, to);

    var diff = sum_width - oldWidth;

    this.adjustSize(diff, parts, from, to);
    this.adjustSize(-diff, parts, to + 1);

    scale.full_width = this.getSum(parts);
  }

  splitSize(width, count) {
    var arr = [];
    for (var i = 0; i < count; i++) arr[i] = 0;

    this.adjustSize(width, arr);
    return arr;

  }

  adjustSize(width, parts, from?, to?) {
    if (!from)
      from = 0;
    if (to === undefined)
      to = parts.length - 1;

    var length = to - from + 1;

    var full = this.getSum(parts, from, to);

    for (var i = from; i <= to; i++) {
      var share = Math.floor(width * (full ? (parts[i] / full) : (1 / length)));

      full -= parts[i];
      width -= share;
      length--;

      parts[i] += share;
    }
    parts[parts.length - 1] += width;
  }

  sortScales(scales) {
    function cellSize(unit, step) {
      var d = new Date(1970, 0, 1);
      return this.dateHelper.add(d, step, unit) - new Date(d).getDate();
    }

    scales.sort(function (a, b) {
      if (cellSize(a.unit, a.step) < cellSize(b.unit, b.step)) {
        return 1;
      } else if (cellSize(a.unit, a.step) > cellSize(b.unit, b.step)) {
        return -1;
      } else {
        return 0;
      }
    });

    for (var i = 0; i < scales.length; i++) {
      scales[i].index = i;
    }
  }

  _isLegacyMode(config) {
    var scaleConfig = config || this.services.config();
    return scaleConfig.scale_unit || scaleConfig.date_scale || scaleConfig.subscales;
  }

  _prepareScaleObject(scale) {
    var format = scale.format;
    if (!format) {
      format = scale.template || scale.date || "%d %M";
    }

    if (typeof format === "string") {
      format = this.ganttObject.gantt.date.date_to_str(format);
    }
    return {
      unit: scale.unit || "day",
      step: scale.step || 1,
      format: format,
      css: scale.css
    };
  }

  primaryScale(config?) {
    var templates = this.services.getService("templateLoader");
    var legacyMode = this._isLegacyMode(config);

    var scaleConfig = config || this.services.config();

    var result;
    if (legacyMode) {
      templates.initTemplate("date_scale", undefined, undefined, scaleConfig, this.services.templates());
      result = {
        unit: this.services.config().scale_unit,
        step: this.services.config().step,
        template: this.services.templates().date_scale,
        date: this.services.config().date_scale,
        css: this.services.templates().scale_cell_class
      };
    } else {
      var primaryScale = scaleConfig.scales[0];
      result = {
        unit: primaryScale.unit,
        step: primaryScale.step,
        template: primaryScale.template,
        format: primaryScale.format,
        date: primaryScale.date,
        css: primaryScale.css || this.services.templates().scale_cell_class
      };
    }

    return this._prepareScaleObject(result);
  }

  getSubScales(config?) {
    var legacyMode = this._isLegacyMode(config);
    var scaleConfig = config || this.services.config();
    var scales;
    if (legacyMode) {
      scales = scaleConfig.subscales || [];
    } else {
      scales = scaleConfig.scales.slice(1);
    }

    return scales.map(function (scale) {
      return this._prepareScaleObject(scale);
    }.bind(this));
  }


  prepareConfigs(scales, min_coll_width, container_width, scale_height, minDate, maxDate, rtl) {
    var heights = this.splitSize(scale_height, scales.length);
    var full_width = container_width;

    var configs = [];
    for (var i = scales.length - 1; i >= 0; i--) {
      var main_scale = (i == scales.length - 1);
      var cfg = this.initScaleConfig(scales[i], minDate, maxDate);
      if (main_scale) {
        this.processIgnores(cfg);
      }

      this.initColSizes(cfg, min_coll_width, full_width, heights[i]);
      this.limitVisibleRange(cfg);

      if (main_scale) {
        full_width = cfg.full_width;
      }

      configs.unshift(cfg);
    }


    for (var i = 0; i < configs.length - 1; i++) {
      this.alineScaleColumns(configs[configs.length - 1], configs[i]);
    }
    for (var i = 0; i < configs.length; i++) {

      if (rtl) {
        this.reverseScale(configs[i]);
      }
      this.setPosSettings(configs[i]);
    }
    return configs;

  }


  reverseScale(scale) {
    scale.width = scale.width.reverse();
    scale.trace_x = scale.trace_x.reverse();

    var indexes = scale.trace_indexes;
    scale.trace_indexes = {};
    scale.trace_index_transition = {};
    scale.rtl = true;
    for (var i = 0; i < scale.trace_x.length; i++) {
      scale.trace_indexes[scale.trace_x[i].valueOf()] = i;
      scale.trace_index_transition[indexes[scale.trace_x[i].valueOf()]] = i;
    }
    return scale;
  }

  setPosSettings(config) {
    for (var i = 0, len = config.trace_x.length; i < len; i++) {
      config.left.push((config.width[i - 1] || 0) + (config.left[i - 1] || 0));
    }
  }

  _ignore_time_config(date, scale) {

    if (this.services.config().skip_off_time) {
      var skip = true;
      var probe = date;

      // check dates in case custom scale unit, e.g. {unit: "month", step: 3}
      for (var i = 0; i < scale.step; i++) {
        if (i) {
          probe = this.dateHelper.add(date, i, scale.unit);
        }

        skip = skip //&& !this.isWorkTime(probe, scale.unit);
      }

      return skip;
    }
    return false;
  }

  //defined in an extension
  processIgnores(config) {
    config.ignore_x = {};
    config.display_count = config.count;
  }

  initColSizes(config, min_col_width, full_width, line_height) {
    var cont_width = full_width;

    config.height = line_height;

    var column_count = config.display_count === undefined ? config.count : config.display_count;

    if (!column_count)
      column_count = 1;

    config.col_width = Math.floor(cont_width / column_count);

    if (min_col_width) {
      if (config.col_width < min_col_width) {
        config.col_width = min_col_width;
        cont_width = config.col_width * column_count;
      }
    }
    config.width = [];
    var ignores = config.ignore_x || {};
    for (var i = 0; i < config.trace_x.length; i++) {
      if (ignores[config.trace_x[i].valueOf()] || (config.display_count == config.count)) {
        config.width[i] = 0;
      } else {
        // width of month columns should be proportional month duration
        var width = 1;
        if (config.unit == "month") {
          var days = Math.round((this.dateHelper.add(config.trace_x[i], config.step, config.unit) - config.trace_x[i]) / (1000 * 60 * 60 * 24));
          width = days;
        }
        config.width[i] = width;
      }
    }

    this.adjustSize(cont_width - this.getSum(config.width)/* 1 width per column from the code above */, config.width);
    config.full_width = this.getSum(config.width);
  }

  initScaleConfig(config, min_date, max_date) {
    var cfg = this.utils.mixin({
      count: 0,
      col_width: 0,
      full_width: 0,
      height: 0,
      width: [],
      left: [],
      trace_x: [],
      trace_indexes: {},
      min_date: new Date(min_date),
      max_date: new Date(max_date)
    }, config);

    this.eachColumn(config.unit, config.step, min_date, max_date, function (date) {
      cfg.count++;
      cfg.trace_x.push(new Date(date));
      cfg.trace_indexes[date.valueOf()] = cfg.trace_x.length - 1;
    });

    cfg.trace_x_ascending = cfg.trace_x.slice();
    return cfg;
  }

  iterateScales(lower_scale, upper_scale, from, to, callback) {
    var upper_dates = upper_scale.trace_x;
    var lower_dates = lower_scale.trace_x;

    var prev = from || 0;
    var end = to || (lower_dates.length - 1);
    var prevUpper = 0;


    for (var up = 1; up < upper_dates.length; up++) {
      var target_index = (lower_scale.trace_indexes[+upper_dates[up]]);
      if (target_index !== undefined && target_index <= end) {
        if (callback) {
          callback.apply(this, [prevUpper, up, prev, target_index]);
        }
        prev = target_index;
        prevUpper = up;
        continue;
      }
    }
  }

  alineScaleColumns(lower_scale, upper_scale, from?, to?) {
    this.iterateScales(lower_scale, upper_scale, from, to, function (upper_start, upper_end, lower_start, lower_end) {
      var targetWidth = this.getSum(lower_scale.width, lower_start, lower_end - 1);
      var actualWidth = this.getSum(upper_scale.width, upper_start, upper_end - 1);
      if (actualWidth != targetWidth) {
        this.setSumWidth(targetWidth, upper_scale, upper_start, upper_end - 1);
      }

    });
  }

  eachColumn(unit, step, min_date, max_date, callback) {
    var start = new Date(min_date),
      end = new Date(max_date);
    if (this.dateHelper[unit + "_start"]) {
      start = this.dateHelper[unit + "_start"](start);
    }

    var curr = new Date(start);
    if (+curr >= +end) {
      end = this.dateHelper.add(curr, step, unit);
    }
    while (+curr < +end) {
      callback.call(this, new Date(curr));
      var tzOffset = curr.getTimezoneOffset();
      curr = this.dateHelper.add(curr, step, unit);
      curr = this.ganttObject._correct_dst_change(curr, tzOffset, step, unit);
      if (this.dateHelper[unit + '_start'])
        curr = this.dateHelper[unit + "_start"](curr);
    }
  }

  limitVisibleRange(cfg) {
    var dates = cfg.trace_x;

    var left = 0, right = cfg.width.length - 1;
    var diff = 0;
    if (+dates[0] < +cfg.min_date && left != right) {
      var width = Math.floor(cfg.width[0] * ((dates[1] - cfg.min_date) / (dates[1] - dates[0])));
      diff += cfg.width[0] - width;
      cfg.width[0] = width;

      dates[0] = new Date(cfg.min_date);
    }

    var last = dates.length - 1;
    var lastDate = dates[last];
    var outDate = this.dateHelper.add(lastDate, cfg.step, cfg.unit);
    if (+outDate > +cfg.max_date && last > 0) {
      var width = cfg.width[last] - Math.floor(cfg.width[last] * ((outDate - cfg.max_date) / (outDate - lastDate)));
      diff += cfg.width[last] - width;
      cfg.width[last] = width;
    }

    if (diff) {
      var full = this.getSum(cfg.width);
      var shared = 0;
      for (var i = 0; i < cfg.width.length; i++) {
        var share = Math.floor(diff * (cfg.width[i] / full));
        cfg.width[i] += share;
        shared += share;
      }
      this.adjustSize(diff - shared, cfg.width);
    }

  }

}

export class Datastore {

  utils: UtilsService;
  createTasksFacade = new DatastoreTasks();
  createLinksFacade = new DatastoreLinks();
  dataStore = DataStore;
  treeDataStore = TreeDataStore;
  createDatastoreSelect = new Select();
  datastoreRender = new DataStoreRender();
  $services: any;

  createDatastoreFacade = {
    //   return {
    createDatastore(config) {

      var $StoreType = (config.type || "").toLowerCase() == "treedatastore" ? TreeDataStore : DataStore;

      if (config) {
        var self = this;
        config.openInitially = function () { return self.config.open_tree_initially; };
      }

      var store = new $StoreType(config);
      this.mixin(store, this.createDatastoreSelect(store));

      if (config.name) {
        var servicePrefix = "datastore:";

        this.$services.dropService(servicePrefix + config.name);
        this.$services.setService(servicePrefix + config.name, function () { return store; });

        var storeList = this.$services.getService("datastores");
        if (!storeList) {
          storeList = [];
          this.$services.setService("datastores", function () { return storeList; });
          storeList.push(config.name);
        } else if (storeList.indexOf(config.name) < 0) {
          storeList.push(config.name);
        }

        this.datastoreRender.bindDataStore(config.name, this);
      }

      return store;
    },

    getDatastore(name) {
      return this.$services.getService("datastore:" + name);
    },

    refreshData() {
      var scrollState = this.getScrollState();
      this.callEvent("onBeforeDataRender", []);

      var stores = this.getDatastores.call(this);
      for (var i = 0; i < stores.length; i++) {
        stores[i].refresh();
      }

      if (scrollState.x || scrollState.y) {
        this.scrollTo(scrollState.x, scrollState.y);
      }
      this.callEvent("onDataRender", []);
    },

    isChildOf(childId, parentId) {
      return this.$data.tasksStore.isChildOf(childId, parentId);
    },

    refreshTask(taskId, refresh_links) {
      var task = this.getTask(taskId);
      if (task && this.isTaskVisible(taskId)) {

        this.$data.tasksStore.refresh(taskId, !!this.getState().drag_id);// do quick refresh during drag and drop

        if (refresh_links !== undefined && !refresh_links)
          return;
        for (var i = 0; i < task.$source.length; i++) {
          this.refreshLink(task.$source[i]);
        }
        for (var i = 0; i < task.$target.length; i++) {
          this.refreshLink(task.$target[i]);
        }
      } else if (this.isTaskExists(taskId) && this.isTaskExists(this.getParent(taskId))) {
        this.refreshTask(this.getParent(taskId));
      }

    },

    refreshLink(linkId) {
      this.$data.linksStore.refresh(linkId, !!this.getState().drag_id);// do quick refresh during drag and drop
    },

    silent(code) {
      var gantt = this;
      gantt.$data.tasksStore.silent(function () {
        gantt.$data.linksStore.silent(function () {
          code();
        });
      });
    },

    clearAll() {
      var stores = this.getDatastores.call(this);
      for (var i = 0; i < stores.length; i++) {
        stores[i].clearAll();
      }

      this._update_flags();
      this.userdata = {};
      this.callEvent("onClear", []);
      this.render();
    },

    _clear_data() {
      this.$data.tasksStore.clearAll();
      this.$data.linksStore.clearAll();
      this._update_flags();
      this.userdata = {};
    },

    selectTask(id) {
      var store = this.$data.tasksStore;
      if (!this.config.select_task)
        return false;
      if (id) {

        store.select(id);
      }
      return store.getSelectedId();
    },

    unselectTask(id) {
      var store = this.$data.tasksStore;
      store.unselect(id);
    },

    isSelectedTask(id) {
      return this.$data.tasksStore.isSelected(id);
    },

    getSelectedId() {
      return this.$data.tasksStore.getSelectedId();
    },
  }

  getDatastores() {
    var storeNames = this.$services.getService("datastores");
    var res = [];
    for (var i = 0; i < storeNames.length; i++) {
      res.push(this.createDatastoreFacade.getDatastore(storeNames[i]));
    }
    return res;
  }

  createFacade() {
    var res = this.utils.mixin({}, this.createDatastoreFacade);
    this.utils.mixin(res, this.createTasksFacade.createTasksDatastoreFacade);
    this.utils.mixin(res, this.createLinksFacade.createLinksStoreFacade);
    return res;
  }

  // return { create: createFacade };

  /***/
}

export class Select {

  ganttObject: GanttObjectService;

  createDataStoreSelectMixin(store) {
    var selectedId = null;

    var deleteItem = store._removeItemInner;

    store._removeItemInner = function (id) {
      if (selectedId == id) {
        this.unselect.call(this, id);
      }

      if (selectedId && this.eachItem) {
        this.eachItem(function (subItem) {
          if (subItem.id == selectedId) {
            this.unselect.call(this, subItem.id);
          }
        }, id);
      }

      return deleteItem.apply(this, arguments);
    };

    store.attachEvent("onIdChange", function (oldId, newId) {
      if (store.getSelectedId() == oldId) {
        store.silent(function () {
          store.unselect(oldId);
          store.select(newId);
        });
      }
    });

    return {
      select(id) {
        if (id) {

          if (selectedId == id)
            return selectedId;

          if (!this._skip_refresh) {
            if (!this.callEvent("onBeforeSelect", [id])) {
              return false;
            }
          }

          this.unselect();

          selectedId = id;

          if (!this._skip_refresh) {
            this.refresh(id);
            this.callEvent("onAfterSelect", [id]);
          }
        }
        return selectedId;
      },
      getSelectedId() {
        return selectedId;
      },
      isSelected(id) {
        return id == selectedId;
      },
      unselect(id) {
        var id = id || selectedId;
        if (!id)
          return;
        selectedId = null;
        if (!this._skip_refresh) {
          this.refresh(id);
          this.unselect.call(this, id);
        }
      }
    };
  }

  unselect(id) {
    const selectedId = null;
    this.ganttObject.callEvent("onAfterUnselect", [id]);
  }

  // return createDataStoreSelectMixin;

}

export class DataStoreRender {

  storeRenderCreator(name, gantt) {
    var store = gantt.getDatastore(name);

    var itemRepainter = {
      renderItem(id, renderer) {

        var renders = renderer.getLayers();

        var item = store.getItem(id);
        if (item && store.isVisible(id)) {
          for (var i = 0; i < renders.length; i++)
            renders[i].render_item(item);
        }
      },
      renderItems(renderer) {
        var renderers = renderer.getLayers();
        for (var i = 0; i < renderers.length; i++) {
          renderers[i].clear();
        }

        var data = store.getVisibleItems();

        for (var i = 0; i < renderers.length; i++) {
          renderers[i].render_items(data);
        }
      },
      updateItems(layer) {
        if (layer.update_items) {
          var data = store.getVisibleItems();
          layer.update_items(data);
        }
      }
    };

    store.attachEvent("onStoreUpdated", function (id, item, action) {
      var renderer = gantt.$services.getService("layers").getDataRender(name);
      if (renderer) {
        renderer.onUpdateRequest = function (layer) {
          itemRepainter.updateItems(layer);
        };
      }
    });

    function skipRepaint(gantt) {
      var state = gantt.$services.getService("state");
      if (state.getState("batchUpdate").batch_update) {
        return true;
      } else {
        return false;
      }
    }

    store.attachEvent("onStoreUpdated", function (id, item, action) {
      if (skipRepaint(gantt)) {
        return;
      }

      var renderer = gantt.$services.getService("layers").getDataRender(name);

      if (renderer) {
        if (!id || action == "move" || action == "delete") {
          store.callEvent("onBeforeRefreshAll", []);
          itemRepainter.renderItems(renderer);
          store.callEvent("onAfterRefreshAll", []);
        } else {
          store.callEvent("onBeforeRefreshItem", [item.id]);
          itemRepainter.renderItem(item.id, renderer);
          store.callEvent("onAfterRefreshItem", [item.id]);
        }
      }

    });

    // TODO: probably can be done more in a more efficient way
    store.attachEvent("onItemOpen", function () {
      gantt.render();
    });

    store.attachEvent("onItemClose", function () {
      gantt.render();
    });

    function refreshId(renders, oldId, newId, item) {
      for (var i = 0; i < renders.length; i++) {
        renders[i].change_id(oldId, newId);
      }
    }

    store.attachEvent("onIdChange", function (oldId, newId) {

      // in case of linked datastores (tasks <-> links), id change should recalculate something in linked datastore before any repaint
      // use onBeforeIdChange for this hook.
      // TODO: use something more reasonable instead
      store.callEvent("onBeforeIdChange", [oldId, newId]);

      if (skipRepaint(gantt)) {
        return;
      }
      var renderer = gantt.$services.getService("layers").getDataRender(name);
      refreshId(renderer.getLayers(), oldId, newId, store.getItem(newId));
      itemRepainter.renderItem(newId, renderer);
    });

  }

  // return {
  //   bindDataStore: storeRenderCreator
  // };

  /***/
}

export class DataStoreHooks {

  utils: UtilsService;
  ganttObject: GanttObjectService
  facadeFactory = new Datastore();
  calculateScaleRange = new DataRange();

  facade = this.facadeFactory.createFacade();
  mixin = this.utils.mixin(this.ganttObject.gantt, this.facade);
  tasksStore = this.facadeFactory.createDatastoreFacade.createDatastore({
    name: "task",
    type: "treeDatastore",
    rootId: function () { return this.ganttObject.gantt.config.root_id; },
    initItem: this.utils.bind(this._init_task, this.ganttObject),
    getConfig: function () { return this.gantt.config; }
  });

  linksStore = this.facadeFactory.createDatastoreFacade.createDatastore({
    name: "link",
    initItem: this.utils.bind(this._init_link, this.ganttObject)
  });
  config: any;

  // gantt.attachEvent("onDestroy", (() => {
  //   this.tasksStore.destructor();
  //   this.linksStore.destructor();
  // });

  // this.tasksStore.attachEvent("onBeforeRefreshAll", function() {

  //   var order = this.tasksStore.getVisibleItems();

  //   for (var i = 0; i < order.length; i++) {
  //     var item = order[i];
  //     item.$index = i;
  //     gantt.resetProjectDates(item);
  //   }

  // });

  // this.tasksStore.attachEvent("onFilterItem", function(id, task) {
  //   var min = null, max = null;
  //   if (gantt.config.start_date && gantt.config.end_date) {
  //     if (gantt._isAllowedUnscheduledTask(task)) return true;
  //     min = gantt.config.start_date.valueOf();
  //     max = gantt.config.end_date.valueOf();

  //     if (+task.start_date > max || +task.end_date < +min)
  //       return false;
  //   }
  //   return true;
  // });

  // this.tasksStore.attachEvent("onIdChange", function(oldId, newId) {
  //   gantt._update_flags(oldId, newId);
  // });

  // tasksStore.attachEvent("onAfterUpdate", function(id) {
  //   gantt._update_parents(id);
  //   if (gantt.getState("batchUpdate").batch_update) {
  //     return true;
  //   }

  //   var task = tasksStore.getItem(id);
  //   for (var i = 0; i < task.$source.length; i++) {
  //     linksStore.refresh(task.$source[i]);
  //   }
  //   for (var i = 0; i < task.$target.length; i++) {
  //     linksStore.refresh(task.$target[i]);
  //   }
  // });

  // tasksStore.attachEvent("onAfterItemMove", function(sid, parent, tindex) {
  //   var source = gantt.getTask(sid);

  //   if (this.getNextSibling(sid) !== null) {
  //     source.$drop_target = this.getNextSibling(sid);
  //   } else if (this.getPrevSibling(sid) !== null) {
  //     source.$drop_target = "next:" + this.getPrevSibling(sid);
  //   } else {
  //     source.$drop_target = "next:null";
  //   }

  // });

  // tasksStore.attachEvent("onStoreUpdated", function(id, item, action) {
  //   if (action == "delete") {
  //     gantt._update_flags(id, null);
  //   }

  //   var state = gantt.$services.getService("state");
  //   if (state.getState("batchUpdate").batch_update) {
  //     return;
  //   }

  //   if (gantt.config.fit_tasks && action !== "paint") {
  //     var oldState = gantt.getState();
  //     calculateScaleRange(gantt);
  //     var newState = gantt.getState();

  //     //this._init_tasks_range();
  //     if (+oldState.min_date != +newState.min_date || +oldState.max_date != +newState.max_date) {
  //       gantt.render();

  //       gantt.callEvent("onScaleAdjusted", []);
  //       return true;
  //     }

  //   }

  //   if (action == "add" || action == "move" || action == "delete") {
  //     gantt.$layout.resize();
  //   } else if (!id) {
  //     linksStore.refresh();
  //   }

  // });

  // linksStore.attachEvent("onAfterAdd", function(id, link) {
  //   sync_link(link);
  // });
  // linksStore.attachEvent("onAfterUpdate", function(id, link) {
  //   sync_links();
  // });
  // linksStore.attachEvent("onAfterDelete", function(id, link) {
  //   sync_link_delete(link);
  // });
  // linksStore.attachEvent("onBeforeIdChange", function(oldId, newId) {
  //   sync_link_delete(gantt.mixin({ id: oldId }, gantt.$data.linksStore.getItem(newId)));
  //   sync_link(gantt.$data.linksStore.getItem(newId));
  // });

  checkLinkedTaskVisibility(taskId) {
    var isVisible = this.ganttObject.isTaskVisible(taskId);
    if (!isVisible && this.ganttObject.isTaskExists(taskId)) {
      var parent = this.ganttObject.getParent(taskId);
      if (this.ganttObject.isTaskExists(parent) && this.ganttObject.isTaskVisible(parent)) {
        parent = this.ganttObject.getTask(parent);
        if (this.ganttObject.isSplitTask(parent)) {
          isVisible = true;
        }
      }
    }
    return isVisible;
  }

  // linksStore.attachEvent("onFilterItem", function(id, link) {
  //   if (!gantt.config.show_links) {
  //     return false;
  //   }

  //   var sourceVisible = checkLinkedTaskVisibility(link.source);
  //   var targetVisible = checkLinkedTaskVisibility(link.target);

  //   if (!(sourceVisible && targetVisible) ||
  //     gantt._isAllowedUnscheduledTask(gantt.getTask(link.source)) || gantt._isAllowedUnscheduledTask(gantt.getTask(link.target)))
  //     return false;

  //   return gantt.callEvent("onBeforeLinkDisplay", [id, link]);
  // });


  // (function () {
  //   // delete all connected links after task is deleted
  //   var treeHelper = this.utilsService.task_tree_helpers();
  //   var deletedLinks = {};

  //   gantt.attachEvent("onBeforeTaskDelete", function (id, item) {
  //     deletedLinks[id] = treeHelper.getSubtreeLinks(gantt, id);
  //     return true;
  //   });

  //   gantt.attachEvent("onAfterTaskDelete", function (id, item) {
  //     if (deletedLinks[id]) {
  //       gantt.$data.linksStore.silent(function () {
  //         for (var i in deletedLinks[id]) {
  //           gantt.$data.linksStore.removeItem(i);
  //           sync_link_delete(deletedLinks[id][i]);
  //         }

  //         deletedLinks[id] = null;
  //       });
  //     }
  //   });
  // })();

  // gantt.attachEvent("onAfterLinkDelete", function (id, link) {
  //   gantt.refreshTask(link.source);
  //   gantt.refreshTask(link.target);
  // });

  // gantt.attachEvent("onParse", sync_links);

  // this.mapEvents({
  //   source: linksStore,
  //   target: gantt,
  //   events: {
  //     "onItemLoading": "onLinkLoading",
  //     "onBeforeAdd": "onBeforeLinkAdd",
  //     "onAfterAdd": "onAfterLinkAdd",
  //     "onBeforeUpdate": "onBeforeLinkUpdate",
  //     "onAfterUpdate": "onAfterLinkUpdate",
  //     "onBeforeDelete": "onBeforeLinkDelete",
  //     "onAfterDelete": "onAfterLinkDelete",
  //     "onIdChange": "onLinkIdChange"
  // }
  // });

  // this.mapEvents({
  //   source: tasksStore,
  //   target: gantt,
  //   events: {
  //     "onItemLoading": "onTaskLoading",
  //     "onBeforeAdd": "onBeforeTaskAdd",
  //     "onAfterAdd": "onAfterTaskAdd",
  //     "onBeforeUpdate": "onBeforeTaskUpdate",
  //     "onAfterUpdate": "onAfterTaskUpdate",
  //     "onBeforeDelete": "onBeforeTaskDelete",
  //     "onAfterDelete": "onAfterTaskDelete",
  //     "onIdChange": "onTaskIdChange",
  //     "onBeforeItemMove": "onBeforeTaskMove",
  //     "onAfterItemMove": "onAfterTaskMove",
  //     "onFilterItem": "onBeforeTaskDisplay",
  //     "onItemOpen": "onTaskOpened",
  //     "onItemClose": "onTaskClosed",
  //     "onBeforeSelect": "onBeforeTaskSelected",
  //     "onAfterSelect": "onTaskSelected",
  //     "onAfterUnselect": "onTaskUnselected"
  // }
  // });

  $data = {
    tasksStore: this.tasksStore,
    linksStore: this.linksStore
  };

  sync_link(link) {
    if (this.ganttObject.isTaskExists(link.source)) {
      var sourceTask = this.ganttObject.getTask(link.source);
      sourceTask.$source = sourceTask.$source || [];
      sourceTask.$source.push(link.id);
    }
    if (this.ganttObject.isTaskExists(link.target)) {
      var targetTask = this.ganttObject.getTask(link.target);
      targetTask.$target = targetTask.$target || [];
      targetTask.$target.push(link.id);
    }
  }

  sync_link_delete(link) {
    if (this.ganttObject.isTaskExists(link.source)) {
      var sourceTask = this.ganttObject.getTask(link.source);
      for (var i = 0; i < sourceTask.$source.length; i++) {
        if (sourceTask.$source[i] == link.id) {
          sourceTask.$source.splice(i, 1);
          break;
        }
      }
    }
    if (this.ganttObject.isTaskExists(link.target)) {
      var targetTask = this.ganttObject.getTask(link.target);
      for (var i = 0; i < targetTask.$target.length; i++) {
        if (targetTask.$target[i] == link.id) {
          targetTask.$target.splice(i, 1);
          break;
        }
      }
    }
  }

  sync_links() {
    var task = null;
    var tasks = this.ganttObject.gantt.$data.tasksStore.getItems();

    for (var i = 0, len = tasks.length; i < len; i++) {
      task = tasks[i];
      task.$source = [];
      task.$target = [];
    }

    var links = this.ganttObject.gantt.$data.linksStore.getItems();
    for (var i = 0, len = links.length; i < len; i++) {

      var link = links[i];
      this.sync_link(link);
    }
  }

  mapEvents(conf) {
    var mapFrom = conf.source;
    var mapTo = conf.target;
    for (var i in conf.events) {
      (function (sourceEvent, targetEvent) {
        mapFrom.attachEvent(sourceEvent, function () {
          return mapTo.callEvent(targetEvent, Array.prototype.slice.call(arguments));
        }, targetEvent);
      })(i, conf.events[i]);
    }
  }

  _init_task(task) {
    if (!this.utils.defined(task.id))
      task.id = this.utils.uid();

    if (task.start_date)
      task.start_date = this.ganttObject.gantt.date.parseDate(task.start_date, "parse_date");
    if (task.end_date)
      task.end_date = this.ganttObject.gantt.date.parseDate(task.end_date, "parse_date");


    var duration = null;
    if (task.duration || task.duration === 0) {
      task.duration = duration = task.duration * 1;
    }

    if (duration) {
      if (task.start_date && !task.end_date) {
        task.end_date = new TimeCalculator(this.ganttObject).calculateEndDate(task);
      } else if (!task.start_date && task.end_date) {
        task.start_date = new TimeCalculator(this.ganttObject).calculateEndDate({
          start_date: task.end_date,
          duration: -task.duration,
          task: task
        });
      }
    }

    task.progress = Number(task.progress) || 0;

    if (new Data()._isAllowedUnscheduledTask(task)) {
      new Data()._set_default_task_timing(task);
    }
    new Data()._init_task_timing(task);
    if (task.start_date && task.end_date)
      new Data().correctTaskWorkTime(task);

    task.$source = [];
    task.$target = [];
    if (task.parent === undefined) {
      task.parent = this.config.root_id;
    }
    return task;
  }

  _init_link(link) {
    if (!this.utils.defined(link.id))
      link.id = this.utils.uid();
    return link;
  }
}

export class WorkTime {

  utils: UtilsService;
  constructor(gantt) {
    var manager = new CalendarManager(gantt);
    var worktimeFacadeFactory = new WorktimeCalendars(),
      utils: UtilsService;
    var timeCalculator = new TimeCalculator(manager);
    var facade = worktimeFacadeFactory.createWorktimeFacade(manager, timeCalculator);
    this.utils.mixin(gantt, facade);
  }
  // var CalendarManager = new CalendarManager(gantt),
  // TimeCalculator = this.timeCalculator(),
  // tslint:disable-next-line: no-use-before-declare
}

export class DatastoreLinks {

  utils: UtilsService;
  $data: any;

  createLinksStoreFacade = {
    getLinkCount() {
      return this.$data.linksStore.count();
    },

    getLink(id) {
      return this.$data.linksStore.getItem(id);
    },

    getLinks() {
      return this.$data.linksStore.getItems();
    },

    isLinkExists(id) {
      return this.$data.linksStore.exists(id);
    },

    addLink(link) {
      return this.$data.linksStore.addItem(link);
    },

    updateLink(id, data) {
      if (!this.utils.defined(data)) {
        data = this.getLink(id);
      }
      this.$data.linksStore.updateItem(id, data);
    },

    deleteLink(id) {
      return this.$data.linksStore.removeItem(id);
    },

    changeLinkId(oldid, newid) {
      return this.$data.linksStore.changeId(oldid, newid);
    }

  }

  // return createLinksStoreFacade;

}

export class DatastoreTasks {

  utils: UtilsService;

  createTasksDatastoreFacade = {
    // return {
    getTask(id) {
      this.assert(id, "Invalid argument for gantt.getTask");
      var task = this.$data.tasksStore.getItem(id);
      this.assert(task, "Task not found id=" + id);
      return task;
    },
    getTaskByTime(from?, to?) {
      var p = this.$data.tasksStore.getItems();

      var res = [];

      if (!(from || to)) {
        res = p;
      } else {
        from = +from || -Infinity;
        to = +to || Infinity;
        for (var t = 0; t < p.length; t++) {
          var task = p[t];
          if (+task.start_date < to && +task.end_date > from)
            res.push(task);
        }
      }
      return res;
    },
    isTaskExists(id) {
      if (!this.$data || !this.$data.tasksStore) {
        return false;
      }
      return this.$data.tasksStore.exists(id);
    },
    updateTask(id, item) {
      if (!this.utils.defined(item)) item = this.getTask(id);
      this.$data.tasksStore.updateItem(id, item);
      if (this.isTaskExists(id))
        this.refreshTask(id);
    },
    addTask(item, parent, index) {
      if (!this.utils.defined(item.id))
        item.id = this.utils.uid();

      if (!this.utils.defined(parent)) parent = this.getParent(item) || 0;
      if (!this.isTaskExists(parent)) parent = this.config.root_id;
      this.setParent(item, parent);

      return this.$data.tasksStore.addItem(item, index, parent);
    },
    deleteTask(id) {
      return this.$data.tasksStore.removeItem(id);
    },
    getTaskCount() {
      return this.$data.tasksStore.count();
    },
    getVisibleTaskCount() {
      return this.$data.tasksStore.countVisible();
    },
    getTaskIndex(id) {
      return this.$data.tasksStore.getBranchIndex(id);
    },
    getGlobalTaskIndex(id) {
      this.assert(id, "Invalid argument");
      return this.$data.tasksStore.getIndexById(id);
    },
    eachTask(code, parent, master?) {
      return this.$data.tasksStore.eachItem(this.utils.bind(code, master || this), parent);
    },
    eachParent(callback, startTask, master) {
      return this.$data.tasksStore.eachParent(this.utils.bind(callback, master || this), startTask);
    },
    changeTaskId(oldid, newid) {
      this.$data.tasksStore.changeId(oldid, newid);
      var task = this.$data.tasksStore.getItem(newid);

      var links = [];

      if (task.$source) {
        links = links.concat(task.$source);
      }
      if (task.$target) {
        links = links.concat(task.$target);
      }

      for (var i = 0; i < links.length; i++) {
        var link = this.getLink(links[i]);
        if (link.source == oldid) {
          link.source = newid;
        }
        if (link.target == oldid) {
          link.target = newid;
        }
      }
    },
    calculateTaskLevel(item) {
      return this.$data.tasksStore.calculateItemLevel(item);
    },
    getNext(id) {
      return this.$data.tasksStore.getNext(id);
    },
    getPrev(id) {
      return this.$data.tasksStore.getPrev(id);
    },
    getParent(id) {
      return this.$data.tasksStore.getParent(id);
    },
    setParent(task, new_pid, silent) {
      return this.$data.tasksStore.setParent(task, new_pid, silent);
    },
    getSiblings(id) {
      return this.$data.tasksStore.getSiblings(id).slice();
    },
    getNextSibling(id) {
      return this.$data.tasksStore.getNextSibling(id);
    },
    getPrevSibling(id) {
      return this.$data.tasksStore.getPrevSibling(id);
    },
    getTaskByIndex(index) {
      var id = this.$data.tasksStore.getIdByIndex(index);
      if (this.isTaskExists(id)) {
        return this.getTask(id);
      } else {
        return null;
      }
    },
    getChildren(id) {
      if (!this.hasChild(id)) {
        return [];
      } else {
        return this.$data.tasksStore.getChildren(id).slice();
      }
    },
    hasChild(id) {
      return this.$data.tasksStore.hasChild(id);
    },
    open(id) {
      this.$data.tasksStore.open(id);
    },
    close(id) {
      this.$data.tasksStore.close(id);
    },
    moveTask(sid, tindex, parent) {
      return this.$data.tasksStore.move.apply(this.$data.tasksStore, arguments);
    },
    sort(field, desc, parent, silent) {
      var render = !silent;//4th argument to cancel redraw after sorting

      this.$data.tasksStore.sort(field, desc, parent);
      this.callEvent("onAfterSort", [field, desc, parent]);

      if (render) {
        this.render();
      }
    }
    // };
  };

  // return createTasksDatastoreFacade;
  /***/
}

export class WorktimeCalendars {

  // TODO: rework public api for date methods
  utils: UtilsService;

  createWorktimeFacade = function (calendarManager, timeCalculator) {
    return {
      getWorkHours(date) {
        return timeCalculator.getWorkHours(date);
      },

      setWorkTime(config) {
        return timeCalculator.setWorkTime(config);
      },

      unsetWorkTime(config) {
        timeCalculator.unsetWorkTime(config);
      },

      isWorkTime(date, unit, task) {
        return timeCalculator.isWorkTime(date, unit, task);
      },

      getClosestWorkTime(config) {
        return timeCalculator.getClosestWorkTime(config);
      },

      calculateDuration(start_date, end_date, task) {
        return timeCalculator.calculateDuration(start_date, end_date, task);
      },
      _hasDuration(start_date, end_date, task) {
        return timeCalculator.hasDuration(start_date, end_date, task);
      },

      calculateEndDate(start, duration, unit, task) {
        return timeCalculator.calculateEndDate(start, duration, unit, task);
      },

      createCalendar: this.utils.bind(calendarManager.createCalendar, calendarManager),
      addCalendar: this.utils.bind(calendarManager.addCalendar, calendarManager),
      getCalendar: this.utils.bind(calendarManager.getCalendar, calendarManager),
      getCalendars: this.utils.bind(calendarManager.getCalendars, calendarManager),
      getTaskCalendar: this.utils.bind(calendarManager.getTaskCalendar, calendarManager),
      deleteCalendar: this.utils.bind(calendarManager.deleteCalendar, calendarManager)
    };
  };


  // return { create: createWorktimeFacade };


  /***/
}

export class IsWorkTimeArgument {
  date: any;
  unit: any;
  task: any;
  id: any;
  calendar: any;
  constructor(date, unit, task, id, calendar) {
    this.date = date;
    this.unit = unit;
    this.task = task;
    this.id = id;
    this.calendar = calendar;
  }
}

export class ClosestWorkTimeArgument {
  date: any;
  unit: any;
  task: any;
  id: any;
  calendar: any;
  dir: any;
  constructor(date, dir?, unit?, task?, id?, calendar?) {
    this.date = date;
    this.dir = dir;
    this.unit = unit;
    this.task = task;
    this.id = id;
    this.calendar = calendar;
  }
}

export class CalculateEndDateArgument {
  start_date: any;
  duration: any;
  unit: any;
  step: any;
  task: any;
  id: any;
  calendar: any;
  constructor(start_date, duration, unit, step, task, id, calendar) {
    this.start_date = start_date;
    this.duration = duration;
    this.unit = unit;
    this.step = step;
    this.task = task;
    this.id = id;
    this.calendar = calendar;
  }
}

export class GetDurationArgument {
  start_date: any;
  end_date: any;
  task: any;
  calendar: any;
  unit: any;
  step: any;

  constructor(start, end, task, calendar) {
    this.start_date = start;
    this.end_date = end;
    this.task = task;
    this.calendar = calendar;
    this.unit = null;
    this.step = null;
  }
}

export class CalendarArgumentsHelper {

  ganttObject: GanttObjectService;

  constructor(private utilService: UtilsService) { }
  getWorkHoursArguments() {
    var config = arguments[0];
    if (this.utilService.isDate(config)) {
      config = {
        date: config
      };
    } else {
      config = this.utilService.mixin({}, config);
    }
    return config;
  }

  setWorkTimeArguments() {
    return arguments[0];
  }

  unsetWorkTimeArguments() {
    return arguments[0];
  }

  isWorkTimeArguments() {
    var config = arguments[0];
    if (config instanceof IsWorkTimeArgument) {
      return config;
    }

    var processedConfig;
    if (!config.date) {
      //IsWorkTimeArgument(date, unit, task, id, calendar)
      processedConfig = new IsWorkTimeArgument(arguments[0], arguments[1], arguments[2], null, arguments[3]);
    } else {
      processedConfig = new IsWorkTimeArgument(config.date, config.unit, config.task, null, config.calendar);
    }

    processedConfig.unit = processedConfig.unit || this.ganttObject.gantt.config.duration_unit;

    return processedConfig;
  }

  getClosestWorkTimeArguments(arg) {
    var config = arguments[0];
    if (config instanceof ClosestWorkTimeArgument)
      return config;

    var processedConfig;
    if (this.utilService.isDate(config)) {
      // processedConfig = ClosestWorkTimeArgument(config);
      processedConfig = new ClosestWorkTimeArgument(config);
    } else {
      processedConfig = new ClosestWorkTimeArgument(
        config.date,
        config.dir,
        config.unit,
        config.task,
        null,//config.id,
        config.calendar
      );
    }

    if (config.id) {
      processedConfig.task = config;
    }
    processedConfig.dir = config.dir || 'any';
    processedConfig.unit = config.unit || this.ganttObject.gantt.config.duration_unit;

    return processedConfig;
  }

  _getStartEndConfig(param) {
    var argumentType = GetDurationArgument;
    var config;
    if (param instanceof argumentType)
      return param;

    if (this.utilService.isDate(param)) {
      config = new argumentType(arguments[0], arguments[1], arguments[2], arguments[3]);
    } else {
      config = new argumentType(param.start_date, param.end_date, param.task, null);
      if (param.id) {
        config.task = param;
      }
    }

    config.unit = config.unit || this.ganttObject.gantt.config.duration_unit;
    config.step = config.step || this.ganttObject.gantt.config.duration_step;
    config.start_date = config.start_date || config.start || config.date;

    return config;
  }

  getDurationArguments(start, end, unit, step) {
    return this._getStartEndConfig.apply(this, arguments);
  }

  hasDurationArguments(start, end, unit, step) {
    return this._getStartEndConfig.apply(this, arguments);
  }

  calculateEndDateArguments(start, duration, unit, step) {
    var config = arguments[0];
    if (config instanceof CalculateEndDateArgument)
      return config;

    var processedConfig;
    //CalculateEndDateArgument(start_date, duration, unit, step, task, id, calendar)
    if (this.utilService.isDate(config)) {
      processedConfig = new CalculateEndDateArgument(
        arguments[0],
        arguments[1],
        arguments[2],
        undefined,
        arguments[3],
        undefined,
        arguments[4]
      );

    } else {
      processedConfig = new CalculateEndDateArgument(
        config.start_date,
        config.duration,
        config.unit,
        config.step,
        config.task,
        null,//config.id,
        config.calendar
      );
    }
    if (config.id) {
      processedConfig.task = config;
    }

    processedConfig.unit = processedConfig.unit || this.ganttObject.gantt.config.duration_unit;
    processedConfig.step = processedConfig.step || this.ganttObject.gantt.config.duration_step;

    return processedConfig;
  }

}

export class CalendarManager {
  _calendars: {}
  $gantt;
  utilsService: UtilsService

  constructor(gantt) {
    this.$gantt = gantt;
    this._calendars = {};
  }

  defaults: {
    global: {
      id: "global",
      worktime: {
        hours: [8, 17],
        days: [0, 1, 1, 1, 1, 1, 0]
      }
    },
    fulltime: {
      id: "fulltime",
      worktime: {
        hours: [0, 24],
        days: [1, 1, 1, 1, 1, 1, 1]
      }
    }
  }

  _getDayHoursForMultiple(calendars, date) {
    var units: any = [],
      tick = true,
      currPos = 0,
      is_work_hour = false,
      start = this.$gantt.date.day_start(new Date(date));
    for (var hour = 0; hour < 24; hour++) {
      is_work_hour = calendars.reduce(function (acc, calendar) {
        return acc && calendar._is_work_hour(start);
      }, true);
      if (is_work_hour) {
        if (tick) {
          units[currPos] = hour;
          units[currPos + 1] = (hour + 1);
          currPos += 2;
        } else {
          units[currPos - 1] += 1;
        }
        tick = false;
      } else if (!tick) {
        tick = true;
      }
      start = this.$gantt.date.add(start, 1, "hour");
    }
    if (!units.length)
      units = false;
    return units;
  }

  mergeCalendars() {
    var newCalendar = this.createCalendar(),
      day,
      units = [];
    var calendars = Array.prototype.slice.call(arguments, 0);
    newCalendar.worktime.hours = [0, 24];
    newCalendar.worktime.dates = {};
    var start = this.$gantt.date.day_start(new Date(259200000)); // 1970 day=0
    for (day = 0; day < 7; day++) {
      units = this._getDayHoursForMultiple(calendars, start);
      newCalendar.worktime.dates[day] = units;
      start = this.$gantt.date.add(start, 1, "day");
    }
    for (var i = 0; i < calendars.length; i++) {
      for (var value in calendars[i].worktime.dates) if (+value > 10000) {
        units = this._getDayHoursForMultiple(calendars, new Date(+value));
        newCalendar.worktime.dates[value] = units;
      }
    }
    return newCalendar;
  }

  _convertWorktimeSettings(settings) {
    var days = settings.days;
    if (days) {
      settings.dates = settings.dates || {};
      for (var i = 0; i < days.length; i++) {
        settings.dates[i] = days[i];
        if (!(days[i] instanceof Array)) {
          settings.dates[i] = !!days[i];
        }
      }
      delete settings.days;
    }
    return settings;
  }

  createCalendar(parentCalendar?) {
    var settings;

    if (!parentCalendar) {
      parentCalendar = {};
    }

    if (parentCalendar.worktime) {
      settings = this.utilsService.copy(parentCalendar.worktime);
    } else {
      settings = this.utilsService.copy(parentCalendar);
    }

    var defaults = this.utilsService.copy(this.defaults.fulltime.worktime);
    this.utilsService.mixin(settings, defaults);

    var id = this.utilsService.uid();
    var calendar = {
      id: id + "",
      worktime: this._convertWorktimeSettings(settings)
    };

    var apiCore = new CalendarWorkTimeStrategy(this.$gantt, new CalendarArgumentsHelper(this.$gantt));
    this.utilsService.mixin(apiCore, calendar);

    // validate/check if empty calendar
    if (!apiCore._tryChangeCalendarSettings(function () {
    })) {
      return null;
    } else {
      return apiCore;
    }
  }

  getCalendar(id?) {
    id = id || "global";
    this.createDefaultCalendars();
    return this._calendars[id];
  }

  getCalendars() {
    var res = [];
    for (var i in this._calendars) {
      res.push(this.getCalendar(i));
    }
    return res;
  }

  _getOwnCalendar(task) {
    var config = this.$gantt.config;
    if (task[config.calendar_property]) {
      return this.getCalendar(task[config.calendar_property]);
    }

    if (config.resource_calendars) {
      for (var field in config.resource_calendars) {
        var resource = config.resource_calendars[field];
        if (task[field]) {
          var calendarId = resource[task[field]];
          if (calendarId) {
            return this.getCalendar(calendarId);
          }
        }
      }
    }
    return null;
  }

  getTaskCalendar(task) {
    if (!task) {
      return this.getCalendar();
    }

    var calendar = this._getOwnCalendar(task);
    var gantt = this.$gantt;
    if (!calendar && gantt.config.inherit_calendar && gantt.isTaskExists(task.parent)) {
      var stop = false;
      gantt.eachParent(function (parent) {
        if (stop) return;
        if (gantt.isSummaryTask(parent)) {
          calendar = this._getOwnCalendar(parent);
          if (calendar) {
            stop = true;
          }
        }
      }, task.id, this);
    }

    return calendar || this.getCalendar();
  }

  addCalendar(calendar) { // puts new calendar to Global Storage - gantt.calendarManager._calendars {}
    if (!(calendar instanceof CalendarWorkTimeStrategy)) {
      var id = calendar.id;
      calendar = this.createCalendar(calendar);
      calendar.id = id;
    }
    var config = this.$gantt.config;

    calendar.id = calendar.id || this.utilsService.uid();
    this._calendars[calendar.id] = calendar;
    if (!config.worktimes)
      config.worktimes = {};
    config.worktimes[calendar.id] = calendar.worktime;
    return calendar.id;
  }

  deleteCalendar(calendar) {
    var config = this.$gantt.config;
    if (!calendar) return false;
    if (this._calendars[calendar]) {
      delete this._calendars[calendar];
      if (config.worktimes && config.worktimes[calendar])
        delete config.worktimes[calendar];
      return true;
    } else {
      return false;
    }
  }

  restoreConfigCalendars(configs) {
    for (var i in configs) {
      if (this._calendars[i])
        continue;

      var settings = configs[i];
      var calendar: any = this.createCalendar(settings);
      calendar.id = i;
      this.addCalendar(calendar);
    }
  }

  createDefaultCalendars() {
    var config = this.$gantt.config;
    this.restoreConfigCalendars(this.defaults);
    this.restoreConfigCalendars(config.worktimes);
  }

}

export class TimeCalculator {
  $gantt: any;
  argumentsHelper: any;
  calendarManager: any;
  $disabledCalendar: any;
  constructor(calendarManager) {

    this.$gantt = calendarManager.gantt;
    this.argumentsHelper = new CalendarArgumentsHelper(this.$gantt);
    this.calendarManager = calendarManager;
    this.$disabledCalendar = new CalendarDisabledTimeStrategy(this.$gantt, this.argumentsHelper);
  }
  _getCalendar(config) {
    var calendar;
    if (!this.$gantt.$services.config().work_time) {
      calendar = this.$disabledCalendar;
    } else {
      var manager = this.calendarManager;
      if (config.task) {
        calendar = manager.getTaskCalendar(config.task);
      } else if (config.id) {
        calendar = manager.getTaskCalendar(config);
      } else if (config.calendar) {
        calendar = config.calendar;
      }
      if (!calendar) {
        calendar = manager.getTaskCalendar();
      }
    }
    return calendar;
  }

  getWorkHours(config) {
    config = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);

    var calendar = this._getCalendar(config);

    return calendar.getWorkHours(config.date);
  }

  setWorkTime(config, calendar) {
    config = this.argumentsHelper.setWorkTimeArguments.apply(this.argumentsHelper, arguments);

    if (!calendar)
      calendar = this.calendarManager.getCalendar(); // Global
    return calendar.setWorkTime(config);
  }

  unsetWorkTime(config, calendar) {
    config = this.argumentsHelper.unsetWorkTimeArguments.apply(this.argumentsHelper, arguments);

    if (!calendar)
      calendar = this.calendarManager.getCalendar(); // Global
    return calendar.unsetWorkTime(config);
  }
  isWorkTime(date, unit, task, calendar) {
    var config = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);

    calendar = this._getCalendar(config);
    return calendar.isWorkTime(config);
  }
  getClosestWorkTime(config) {
    config = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);

    var calendar = this._getCalendar(config);

    return calendar.getClosestWorkTime(config);
  }

  calculateDuration() { // start_date_date, end_date, task
    var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);


    var calendar = this._getCalendar(config);
    return calendar.calculateDuration(config);
  }
  hasDuration() {
    var config = this.argumentsHelper.hasDurationArguments.apply(this.argumentsHelper, arguments);

    var calendar = this._getCalendar(config);

    return calendar.hasDuration(config);
  }
  calculateEndDate(config) { // start_date, duration, unit, task
    var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

    var calendar = this._getCalendar(config);
    return calendar.calculateEndDate(config);
  }
}

export class CalendarWorkTimeStrategy {
  argumentsHelper: any;
  $gantt: any;
  _workingUnitsCache: any;
  utilServices: UtilsService;
  worktime: any;

  constructor(gantt, argumentsHelper) {
    this.argumentsHelper = argumentsHelper;
    this.$gantt = gantt;
    this._workingUnitsCache = new CreateCache().createCacheObject();
  }

  units: [
    "year",
    "month",
    "week",
    "day",
    "hour",
    "minute"
  ]

  // cache previously calculated worktime
  _getUnitOrder(unit) {
    for (var i = 0, len = this.units.length; i < len; i++) {
      if (this.units[i] == unit)
        return i;
    }
  }

  _timestamp(settings) {

    var timestamp = null;
    if ((settings.day || settings.day === 0)) {
      timestamp = settings.day;
    } else if (settings.date) {
      // store worktime datestamp in utc so it could be recognized in different timezones (e.g. opened locally and sent to the export service in different timezone)
      timestamp = Date.UTC(settings.date.getFullYear(), settings.date.getMonth(), settings.date.getDate());
    }
    return timestamp;
  }

  _checkIfWorkingUnit(date, unit, order) {
    if (order === undefined) {
      order = this._getUnitOrder(unit);
    }

    // disable worktime check for custom time units
    if (order === undefined) {
      return true;
    }
    if (order) {
      //check if bigger time unit is a work time (hour < day < month...)
      //i.e. don't check particular hour if the whole day is marked as not working
      if (!this._isWorkTime(date, this.units[order - 1], order - 1))
        return false;
    }
    if (!this["_is_work_" + unit])
      return true;
    return this["_is_work_" + unit](date);
  }

  //checkings for particular time units
  //methods for month-year-week can be defined, otherwise always return 'true'
  _is_work_day(date) {
    var val = this._getWorkHours(date);

    if (val instanceof Array) {
      return val.length > 0;
    }
    return false;
  }

  _is_work_hour(date) {
    var hours = this._getWorkHours(date); // [7,12] or []
    var hour = date.getHours();
    for (var i = 0; i < hours.length; i += 2) {
      if (hours[i + 1] === undefined) {
        return hours[i] == hour;
      } else {
        if (hour >= hours[i] && hour < hours[i + 1])
          return true;
      }
    }
    return false;
  }

  _internDatesPull: {}

  _nextDate(start, unit, step) {
    var dateHelper = this.$gantt.date;
    return dateHelper.add(start, step, unit);

    /*var start_value = +start,
      key = unit + "_" + step;
    var interned = this._internDatesPull[key];
    if(!interned){
      interned = this._internDatesPull[key] = {};
    }
    var calculated;
    if(!interned[start_value]){
      interned[start_value] = calculated = dateHelper.add(start, step, unit);
      //interned[start_value] = dateHelper.add(start, step, unit);
    }
    return calculated || interned[start_value];*/
  }

  _getWorkUnitsBetweenGeneric(from, to, unit, step) {
    var dateHelper = this.$gantt.date;
    var start = new Date(from),
      end = new Date(to);
    step = step || 1;
    var units = 0;


    var next = null;
    var stepStart,
      stepEnd;

    // calculating decimal durations, i.e. 2016-09-20 00:05:00 - 2016-09-20 01:00:00 ~ 0.95 instead of 1
    // and also  2016-09-20 00:00:00 - 2016-09-20 00:05:00 ~ 0.05 instead of 1
    // durations must be rounded later
    var checkFirst = false;
    stepStart = dateHelper[unit + "_start"](new Date(start));
    if (stepStart.valueOf() != start.valueOf()) {
      checkFirst = true;
    }
    var checkLast = false;
    stepEnd = dateHelper[unit + "_start"](new Date(to));
    if (stepEnd.valueOf() != to.valueOf()) {
      checkLast = true;
    }

    var isLastStep = false;
    while (start.valueOf() < end.valueOf()) {
      next = this._nextDate(start, unit, step);
      isLastStep = (next.valueOf() > end.valueOf());

      if (this._isWorkTime(start, unit)) {
        if (checkFirst || (checkLast && isLastStep)) {
          stepStart = dateHelper[unit + "_start"](new Date(start));
          stepEnd = dateHelper.add(stepStart, step, unit);
        }

        if (checkFirst) {
          checkFirst = false;
          next = this._nextDate(stepStart, unit, step);
          units += ((stepEnd.valueOf() - start.valueOf()) / (stepEnd.valueOf() - stepStart.valueOf()));
        } else if (checkLast && isLastStep) {
          checkLast = false;
          units += ((end.valueOf() - start.valueOf()) / (stepEnd.valueOf() - stepStart.valueOf()));

        } else {
          units++;
        }
      }
      start = next;
    }
    return units;
  }

  _getMinutesPerDay(date) {
    // current api doesn't allow setting working minutes, so use hardcoded 60 minutes per hour
    return this._getHoursPerDay(date) * 60;
  }

  _getHoursPerDay(date) {
    var hours = this._getWorkHours(date);
    var res = 0;
    for (var i = 0; i < hours.length; i += 2) {
      res += ((hours[i + 1] - hours[i]) || 0);
    }
    return res;
  }

  _getWorkUnitsForRange(from, to, unit, step) {
    var total = 0;
    var start = new Date(from),
      end = new Date(to);

    var getUnitsPerDay;
    if (unit == "minute") {
      getUnitsPerDay = this.utilServices.bind(this._getMinutesPerDay, this);
    } else {
      getUnitsPerDay = this.utilServices.bind(this._getHoursPerDay, this);
    }

    while (start.valueOf() < end.valueOf()) {
      if (this._isWorkTime(start, "day")) {
        total += getUnitsPerDay(start);
      }
      start = this._nextDate(start, "day", 1);
    }

    return total / step;
  }

  // optimized method for calculating work units duration of large time spans
  // implemented for hours and minutes units, bigger time units don't benefit from the optimization so much
  _getWorkUnitsBetweenQuick(from, to, unit, step) {
    var start = new Date(from),
      end = new Date(to);
    step = step || 1;

    var firstDayStart = new Date(start);
    var firstDayEnd = this.$gantt.date.add(this.$gantt.date.day_start(new Date(start)), 1, "day");

    if (end.valueOf() <= firstDayEnd.valueOf()) {
      return this._getWorkUnitsBetweenGeneric(from, to, unit, step);
    } else {

      var lastDayStart = this.$gantt.date.day_start(new Date(end));
      var lastDayEnd = end;

      var startPart = this._getWorkUnitsBetweenGeneric(firstDayStart, firstDayEnd, unit, step);
      var endPart = this._getWorkUnitsBetweenGeneric(lastDayStart, lastDayEnd, unit, step);

      var rangePart = this._getWorkUnitsForRange(firstDayEnd, lastDayStart, unit, step);
      var total = startPart + rangePart + endPart;

      return total;
    }
  }

  _getCalendar() {
    return this.worktime;
  }

  _setCalendar(settings) {
    this.worktime = settings;
  }

  _tryChangeCalendarSettings(payload) {
    var backup = JSON.stringify(this._getCalendar());
    payload();
    if (this._isEmptyCalendar(this._getCalendar())) {
      this.$gantt.assert(false, "Invalid calendar settings, no worktime available");
      this._setCalendar(JSON.parse(backup));
      this._workingUnitsCache.clear();
      return false;
    }
    return true;

  }

  _isEmptyCalendar(settings: any) {
    var result: any = false,
      datesArray: any = [],
      isFullWeekSet = true;
    for (var i in settings.dates) {
      var date: any = settings.dates[i];
      result |= date;
      datesArray.push(i);
    }

    var checkFullArray = [];
    for (let i = 0; i < datesArray.length; i++) {
      if (datesArray[i] < 10) {
        checkFullArray.push(datesArray[i]);
      }
    }
    checkFullArray.sort();

    for (let i = 0; i < 7; i++) {
      if (checkFullArray[i] != i)
        isFullWeekSet = false;
    }
    if (isFullWeekSet)
      return !result;
    return !(result || !!settings.hours); // can still return false if separated dates are set to true
  }

  getWorkHours() {
    var config = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);
    return this._getWorkHours(config.date);
  }

  _getWorkHours(date) {
    var t = this._timestamp({ date: date });
    var hours = true;
    var calendar = this._getCalendar();
    if (calendar.dates[t] !== undefined) {
      hours = calendar.dates[t];//custom day
    } else if (calendar.dates[date.getDay()] !== undefined) {
      hours = calendar.dates[date.getDay()];//week day
    }
    if (hours === true) {
      return calendar.hours;
    } else if (hours) {
      return hours;
    }
    return [];
  }

  setWorkTime(settings) {
    return this._tryChangeCalendarSettings(this.utilServices.bind(function () {
      var hours = settings.hours !== undefined ? settings.hours : true;
      var timestamp = this._timestamp(settings);
      if (timestamp !== null) {
        this._getCalendar().dates[timestamp] = hours;
      } else {
        this._getCalendar().hours = hours;
      }
      this._workingUnitsCache.clear();
    }, this));
  }

  unsetWorkTime(settings) {
    return this._tryChangeCalendarSettings(this.utilServices.bind(function () {
      if (!settings) {
        this.reset_calendar();
      } else {

        var timestamp = this._timestamp(settings);

        if (timestamp !== null) {
          delete this._getCalendar().dates[timestamp];
        }
      }
      // Clear work units cache
      this._workingUnitsCache.clear();
    }, this));
  }

  _isWorkTime(date, unit, order?) {
    // Check if this item has in the cache

    // use string keys
    var dateKey = String(date.valueOf());
    var is_work_unit = this._workingUnitsCache.getItem(unit, dateKey);

    if (is_work_unit == -1) {
      // calculate if not cached
      is_work_unit = this._checkIfWorkingUnit(date, unit, order);
      this._workingUnitsCache.setItem(unit, dateKey, is_work_unit);
    }

    return is_work_unit;
  }

  isWorkTime() {
    var config = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);
    return this._isWorkTime(config.date, config.unit);
  }

  calculateDuration() {
    var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);

    if (!config.unit) {
      return false;
    }
    return this._calculateDuration(config.start_date, config.end_date, config.unit, config.step);
  }


  _calculateDuration(from, to, unit, step) {
    var res = 0;
    if (unit == "hour" || unit == "minute") {
      res = this._getWorkUnitsBetweenQuick(from, to, unit, step);
    } else {
      res = this._getWorkUnitsBetweenGeneric(from, to, unit, step);
    }

    // getWorkUnits.. returns decimal durations
    return Math.round(res);
  }

  hasDuration() {
    var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);

    var from = config.start_date,
      to = config.end_date,
      unit = config.unit,
      step = config.step;

    if (!unit) {
      return false;
    }
    var start = new Date(from),
      end = new Date(to);
    step = step || 1;

    while (start.valueOf() < end.valueOf()) {
      if (this._isWorkTime(start, unit))
        return true;
      start = this._nextDate(start, unit, step);
    }
    return false;
  }


  calculateEndDate() {
    var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

    var from = config.start_date,
      duration = config.duration,
      unit = config.unit,
      step = config.step;

    if (!unit)
      return false;

    var mult = (config.duration >= 0) ? 1 : -1;
    duration = Math.abs(duration * 1);
    return this._calculateEndDate(from, duration, unit, step * mult);
  }

  _calculateEndDate(from, duration, unit, step) {
    if (!unit)
      return false;

    if (step == 1 && unit == "minute") {
      return this._calculateMinuteEndDate(from, duration, step);
    } else if (step == 1 && unit == "hour") {
      return this._calculateHourEndDate(from, duration, step);
    } else {
      var interval = this._addInterval(from, duration, unit, step, null);
      return interval.end;
    }
  }

  _addInterval(start, duration, unit, step, stopAction) {
    var added = 0;
    var current = start;
    while (added < duration && !(stopAction && stopAction(current))) {
      var next = this._nextDate(current, unit, step);
      if (this._isWorkTime(step > 0 ? new Date(next.valueOf() - 1) : new Date(next.valueOf() + 1), unit)) {
        added++;
      }
      current = next;
    }
    return {
      end: current,
      satrt: start,
      added: added
    };
  }

  _calculateHourEndDate(from, duration, step) {
    var start = new Date(from),
      added = 0;
    step = step || 1;
    duration = Math.abs(duration * 1);

    var interval = this._addInterval(start, duration, "hour", step, function (date) {
      // iterate until hour end
      if (!(date.getHours() || date.getMinutes() || date.getSeconds() || date.getMilliseconds())) {
        return true;
      }
      return false;
    });

    added = interval.added;
    start = interval.end;

    var durationLeft = duration - added;

    if (durationLeft && durationLeft > 24) {
      var current = start;
      while (added < duration) {
        var next = this._nextDate(current, "day", step);
        // reset to day start in case DST switch happens in the process
        next.setHours(0);
        next.setMinutes(0);
        next.setSeconds(0);
        if (this._isWorkTime(step > 0 ? new Date(next.valueOf() - 1) : new Date(next.valueOf() + 1), "day")) {
          var hours = this._getHoursPerDay(current);
          if (added + hours >= duration) {
            break;
          } else {
            added += hours;
          }
        }
        current = next;
      }
      start = current;
    }

    if (added < duration) {
      var durationLeft = duration - added;
      interval = this._addInterval(start, durationLeft, "hour", step, null);
      start = interval.end;
    }

    return start;
  }

  _calculateMinuteEndDate(from, duration, step) {

    var start = new Date(from),
      added = 0;
    step = step || 1;
    duration = Math.abs(duration * 1);

    var interval = this._addInterval(start, duration, "minute", step, function (date) {
      // iterate until hour end
      if (!(date.getMinutes() || date.getSeconds() || date.getMilliseconds())) {
        return true;
      }
      return false;
    });

    added = interval.added;
    start = interval.end;

    if (added < duration) {
      var left = duration - added;
      var hours = Math.floor(left / 60);
      if (hours) {
        start = this._calculateEndDate(start, hours, "hour", step > 0 ? 1 : -1);
        added += hours * 60;
      }
    }

    if (added < duration) {
      var durationLeft = duration - added;
      interval = this._addInterval(start, durationLeft, "minute", step, null);
      start = interval.end;
    }

    return start;
  }

  getClosestWorkTime() {
    var settings = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);
    return this._getClosestWorkTime(settings.date, settings.unit, settings.dir);
  }

  _getClosestWorkTime(inputDate, unit, direction) {
    var result = new Date(inputDate);

    if (this._isWorkTime(result, unit)) {
      return result;
    }

    result = this.$gantt.date[unit + '_start'](result);

    if (direction == 'any' || !direction) {
      var closestFuture = this._getClosestWorkTimeFuture(result, unit);
      var closestPast = this._getClosestWorkTimePast(result, unit);
      if (Math.abs(closestFuture - inputDate) <= Math.abs(inputDate - closestPast)) {
        result = closestFuture;
      } else {
        result = closestPast;
      }
    } else if (direction == "past") {
      result = this._getClosestWorkTimePast(result, unit);
    } else {
      result = this._getClosestWorkTimeFuture(result, unit);
    }
    return result;
  }

  _getClosestWorkTimeFuture(date, unit) {
    return this._getClosestWorkTimeGeneric(date, unit, 1);
  }

  _getClosestWorkTimePast(date, unit) {
    var result = this._getClosestWorkTimeGeneric(date, unit, -1);
    // should return the end of the closest work interval
    return this.$gantt.date.add(result, 1, unit);
  }

  _getClosestWorkTimeGeneric(date, unit, increment) {
    var unitOrder = this._getUnitOrder(unit),
      biggerTimeUnit = this.units[unitOrder - 1];

    var result = date;

    // be extra sure we won't fall into infinite loop, 3k seems big enough
    var maximumLoop = 3000,
      count = 0;

    while (!this._isWorkTime(result, unit)) {
      if (biggerTimeUnit && !this._isWorkTime(result, biggerTimeUnit)) {
        // if we look for closest work hour and detect a week-end - first find the closest work day,
        // and continue iterations after that
        if (increment > 0) {
          result = this._getClosestWorkTimeFuture(result, biggerTimeUnit);
        } else {
          result = this._getClosestWorkTimePast(result, biggerTimeUnit);
        }

        if (this._isWorkTime(result, unit)) {
          break;
        }
      }

      count++;
      if (count > maximumLoop) {
        this.$gantt.assert(false, "Invalid working time check");
        return false;
      }

      var tzOffset = result.getTimezoneOffset();
      result = this.$gantt.date.add(result, increment, unit);

      result = this.$gantt._correct_dst_change(result, tzOffset, increment, unit);
      if (this.$gantt.date[unit + '_start']) {
        result = this.$gantt.date[unit + '_start'](result);
      }
    }
    return result;
  }

}

export class CalendarDisabledTimeStrategy {
  argumentsHelper: any;
  $gantt: any;
  constructor(gantt, argumentsHelper) {
    this.argumentsHelper = argumentsHelper;
    this.$gantt = gantt;
  }

  getWorkHours() {
    return [0, 24];
  }

  setWorkTime() {
    return true;
  }

  unsetWorkTime() {
    return true;
  }

  isWorkTime() {
    return true;
  }

  getClosestWorkTime(config) {
    var config = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);
    return config.date;
  }

  calculateDuration() {
    var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
    var from = config.start_date,
      to = config.end_date,
      unit = config.unit,
      step = config.step;

    return this._calculateDuration(from, to, unit, step);
  }

  _calculateDuration(start, end, unit, step) {
    var dateHelper = this.$gantt.date;
    var fixedUnits = {
      "week": 1000 * 60 * 60 * 24 * 7,
      "day": 1000 * 60 * 60 * 24,
      "hour": 1000 * 60 * 60,
      "minute": 1000 * 60
    };

    var res = 0;
    if (fixedUnits[unit]) {
      res = Math.round((end - start) / (step * fixedUnits[unit]));
    } else {
      var from: any = new Date(start),
        to: any = new Date(end);
      while (from.valueOf() < to.valueOf()) {
        res += 1;
        from = dateHelper.add(from, step, unit);
      }

      if (from.valueOf() != end.valueOf()) {
        res += (to - from) / (dateHelper.add(from, step, unit) - from);
      }
    }

    return Math.round(res);
  }

  hasDuration() {
    var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
    var from = config.start_date,
      to = config.end_date,
      unit = config.unit;

    if (!unit) {
      return false;
    }
    from = new Date(from);
    to = new Date(to);

    return (from.valueOf() < to.valueOf());
  }

  calculateEndDate() {
    var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

    var start = config.start_date,
      duration = config.duration,
      unit = config.unit,
      step = config.step;

    return this.$gantt.date.add(start, step * duration, unit);
  }

}

export class CreateCache {

  createCacheObject() {
    // worktime hash is on the hot path,
    // Map seems to work faster than plain array, use it whenever possible
    if (typeof Map !== "undefined") {
      return new WorkUnitsMapCache();
    }
    else {
      return new WorkUnitsObjectCache();
    }
  }
  // return { createCacheObject: createCacheObject };
}

export class WorkUnitsMapCache {
  _cache: Map<any, any>;
  constructor() {
    this.clear();
  }

  getItem(unit, timestamp) {
    if (this._cache.has(unit)) {
      var unitCache = this._cache.get(unit);
      if (unitCache.has(timestamp)) {
        return unitCache.get(timestamp);
      }
    }
    return -1;
  }
  setItem(unit, timestamp, value) {
    if (!unit || !timestamp) {
      return;
    }
    var cache = this._cache;
    var unitCache;
    if (!cache.has(unit)) {
      unitCache = new Map();
      cache.set(unit, unitCache);
    }
    else {
      unitCache = cache.get(unit);
    }
    unitCache.set(timestamp, value);
  }
  clear() {
    this._cache = new Map();
  }
}


export class WorkUnitsObjectCache {
  _cache: any;

  constructor() {
    this.clear();
  }

  getItem(unit, timestamp) {
    var cache = this._cache;
    if (cache && cache[unit]) {
      var units = cache[unit];
      if (units[timestamp] !== undefined) {
        return units[timestamp];
      }
    }
    return -1;
  }

  setItem(unit, timestamp, value) {
    if (!unit || !timestamp) {
      return;
    }
    var cache = this._cache;
    if (!cache) {
      return;
    }
    if (!cache[unit]) {
      cache[unit] = {};
    }
    cache[unit][timestamp] = value;
  }

  clear() {
    this._cache = {};
  }
}

export class Data {

  ganttObject: GanttObjectService;
  _lightbox_id: any;
  _tasks_dnd: any;
  config: any;
  utils: UtilsService;

  isUnscheduledTask(task) {
    this.ganttObject.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isUnscheduledTask. Task object was expected");
    return (!!task.unscheduled || !task.start_date);
  }

  _isAllowedUnscheduledTask(task) {
    return !!(task.unscheduled && this.ganttObject.gantt.config.show_unscheduled);
  };

  isTaskVisible(id) {
    if (!this.ganttObject.isTaskExists(id))
      return false;

    var task = this.ganttObject.getTask(id);

    var taskStart = task.start_date ? task.start_date.valueOf() : null;
    var taskEnd = task.end_date ? task.end_date.valueOf() : null;

    if (!(this._isAllowedUnscheduledTask(task) || (taskStart && taskEnd && taskStart <= this.ganttObject._max_date.valueOf() && taskEnd >= this.ganttObject._min_date.valueOf()))) {
      return false;
    }

    return !!(new DatastoreTasks().createTasksDatastoreFacade.getGlobalTaskIndex(id) >= 0);
  };

  _getProjectEnd() {
    if (this.ganttObject.gantt.config.project_end) {
      return this.ganttObject.gantt.config.project_end;
    } else {
      var tasks = new DatastoreTasks().createTasksDatastoreFacade.getTaskByTime();
      tasks = tasks.sort(function (a, b) {
        return +a.end_date > +b.end_date ? 1 : -1;
      });
      return tasks.length ? tasks[tasks.length - 1].end_date : null;
    }
  };
  _getProjectStart() {
    if (this.ganttObject.gantt.config.project_start) {
      return this.ganttObject.gantt.config.project_start;
    }

    // use timeline start if project start is not specified
    if (this.ganttObject.gantt.config.start_date) {
      return this.ganttObject.gantt.config.start_date;
    }
    if (this.ganttObject.getState().min_date) {
      return this.ganttObject.getState().min_date;
    }

    // earliest task start if neither project start nor timeline are specified
    var tasks = new DatastoreTasks().createTasksDatastoreFacade.getTaskByTime();
    tasks = tasks.sort(function (a, b) {
      return +a.start_date > +b.start_date ? 1 : -1;
    });
    return tasks.length ? tasks[0].start_date : null;
  };

  _defaultTaskDate(item, parent_id) {
    var parent = (parent_id && parent_id != this.ganttObject.gantt.config.root_id) ? this.ganttObject.gantt.getTask(parent_id) : false,
      startDate = null;
    if (parent) {
      if (this.ganttObject.gantt.config.schedule_from_end) {
        startDate = new TimeCalculator(this.ganttObject).calculateEndDate({
          start_date: parent.end_date,
          duration: - this.ganttObject.gantt.config.duration_step,
          task: item
        });
      } else {
        startDate = parent.start_date;
      }

    } else if (this.ganttObject.gantt.config.schedule_from_end) {
      startDate = new TimeCalculator(this.ganttObject).calculateEndDate({
        start_date: new Data()._getProjectEnd(),
        duration: - this.ganttObject.gantt.config.duration_step,
        task: item
      });
    } else {
      var first = new DatastoreTasks().createTasksDatastoreFacade.getTaskByIndex(0);
      startDate = first ? (first.start_date ? first.start_date : (first.end_date ? new TimeCalculator(this.ganttObject).calculateEndDate({
        start_date: first.end_date,
        duration: -this.ganttObject.gantt.config.duration_step,
        task: item
      }) : null)) : this.ganttObject.gantt.config.start_date || this.ganttObject.getState().min_date;
    }
    this.ganttObject.gantt.assert(startDate, "Invalid dates");
    return new Date(startDate);
  };

  _set_default_task_timing(task) {
    task.start_date = task.start_date || this._defaultTaskDate(task, this.ganttObject.getParent(task));
    task.duration = task.duration || this.ganttObject.gantt.config.duration_step;
    task.end_date = task.end_date || new TimeCalculator(this.ganttObject).calculateEndDate(task);
  };

  createTask(item, parent, index) {
    item = item || {};
    if (!this.utils.defined(item.id))
      item.id = this.utils.uid();

    if (!item.start_date) {
      item.start_date = this._defaultTaskDate(item, parent);
    }
    if (item.text === undefined) {
      item.text = this.ganttObject.gantt.locale.labels.new_task;
    }
    if (item.duration === undefined) {
      item.duration = 1;
    }

    if (this.ganttObject.isTaskExists(parent)) {
      this.ganttObject.setParent(item, parent, true);
      var parentObj = this.ganttObject.getTask(parent);
      parentObj.$open = true;
    }

    if (!this.ganttObject.callEvent("onTaskCreated", [item])) {
      return null;
    }
    if (this.ganttObject.gantt.config.details_on_create) {
      item.$new = true;
      // this.ganttObject.silent( function() {
      // 	this.ganttObject.gantt.$data.tasksStore.addItem(item, index);
      // });
      this.ganttObject.selectTask(item.id);
      this.ganttObject.refreshData();
      this.ganttObject.showLightbox(item.id);
    } else {
      if (this.ganttObject.addTask(item, parent, index)) {
        new Layout().createLayoutFacade.showTask(item.id);
        this.ganttObject.selectTask(item.id);
      }
    }
    return item.id;
  };

  _update_flags(oldid, newid) {
    //  TODO: need a proper way to update all possible flags
    var store = this.ganttObject.gantt.$data.tasksStore;
    if (oldid === undefined) {
      this._lightbox_id = null;

      store.silent(function () {
        store.unselect();
      });

      if (this._tasks_dnd && this._tasks_dnd.drag) {
        this._tasks_dnd.drag.id = null;
      }
    } else {
      if (this._lightbox_id == oldid)
        this._lightbox_id = newid;

      // TODO: probably can be removed
      if (store.getSelectedId() == oldid) {
        store.silent(function () {
          store.unselect(oldid);
          store.select(newid);
        });
      }
      if (this._tasks_dnd && this._tasks_dnd.drag && this._tasks_dnd.drag.id == oldid) {
        this._tasks_dnd.drag.id = newid;
      }
    }
  };

  _get_task_timing_mode(task, force?) {
    var task_type = this.ganttObject.getTaskType(task.type);

    var state = {
      type: task_type,
      $no_start: false,
      $no_end: false
    };

    if (!force && task_type == task.$rendered_type) {
      state.$no_start = task.$no_start;
      state.$no_end = task.$no_end;
      return state;
    }

    if (task_type == this.ganttObject.gantt.config.types.project) {
      //project duration is always defined by children duration
      state.$no_end = state.$no_start = true;
    } else if (task_type != this.ganttObject.gantt.config.types.milestone) {
      //tasks can have fixed duration, children duration(as projects), or one date fixed, and other defined by nested items
      state.$no_end = !(task.end_date || task.duration);
      state.$no_start = !task.start_date;

      if (this._isAllowedUnscheduledTask(task)) {
        state.$no_end = state.$no_start = false;
      }
    }

    return state;
  };

  _init_task_timing(task) {
    var task_mode = new Data()._get_task_timing_mode(task, true);

    var dirty = task.$rendered_type != task_mode.type;

    var task_type = task_mode.type;

    if (dirty) {
      task.$no_start = task_mode.$no_start;
      task.$no_end = task_mode.$no_end;
      task.$rendered_type = task_mode.type;
    }

    if (dirty && task_type != this.ganttObject.gantt.config.types.milestone) {
      if (task_type == this.ganttObject.gantt.config.types.project) {
        //project duration is always defined by children duration
        this._set_default_task_timing(task);
      }
    }

    if (task_type == this.ganttObject.gantt.config.types.milestone) {
      task.end_date = task.start_date;
    }
    if (task.start_date && task.end_date) {
      task.duration = new TimeCalculator(this.ganttObject).calculateDuration(); // calculateDuration(task);
    }

    if (!task.end_date) {
      task.end_date = task.start_date;
    }

    task.duration = task.duration || 0;
  };

  isSummaryTask(task) {
    this.ganttObject.assert(task && task instanceof Object, "Invalid argument <b>task</b>=" + task + " of gantt.isSummaryTask. Task object was expected");

    var mode = new Data()._get_task_timing_mode(task);

    return !!(mode.$no_end || mode.$no_start);
  };

  // downward calculation of project duration
  resetProjectDates(task) {
    var taskMode = this._get_task_timing_mode(task);
    if (taskMode.$no_end || taskMode.$no_start) {
      var dates = this.getSubtaskDates(task.id);
      this._assign_project_dates(task, dates.start_date, dates.end_date);
    }
  };

  getSubtaskDuration(task_id) {
    var res = 0,
      root = task_id !== undefined ? task_id : this.ganttObject.gantt.config.root_id;

    new DatastoreTasks().createTasksDatastoreFacade.eachTask((child) => {
      if (this.ganttObject.getTaskType(child.type) == this.ganttObject.gantt.config.types.project || this.isUnscheduledTask(child))
        return;

      res += child.duration;
    }, root);

    return res;
  };

  getSubtaskDates(task_id) {
    var min = null,
      max = null,
      root = task_id !== undefined ? task_id : this.ganttObject.gantt.config.root_id;

    new DatastoreTasks().createTasksDatastoreFacade.eachTask((child) => {
      if (this.ganttObject.getTaskType(child.type) == this.ganttObject.gantt.config.types.project || this.isUnscheduledTask(child))
        return;

      if ((child.start_date && !child.$no_start) && (!min || min > child.start_date.valueOf()))
        min = child.start_date.valueOf();
      if ((child.end_date && !child.$no_end) && (!max || max < child.end_date.valueOf()))
        max = child.end_date.valueOf();
    }, root);

    return {
      start_date: min ? new Date(min) : null,
      end_date: max ? new Date(max) : null
    };
  };

  _assign_project_dates(task, from, to) {
    var taskTiming = this._get_task_timing_mode(task);
    if (taskTiming.$no_start) {
      if (from && from != Infinity) {
        task.start_date = new Date(from);
      } else {
        task.start_date = this._defaultTaskDate(task, this.ganttObject.getParent(task));
      }
    }

    if (taskTiming.$no_end) {
      if (to && to != -Infinity) {
        task.end_date = new Date(to);
      } else {
        task.end_date = new TimeCalculator(this.ganttObject).calculateEndDate({
          start_date: task.start_date,
          duration: this.config.duration_step,
          task: task
        });
      }
    }
    if (taskTiming.$no_start || taskTiming.$no_end) {
      this._init_task_timing(task);
    }
  };

  // upward calculation of project duration
  _update_parents(taskId, silent) {
    if (!taskId) return;

    var task = this.ganttObject.getTask(taskId);
    var pid = this.ganttObject.getParent(task);

    var taskTiming = this._get_task_timing_mode(task);

    var has_changed = true;

    if (taskTiming.$no_start || taskTiming.$no_end) {
      var oldStart = task.start_date.valueOf(),
        oldEnd = task.end_date.valueOf();

      new Data().resetProjectDates(task);

      // not refresh parent projects if dates hasn't changed
      if (oldStart == task.start_date.valueOf() && oldEnd == task.end_date.valueOf()) {
        has_changed = false;
      }

      if (has_changed && !silent) {
        this.ganttObject.refreshTask(task.id, true);
      }
    }


    if (has_changed && pid && this.ganttObject.isTaskExists(pid)) {
      this._update_parents(pid, silent);
    }
  };

  roundDate(config) {
    var scale = this.ganttObject.getScale();

    if (this.utils.isDate(config)) {
      config = {
        date: config,
        unit: scale ? scale.unit : this.ganttObject.gantt.config.duration_unit,
        step: scale ? scale.step : this.ganttObject.gantt.config.duration_step
      };
    }
    var date = config.date,
      steps = config.step,
      unit = config.unit;

    if (!scale) {
      return date;
    }

    var upper, lower, colIndex;
    if (unit == scale.unit && steps == scale.step &&
      +date >= +scale.min_date && +date <= +scale.max_date) {
      //find date in time scale config
      colIndex = Math.floor(this.ganttObject.columnIndexByDate(date));

      if (!scale.trace_x[colIndex]) {
        colIndex -= 1;// end of time scale
        if (scale.rtl) {
          colIndex = 0;
        }
      }
      lower = new Date(scale.trace_x[colIndex]);
      upper = this.ganttObject.gantt.date.add(lower, steps, unit);
    } else {
      colIndex = Math.floor(this.ganttObject.columnIndexByDate(date));

      upper = this.ganttObject.gantt.date[unit + "_start"](new Date(scale.min_date));
      if (scale.trace_x[colIndex]) {
        upper = this.ganttObject.gantt.date[unit + "_start"](scale.trace_x[colIndex]);// end of time scale
      }

      while (+upper < +date) {
        upper = this.ganttObject.gantt.date[unit + "_start"](this.ganttObject.gantt.date.add(upper, steps, unit));

        var tzOffset = upper.getTimezoneOffset();

        upper = this.ganttObject._correct_dst_change(upper, tzOffset, upper, unit);
        if (this.ganttObject.gantt.date[unit + '_start'])
          upper = this.ganttObject.gantt.date[unit + '_start'](upper);
      }

      lower = this.ganttObject.gantt.date.add(upper, -1 * steps, unit);

    }
    if (config.dir && config.dir == 'future')
      return upper;
    if (config.dir && config.dir == 'past')
      return lower;

    if (Math.abs(date - lower) < Math.abs(upper - date)) {
      return lower;
    } else {
      return upper;
    }

  };

  correctTaskWorkTime(task) {
    if (this.ganttObject.gantt.config.work_time && this.ganttObject.gantt.config.correct_work_time) {
      if (!new WorktimeCalendars().createWorktimeFacade(task,new TimeCalculator(this.ganttObject)).isWorkTime(task.start_date, undefined, task)) {
        task.start_date = new WorktimeCalendars().createWorktimeFacade(task,new TimeCalculator(this.ganttObject)).getClosestWorkTime({ date: task.start_date, dir: 'future', task: task });
        task.end_date = new TimeCalculator(this.ganttObject).calculateEndDate(task);
      } else if (!new WorktimeCalendars().createWorktimeFacade(task,new TimeCalculator(this.ganttObject)).isWorkTime(new Date(+task.end_date - 1), undefined, task)) {
        task.end_date = new TimeCalculator(this.ganttObject).calculateEndDate(task);
      }
    }
  };

  // attachEvent("onBeforeTaskUpdate",((id, task) => {
  // 	this._init_task_timing(task);
  // 	return true;
  // });

  // attachEvent("onBeforeTaskAdd", ((id, task) => {
  // 	this._init_task_timing(task);
  // 	return true;
  // });

}

export class Layout {

  DEFAULT_VALUE = "DEFAULT_VALUE";

  createLayoutFacade = {

    getTimeline(gantt) {
      return gantt.$ui.getView("timeline");
    },

    getGrid(gantt) {
      return gantt.$ui.getView("grid");
    },

    getVerticalScrollbar(gantt) {
      return gantt.$ui.getView("scrollVer");
    },

    getHorizontalScrollbar(gantt) {
      return gantt.$ui.getView("scrollHor");
    },

    tryCall(getView, method, args, fallback) {
      var view = getView(this);
      if (!(view && view.isVisible())) {
        if (fallback) {
          return fallback();
        } else {
          return this.DEFAULT_VALUE;
        }
      } else {
        return view[method].apply(view, args);
      }
    },

    getColumnIndex(name) {
      var res = this.tryCall.call(this, this.getGrid, "getColumnIndex", [name]);
      if (res === this.DEFAULT_VALUE) {
        return 0;
      } else {
        return res;
      }
    },

    dateFromPos(x) {
      var res = this.tryCall.call(this, this.getTimeline, "dateFromPos", Array.prototype.slice.call(arguments));
      if (res === this.DEFAULT_VALUE) {
        return this.getState().min_date;
      } else {
        return res;
      }
    },

    posFromDate(date) {
      var res = this.tryCall.call(this, this.getTimeline, "posFromDate", [date]);
      if (res === this.DEFAULT_VALUE) {
        return 0;
      } else {
        return res;
      }
    },

    getRowTop(index) {
      var self = this;
      var res = this.tryCall.call(self, this.getTimeline, "getRowTop", [index],
        function () { return this.tryCall.call(self, this.getGrid, "getRowTop", [index]); }
      );

      if (res === this.DEFAULT_VALUE) {
        return 0;
      } else {
        return res;
      }
    },

    getTaskTop(id) {
      var self = this;
      var res = this.tryCall.call(self, this.getTimeline, "getItemTop", [id],
        function () { return this.tryCall.call(self, this.getGrid, "getItemTop", [id]); }
      );

      if (res === this.DEFAULT_VALUE) {
        return 0;
      } else {
        return res;
      }
    },


    getTaskPosition(task, start_date, end_date) {
      var res = this.tryCall.call(this, this.getTimeline, "getItemPosition", [task, start_date, end_date]);

      if (res === this.DEFAULT_VALUE) {
        var top = this.getTaskTop(task.id);
        var height = this.getTaskHeight();

        return {
          left: 0,
          top: top,
          height: height,
          width: 0
        };
      } else {
        return res;
      }
    },

    getTaskHeight() {
      var self = this;
      var res = this.tryCall.call(self, this.getTimeline, "getItemHeight", [],
        function () { return this.tryCall.call(self, this.getGrid, "getItemHeight", []); }
      );

      if (res === this.DEFAULT_VALUE) {
        return 0;
      } else {
        return res;
      }
    },


    columnIndexByDate(date) {
      var res = this.tryCall.call(this, this.getTimeline, "columnIndexByDate", [date]);
      if (res === this.DEFAULT_VALUE) {
        return 0;
      } else {
        return res;
      }
    },

    roundTaskDates() {
      this.tryCall.call(this, this.getTimeline, "roundTaskDates", []);
    },

    getScale() {
      var res = this.tryCall.call(this, this.getTimeline, "getScale", []);
      if (res === this.DEFAULT_VALUE) {
        return null;
      } else {
        return res;
      }
    },

    getTaskNode(id) {
      var timeline = this.getTimeline(this);
      if (!timeline || !timeline.isVisible()) {
        return null;
      } else {
        return timeline._taskRenderer.rendered[id];
      }
    },


    getLinkNode(id) {
      var timeline = this.getTimeline(this);
      if (!timeline.isVisible()) {
        return null;
      } else {
        return timeline._linkRenderer.rendered[id];
      }
    },

    scrollTo(left, top) {
      var vertical = this.getVerticalScrollbar(this);
      var horizontal = this.getHorizontalScrollbar(this);

      var oldH = { position: 0 },
        oldV = { position: 0 };

      if (vertical) {
        oldV = vertical.getScrollState();
      }
      if (horizontal) {
        oldH = horizontal.getScrollState();
      }

      if (horizontal && left * 1 == left) {
        horizontal.scroll(left);
      }
      if (vertical && top * 1 == top) {
        vertical.scroll(top);
      }

      var newV = { position: 0 },
        newH = { position: 0 };
      if (vertical) {
        newV = vertical.getScrollState();
      }
      if (horizontal) {
        newH = horizontal.getScrollState();
      }

      this.callEvent("onGanttScroll", [oldH.position, oldV.position, newH.position, newV.position]);
    },

    showDate(date) {
      var date_x = this.posFromDate(date);
      var scroll_to = Math.max(date_x - this.config.task_scroll_offset, 0);
      this.scrollTo(scroll_to);
    },
    showTask(id) {
      var pos = this.getTaskPosition(this.getTask(id));

      var left = Math.max(pos.left - this.config.task_scroll_offset, 0);

      var dataHeight = this._scroll_state().y;
      var top;
      if (!dataHeight) {
        top = pos.top;
      } else {
        top = pos.top - (dataHeight - this.config.row_height) / 2;
      }

      this.scrollTo(left, top);
    },
    _scroll_state() {
      var result = {
        x: false,
        y: false,
        x_pos: 0,
        y_pos: 0,
        scroll_size: this.config.scroll_size + 1,//1px for inner content
        x_inner: 0,
        y_inner: 0
      };

      var scrollVer = this.getVerticalScrollbar(this),
        scrollHor = this.getHorizontalScrollbar(this);
      if (scrollHor) {
        var horState = scrollHor.getScrollState();
        if (horState.visible) {
          result.x = horState.size;
          result.x_inner = horState.scrollSize;
        }
        result.x_pos = horState.position || 0;
      }

      if (scrollVer) {
        var verState = scrollVer.getScrollState();
        if (verState.visible) {
          result.y = verState.size;

          result.y_inner = verState.scrollSize;
        }
        result.y_pos = verState.position || 0;
      }

      return result;
    },
    getScrollState() {
      var state = this._scroll_state();
      return { x: state.x_pos, y: state.y_pos, inner_width: state.x, inner_height: state.y, width: state.x_inner, height: state.y_inner };
    }

  };

}

export class Core {
  constants;
  config: any;
  env: any;
  min_date;
  max_date;
  boxAttribute = "data-dhxbox";
  _dhx_msg_cfg = null;
  utilsService: UtilsService;
  common: CommonService;
  skinService: SkinsService;
  uiService: UiService;
  ganttObject: GanttObjectService;


  constructor() {}


  messagebox: any = {
    seed: (new Date()).valueOf(),
    uid: this.utils.uid,
    expire: 4000,
    keyboard: true,
    position: "top",
    pull: {},
    timers: {}
  }

  modalityObj: any = {

  }

  cachedFunctions(gantt) {

    gantt._cached_functions = {
      cache: {},
      mode: false,
      critical_path_mode: false,
      wrap_methods: function (methods, object) {
        if (object._prefetch_originals) {
          for (var i in object._prefetch_originals) {
            object[i] = object._prefetch_originals[i];
          }
        }
        object._prefetch_originals = {};
        for (let i = 0; i < methods.length; i++)
          this.prefetch(methods[i], object);

      },
      prefetch: function (methodname, host) {
        var original = host[methodname];
        if (original) {
          var optimizer = this;

          host._prefetch_originals[methodname] = original;
          host[methodname] = function get_prefetched_value() {

            var argumentsArray = new Array(arguments.length);
            for (var i = 0, l = arguments.length; i < l; i++) {
              argumentsArray[i] = arguments[i];
            }

            if (optimizer.active) {
              var args = optimizer.get_arguments_hash(Array.prototype.slice.call(argumentsArray));
              if (!optimizer.cache[methodname]) {
                optimizer.cache[methodname] = {};
              }

              var cached_values = optimizer.cache[methodname];

              if (optimizer.has_cached_value(cached_values, args)) {
                return optimizer.get_cached_value(cached_values, args);
              } else {
                var value = original.apply(this, argumentsArray);
                optimizer.cache_value(cached_values, args, value);
                return value;
              }
            }

            return original.apply(this, argumentsArray);
          };
        }
        return original;
      },
      cache_value: function (cache, arguments_hash, value) {
        if (this.is_date(value))
          value = new Date(value);
        cache[arguments_hash] = value;
      },
      has_cached_value: function (cache, arguments_hash) {
        return cache.hasOwnProperty(arguments_hash);
      },
      get_cached_value: function (cache, arguments_hash) {
        var data = cache[arguments_hash];

        //for cached dates - return copy
        if (this.is_date(data)) {
          data = new Date(data);
        }
        return data;
      },
      is_date: function (value) {
        return (value && value.getUTCDate);
      },
      get_arguments_hash: function (args) {
        var values = [];
        for (var i = 0; i < args.length; i++) {
          values.push(this.stringify_argument(args[i]));
        }
        return "(" + values.join(";") + ")";
      },
      stringify_argument: function (value) {
        //expecting task or link, or any other data entries, dates and primitive values
        var ret = "";
        if (value.id) {
          ret = value.id;
        } else if (this.is_date(value)) {
          ret = value.valueOf();
        } else {
          ret = value;
        }
        return ret + "";
      },
      activate: function () {
        this.clear();
        this.active = true;
      },
      deactivate: function () {
        this.clear();
        this.active = false;
      },
      clear: function () {
        this.cache = {};
      },

      setup: function (gantt) {
        var override_gantt = [];

        var gantt_methods = [
          '_isProjectEnd',
          '_getProjectEnd',
          '_getSlack'
        ];



        if (this.mode == 'auto') {
          if (this.config.highlight_critical_path) {
            override_gantt = gantt_methods;
          }
        } else if (this.mode === true) {
          override_gantt = gantt_methods;
        }

        this.wrap_methods(override_gantt, gantt);

      },
      update_if_changed: function (gantt) {
        var changed = (this.critical_path_mode != this.config.highlight_critical_path ||
          this.mode !== this.config.optimize_render);
        if (changed) {
          this.critical_path_mode = this.config.highlight_critical_path;
          this.mode = this.config.optimize_render;
          this.setup(gantt);
        }
      }
    };

    function activate() {
      gantt._cached_functions.update_if_changed(gantt);
      if (!gantt._cached_functions.active) {
        gantt._cached_functions.activate();
      }
      return true;
    }
    gantt.attachEvent("onBeforeGanttRender", activate);
    gantt.attachEvent("onBeforeDataRender", activate);
    gantt.attachEvent("onBeforeSmartRender", function () {
      activate();
    });
    gantt.attachEvent("onBeforeParse", activate);
    gantt.attachEvent("onDataRender", function () {
      gantt._cached_functions.deactivate();
    });
    var deactivTimeout = null;
    gantt.attachEvent("onSmartRender", function () {
      if (deactivTimeout)
        clearTimeout(deactivTimeout);
      deactivTimeout = setTimeout(function () {
        gantt._cached_functions.deactivate();
      }, 1000);
    });

    gantt.attachEvent("onBeforeGanttReady", function () {
      gantt._cached_functions.update_if_changed(gantt);
      return true;
    });

  }


  data(gantt) {

    var helpers = this.utils;

    gantt.attachEvent("onBeforeTaskUpdate", function (id, task) {
      gantt._init_task_timing(task);
      return true;
    });
    gantt.attachEvent("onBeforeTaskAdd", function (id, task) {
      gantt._init_task_timing(task);
      return true;
    });

  };

  data_task_layers(gantt) {
    delete gantt.addTaskLayer;
    delete gantt.addLinkLayer;
  };


  // data_task_types(gantt) {

  getTaskType(type) {
    return "task";
  };
  // };

  /***/
  // }

  // deprecatedWarnings() {

  // return function (gantt) {

  // no deprecated methods for now

  // eslint-disable-next-line no-unused-vars
  deprecated(badCode, goodCode, versionDeprecated, versionDeleted) {

    var formatting = this.env.isIE ? "" : "%c";
    versionDeprecated = versionDeprecated || "v6.0";
    versionDeleted = versionDeleted || "v7.0";

    var message = [
      formatting, "\"", badCode, "\"", formatting,
      " has been deprecated in dhtmlxGantt ", versionDeprecated, " and will stop working in ", versionDeleted, ". Use ",
      formatting, "\"", goodCode, "\"", formatting,
      " instead. \nSee more details at http://docs.dhtmlx.com/gantt/migrating.html "
    ].join("");

    var log = window.console.warn || window.console.log;

    var args = [message];
    if (!this.env.isIE) {
      args = args.concat(["font-weight:bold", "font-weight:normal", "font-weight:bold", "font-weight:normal"]);
    }

    log.apply(window.console, args);
  }

  destructor(gantt) {

    gantt.destructor = function () {
      gantt.callEvent("onDestroy", []);
      this.clearAll();

      if (this.config.$root) {
        delete this.config.$root.gantt;
      }

      this._eventRemoveAll();
      if (this.$layout) {
        this.$layout.destructor();
      }

      this.resetLightbox();

      if (this._dp && this._dp.destructor) {
        this._dp.destructor();
      }
      this.$services.destructor();

      // detachAllEvents should be called last, because in components may be attached events
      this.detachAllEvents();

      for (var i in this) {
        if (i.indexOf("$") === 0) {
          delete this[i];
        }
      }
      gantt.$destroyed = true;
    };
  }

  dynamicLoading(gantt) {

  };


  gantt() {
    this.commonService.import(this.gantt);
    this.skinService.terraceCss();
    // this.core();

    function DHXGantt() {
      console.log(this)
      var constants = this.constantService.keyCodes();
      var version = "6.2.6";
      var license = "gpl";
      var templates = {};
      var ext = {};
      var keys = {
        edit_save: constants.KEY_CODES.ENTER,
        edit_cancel: constants.KEY_CODES.ESC
      };
    }
    return function core() {
      // use a named constructor to make gantt instance discoverable in heap snapshots
      var gantt: any = new DHXGantt();

      this.$services = this.commonService.services;
      this.config = this.ganttService.config;
      gantt.ajax = this.commonService.ajax(gantt);
      gantt.date = this.commonService.date(gantt);
      var dnd = this.commonService.dnd(gantt);
      gantt.$services.setService("dnd", function () { return dnd; });

      gantt.$services.setService("config", function () {
        return this.config;
      });
      gantt.$services.setService("date", function () {
        return gantt.date;
      });
      gantt.$services.setService("locale", function () {
        return gantt.locale;
      });
      gantt.$services.setService("templates", function () {
        return gantt.templates;
      });

      var templatesLoader = (this.commonService.templates())(gantt);
      gantt.$services.setService("templateLoader", function () {
        return templatesLoader;
      });

      var eventable = (this.utilsService.eventable());
      eventable(gantt);

      var StateService = (this.commonService.state());
      var stateService = StateService();

      stateService.registerProvider("global", function () {
        var res = {
          min_date: gantt._min_date,
          max_date: gantt._max_date,
          selected_task: null
        };

        // do not throw error if getState called from non-initialized gantt
        if (gantt.$data && gantt.$data.tasksStore) {
          res.selected_task = gantt.$data.tasksStore.getSelectedId();
        }
        return res;
      });
      gantt.getState = stateService.getState;
      gantt.$services.setService("state", function () {
        return stateService;
      });

      var utils = this.utilsService.utils();
      utils.mixin(gantt, utils);

      gantt.Promise = this.utilsService.promise;
      gantt.env = this.utilsService.env;

      var domHelpers = this.utilsService;
      gantt.utils = {
        dom: {
          getNodePosition: domHelpers.getNodePosition,
          getRelativeEventPosition: domHelpers.getRelativeEventPosition,
          isChildOf: domHelpers.isChildOf,
          hasClass: domHelpers.hasClass,
          closest: domHelpers.closest
        }
      };

      var domEvents: any = this.utilsService.domEventScope();
      gantt.event = domEvents.attach;
      gantt.eventRemove = domEvents.detach;
      gantt._eventRemoveAll = domEvents.detachAll;
      gantt._createDomEventScope = domEvents.extend;

      utils.mixin(gantt, this.message)(gantt);
      var uiApi = this.uiService.index().init(gantt);
      gantt.$ui = uiApi.factory;
      gantt.$ui.layers = uiApi.render;
      gantt.$mouseEvents = uiApi.mouseEvents;
      gantt.$services.setService("mouseEvents", function () {
        return gantt.$mouseEvents;
      });
      gantt.mixin(gantt, uiApi.layersApi);

      this.data_task_layers(gantt);

      gantt.$services.setService("layers", function () {
        return uiApi.layersService;
      });

      var createLayoutFacade = this.facadeService.layout;
      gantt.mixin(gantt, createLayoutFacade());

      this.dataStoreService.datastoreHooks(gantt);

      var DataProcessor = this.dataProcessorService.index();
      gantt.dataProcessor = DataProcessor.DEPRECATED_api;
      gantt.createDataProcessor = DataProcessor.createDataProcessor;

      this.pluginService.index(gantt);

      this.dynamicLoading(gantt);
      this.gridColumnApi(gantt);
      this.waiAria(gantt);
      this.tasks(gantt);
      this.load(gantt);
      this.worktimeService.workTime(gantt);
      this.data(gantt);

      this.publishHelper.voidScriptSecond().default(gantt);

      this.lightboxService.index(gantt);
      this.lightboxOptionalTime(gantt);
      this.data_task_types(gantt);
      this.cachedFunctions(gantt);
      this.skin(gantt);
      this.skinService.skyblue(gantt);
      this.skinService.meadow(gantt);
      this.skinService.terrace(gantt);
      this.skinService.broadway(gantt);
      this.skinService.material(gantt);
      this.skinService.contrastBlack(gantt);
      this.skinService.contrastWhite(gantt);
      this.touch(gantt);
      this.localeService.index(gantt);
      this.gantt_core(gantt);
      this.destructor(gantt);
      this.publishHelper.voidScriptThird().default(gantt);
      return gantt;
    }
  }


  init(node, from?, to?) {

    if (from && to) {
      this.config.start_date = this.config.min_date = new Date(from);
      this.config.end_date = this.config.max_date = new Date(to);
    }
    // this.date.init();
    this.commonService.init();
    if (!this.config.scroll_size)
      this.config.scroll_size = this.utilsService.getScrollSize() || 1;

    // can be called only once
    this.init = function (node) {
      if (this.$container && this.$container.parentNode) {
        this.$container.parentNode.removeChild(this.$container);
        this.$container = null;
      }

      if (this.$layout) {
        this.$layout.clear();
      }
      this._reinit(node);
    };

    this._reinit(node);
  }

  _reinit(node) {
    this.utilsService.callEvent("onBeforeGanttReady", [], undefined);

    // detach listeners before clearing old DOM, possible IE errors when accessing detached nodes
    this.utilsService.detachAll();
    this.uiService.reset();

    this.ganttObject.resetLightbox();
    this.ganttObject._update_flags();


    var config = this.ganttObject.gantt.$services.getService("templateLoader");
    config.initTemplates(this);

    new GanttLayers()._clearTaskLayers();
    new GanttLayers()._clearLinkLayers();

    //this.clear
    if (this.ganttObject.gantt.$layout) {
      this.ganttObject.gantt.$layout.destructor();
      this.ganttObject.gantt.$ui.reset();
    }

    this.config.$root = this.utilsService.toNode(node);
    if (this.config.$root) {
      this.config.$root.innerHTML = "";
    }
    this.config.$root.gantt = this;
    new DataRange().updateTasksRange(this)
    this.config.layout.id = "main";
    this.ganttObject.gantt.$layout = this.ganttObject.gantt.$ui.createView("layout", node, this.config.layout);

    this.ganttObject.gantt.$layout.attachEvent("onBeforeResize", function () {
      var storeNames = this.$services.getService("datastores");
      for (var i = 0; i < storeNames.length; i++) {
        this.ganttObject.getDatastore(storeNames[i]).filter();
      }
    });

    this.ganttObject.gantt.$layout.attachEvent("onResize", (() => {
      this.ganttObject.refreshData();
    }));

    this.utilsService.callEvent("onGanttLayoutReady", [], undefined);
    this.ganttObject.gantt.$layout.render();

    this.ganttObject.gantt.$container = this.ganttObject.gantt.$layout.$container.firstChild;

    new GanttCore().addResizeListener(this.ganttObject.gantt);

    this.utilsService.callEvent("onTemplatesReady", [], undefined);
    this.uiService.reset(this.config.$root);
    this.utilsService.callEvent("onGanttReady", [], undefined);

    this.ganttObject.render();
  };


  gantt_core(gantt) {
    var domHelpers = this.utilsService,
      helpers = this.utilsService;
    // var calculateScaleRange = 

    // gantt.assert = this.commonService.assert(gantt);

    //initial initialization
    // gantt.init = function (node, from, to) {
    //   if (from && to) {
    //     this.config.start_date = this._min_date = new Date(from);
    //     this.config.end_date = this._max_date = new Date(to);
    //   }
    //   this.date.init();

    //   if (!this.config.scroll_size)
    //     this.config.scroll_size = domHelpers.getScrollSize() || 1;

    //   //can be called only once
    //   this.init = function (node) {
    //     if (this.$container && this.$container.parentNode) {
    //       this.$container.parentNode.removeChild(this.$container);
    //       this.$container = null;
    //     }

    //     if (this.$layout) {
    //       this.$layout.clear();
    //     }
    //     this._reinit(node);
    //   };

    //   this._reinit(node);
    // };
  };

  gridColumnApi(gantt) {
    gantt.getGridColumn = function (name) {
      var columns = this.config.columns;

      for (var i = 0; i < columns.length; i++) {
        if (columns[i].name == name)
          return columns[i];
      }

      return null;
    };

    gantt.getGridColumns = function () {
      return this.config.columns.slice();
    };
  };

  lightboxOptionalTime(gantt) {

    gantt._extend_to_optional = function (lightbox_block) {

      var duration = lightbox_block;
      var optional_time = {
        render: duration.render,
        focus: duration.focus,
        set_value: function (node, value, task, section) {
          var mapping = gantt._resolve_default_mapping(section);
          if (!task[mapping.start_date] || (mapping.start_date == "start_date" && this._isAllowedUnscheduledTask(task))) {
            optional_time.disable(node, section);
            var val = {};

            for (var i in mapping) {
              //take default values from the time control from task start/end dates
              val[mapping[i]] = task[i];
            }

            return duration.set_value.call(gantt, node, value, val, section);//set default value
          } else {
            optional_time.enable(node, section);
            return duration.set_value.call(gantt, node, value, task, section);
          }
        },
        get_value: function (node, task, section) {
          if (section.disabled) {
            return { start_date: null };
          } else {
            return duration.get_value.call(gantt, node, task, section);
          }
        },
        update_block: function (node, section) {
          gantt.callEvent("onSectionToggle", [gantt._lightbox_id, section]);
          node.style.display = section.disabled ? "none" : "block";

          if (section.button) {
            var button = node.previousSibling.querySelector(".gantt_custom_button_label"),
              labels = gantt.locale.labels;

            var button_text = section.disabled ? labels[section.name + "_enable_button"] : labels[section.name + "_disable_button"];

            button.innerHTML = button_text;
          }
          gantt.resizeLightbox();
        },
        disable: function (node, section) {
          section.disabled = true;
          optional_time.update_block(node, section);

        },
        enable: function (node, section) {
          section.disabled = false;
          optional_time.update_block(node, section);
        },
        button_click: function (index, el, section, container) {
          if (gantt.callEvent("onSectionButton", [gantt._lightbox_id, section]) === false) {
            return;
          }
          var config = gantt._get_typed_lightbox_config()[index];
          if (config.disabled) {
            optional_time.enable(container, config);
          } else {
            optional_time.disable(container, config);
          }
        }
      };
      return optional_time;
    };

    gantt.form_blocks.duration_optional = gantt._extend_to_optional(gantt.form_blocks.duration);
    gantt.form_blocks.time_optional = gantt._extend_to_optional(gantt.form_blocks.time);

  };


  load(gantt) {
    var helpers = this.utilsService;
    gantt.load = function (url, type, callback) {
      this._load_url = url;
      this.assert(arguments.length, "Invalid load arguments");

      var tp = 'json', cl = null;
      if (arguments.length >= 3) {
        tp = type;
        cl = callback;
      } else {
        if (typeof arguments[1] == "string")
          tp = arguments[1];
        else if (typeof arguments[1] == "function")
          cl = arguments[1];
      }

      this._load_type = tp;

      this.callEvent("onLoadStart", [url, tp]);

      return this.ajax.get(url, gantt.bind(function (l) {
        this.on_load(l, tp);
        this.callEvent("onLoadEnd", [url, tp]);
        if (typeof cl == "function")
          cl.call(this);
      }, this));
    };
    gantt.parse = function (data, type) {
      this.on_load({ xmlDoc: { responseText: data } }, type);
    };

    gantt.serialize = function (type) {
      type = type || "json";
      return this[type].serialize();
    };

    /*
    tasks and relations
    {
    data:[
      {
        "id":"string",
        "text":"...",
        "start_date":"Date or string",
        "end_date":"Date or string",
        "duration":"number",
        "progress":"0..1",
        "parent_id":"string",
        "order":"number"
      },...],
    links:[
      {
        id:"string",
        source:"string",
        target:"string",
        type:"string"
      },...],
    collections:{
        collectionName:[
          {key:, label:, optional:...},...
        ],...
      }
    }
  
    * */

    gantt.on_load = function (resp, type) {
      if (resp.xmlDoc && resp.xmlDoc.status === 404) { // work if we don't have a file at current url
        this.assert(false, "Failed to load the data from <a href='" + resp.xmlDoc.responseURL + "' target='_blank'>"
          + resp.xmlDoc.responseURL + "</a>, server returns 404");
        return;
      }
      this.callEvent("onBeforeParse", []);
      if (!type)
        type = "json";
      this.assert(this[type], "Invalid data type:'" + type + "'");

      var raw = resp.xmlDoc.responseText;

      var data = this[type].parse(raw, resp);
      this._process_loading(data);
    };

    gantt._process_loading = function (data) {
      if (data.collections)
        this._load_collections(data.collections);

      this.$data.tasksStore.parse(data.data);
      var links = data.links || (data.collections ? data.collections.links : []);
      this.$data.linksStore.parse(links);

      //this._sync_links();
      this.callEvent("onParse", []);
      this.render();
      if (this.config.initial_scroll) {
        var firstTask = this.getTaskByIndex(0);
        var id = firstTask ? firstTask.id : this.config.root_id;
        if (this.isTaskExists(id))
          this.showTask(id);
      }
    };


    gantt._load_collections = function (collections) {
      var collections_loaded = false;
      for (var key in collections) {
        if (collections.hasOwnProperty(key)) {
          collections_loaded = true;
          var collection = collections[key];
          var arr = this.serverList[key];
          if (!arr) continue;
          arr.splice(0, arr.length); //clear old options
          for (var j = 0; j < collection.length; j++) {
            var option = collection[j];
            var obj = this.copy(option);
            obj.key = obj.value;// resulting option object

            for (var option_key in option) {
              if (option.hasOwnProperty(option_key)) {
                if (option_key == "value" || option_key == "label")
                  continue;
                obj[option_key] = option[option_key]; // obj['value'] = option['value']
              }
            }
            arr.push(obj);
          }
        }
      }
      if (collections_loaded)
        this.callEvent("onOptionsLoad", []);
    };

    gantt.attachEvent("onBeforeTaskDisplay", function (id, task) {
      return !task.$ignore;
    });

    function jsonParseError(data) {
      gantt.assert(false, "Can't parse data: incorrect value of gantt.parse or gantt.load method. "
        + "Actual argument value: " + JSON.stringify(data));
      throw new Error("Invalid argument for gantt.parse or gantt.load. An object or a JSON string of format https://docs.dhtmlx.com/gantt/desktop__supported_data_formats.html#json is expected. Actual argument value: "
        + JSON.stringify(data));
    }

    gantt.json = {
      parse: function (data) {
        if (!data) {
          jsonParseError(data);
        }

        if (typeof data == "string") {
          if (this.window.JSON) {
            try {
              data = JSON.parse(data);
            }
            catch (e) {
              jsonParseError(data);
            }
          } else {
            gantt.assert(false, "JSON is not supported");
          }
        }

        if (!data.data) {
          jsonParseError(data);
        }

        if (data.dhx_security)
          gantt.security_key = data.dhx_security;
        return data;
      },
      serializeTask: function (task) {
        return this._copyObject(task);
      },
      serializeLink: function (link) {
        return this._copyLink(link);
      },
      _copyLink: function (obj) {
        var copy = {};
        for (var key in obj)
          copy[key] = obj[key];
        return copy;
      },
      _copyObject: function (obj) {
        var copy = {};
        for (var key in obj) {
          if (key.charAt(0) == "$")
            continue;
          copy[key] = obj[key];

          if (helpers.isDate(copy[key])) {
            copy[key] = gantt.templates.xml_format !== gantt.templates.formate_date ? gantt.templates.xml_format(copy[key]) : gantt.templates.formate_date(copy[key]);
          }
        }
        return copy;
      },
      serialize: function () {
        var tasks = [];
        var links = [];

        gantt.eachTask(function (obj) {
          gantt.resetProjectDates(obj);
          tasks.push(this.serializeTask(obj));
        }, this.config.root_id, this);

        var rawLinks = gantt.getLinks();
        for (var i = 0; i < rawLinks.length; i++) {
          links.push(this.serializeLink(rawLinks[i]));
        }

        return {
          data: tasks,
          links: links
        };
      }
    };

    /*
    <data>
      <task id:"some" parent_id="0" progress="0.5">
        <text>My task 1</text>
        <start_date>16.08.2013</start_date>
        <end_date>22.08.2013</end_date>
      </task>
      <coll_options>
        <links>
          <link source='a1' target='b2' type='c3' />
        </links>
      </coll_options>
    </data>
    */

    function xmlParseError(data) {
      gantt.assert(false, "Can't parse data: incorrect value of gantt.parse or gantt.load method. "
        + "Actual argument value: " + JSON.stringify(data));
      throw new Error("Invalid argument for gantt.parse or gantt.load. An XML of format https://docs.dhtmlx.com/gantt/desktop__supported_data_formats.html#xmldhtmlxgantt20 is expected. Actual argument value: "
        + JSON.stringify(data));
    }

    gantt.xml = {
      _xmlNodeToJSON: function (node, attrs_only) {
        var t: any = {};
        for (var i = 0; i < node.attributes.length; i++)
          t[node.attributes[i].name] = node.attributes[i].value;

        if (!attrs_only) {
          for (var i = 0; i < node.childNodes.length; i++) {
            var child = node.childNodes[i];
            if (child.nodeType == 1)
              t[child.tagName] = child.firstChild ? child.firstChild.nodeValue : "";
          }

          if (!t.text) t.text = node.firstChild ? node.firstChild.nodeValue : "";
        }

        return t;
      },
      _getCollections: function (loader) {
        var collection = {};
        var opts = gantt.ajax.xpath("//coll_options", loader);
        for (var i = 0; i < opts.length; i++) {
          var bind = opts[i].getAttribute("for");
          var arr = collection[bind] = [];
          var itms = gantt.ajax.xpath(".//item", opts[i]);
          for (var j = 0; j < itms.length; j++) {
            var itm = itms[j];
            var attrs = itm.attributes;
            var obj = { key: itms[j].getAttribute("value"), label: itms[j].getAttribute("label") };
            for (var k = 0; k < attrs.length; k++) {
              var attr = attrs[k];
              if (attr.nodeName == "value" || attr.nodeName == "label")
                continue;
              obj[attr.nodeName] = attr.nodeValue;
            }
            arr.push(obj);
          }
        }
        return collection;
      },
      _getXML: function (text, loader, toptag) {
        toptag = toptag || "data";
        if (!loader.getXMLTopNode) {
          loader = gantt.ajax.parse(loader);
        }

        var xml = gantt.ajax.xmltop(toptag, loader.xmlDoc);
        if (!xml || xml.tagName != toptag) {
          xmlParseError(text);
        }

        var skey = xml.getAttribute("dhx_security");
        if (skey)
          gantt.security_key = skey;

        return xml;
      },
      parse: function (text, loader) {
        loader = this._getXML(text, loader);
        var data: any = {};

        var evs = data.data = [];
        var xml = gantt.ajax.xpath("//task", loader);

        for (var i = 0; i < xml.length; i++)
          evs[i] = this._xmlNodeToJSON(xml[i]);

        data.collections = this._getCollections(loader);
        return data;
      },
      _copyLink: function (obj) {
        return "<item id='" + obj.id + "' source='" + obj.source + "' target='" + obj.target + "' type='" + obj.type + "' />";
      },
      _copyObject: function (obj) {
        return "<task id='" + obj.id + "' parent='" + (obj.parent || "") + "' start_date='" + obj.start_date + "' duration='" + obj.duration + "' open='" + (!!obj.open) + "' progress='" + obj.progress + "' end_date='" + obj.end_date + "'><![CDATA[" + obj.text + "]]></task>";
      },
      serialize: function () {
        var tasks = [];
        var links = [];

        var json = gantt.json.serialize();
        for (var i = 0, len = json.data.length; i < len; i++) {
          tasks.push(this._copyObject(json.data[i]));
        }
        for (var i = 0, len = json.links.length; i < len; i++) {
          links.push(this._copyLink(json.links[i]));
        }
        return "<data>" + tasks.join("") + "<coll_options for='links'>" + links.join("") + "</coll_options></data>";
      }
    };


    gantt.oldxml = {
      parse: function (text, loader) {
        loader = gantt.xml._getXML(text, loader, "projects");
        var data: any = { collections: { links: [] } };

        var evs = data.data = [];
        var xml = gantt.ajax.xpath("//task", loader);

        for (var i = 0; i < xml.length; i++) {
          evs[i] = gantt.xml._xmlNodeToJSON(xml[i]);
          var parent = xml[i].parentNode;

          if (parent.tagName == "project")
            evs[i].parent = "project-" + parent.getAttribute("id");
          else
            evs[i].parent = parent.parentNode.getAttribute("id");
        }

        xml = gantt.ajax.xpath("//project", loader);
        for (var i = 0; i < xml.length; i++) {
          var ev = gantt.xml._xmlNodeToJSON(xml[i], true);
          ev.id = "project-" + ev.id;
          evs.push(ev);
        }

        for (var i = 0; i < evs.length; i++) {
          var ev = evs[i];
          ev.start_date = ev.startdate || ev.est;
          ev.end_date = ev.enddate;
          ev.text = ev.name;
          ev.duration = ev.duration / 8;
          ev.open = 1;
          if (!ev.duration && !ev.end_date) ev.duration = 1;
          if (ev.predecessortasks)
            data.collections.links.push({
              target: ev.id,
              source: ev.predecessortasks,
              type: this.config.links.finish_to_start
            });
        }

        return data;
      },
      serialize: function () {
        gantt.message("Serialization to 'old XML' is not implemented");
      }
    };

    gantt.serverList = function (name, array) {
      if (array) {
        this.serverList[name] = array.slice(0);
      } else if (!this.serverList[name]) {
        this.serverList[name] = [];
      }
      return this.serverList[name];
    };

  };


  skin(gantt) {

    function _configure(col, data, force) {
      for (var key in data)
        if (typeof col[key] == "undefined" || force)
          col[key] = data[key];
    }

    function _get_skin(force, gantt) {
      var skin = gantt.skin;
      if (!skin || force) {
        var links = document.getElementsByTagName("link");
        for (var i = 0; i < links.length; i++) {
          var res = links[i].href.match("dhtmlxgantt_([a-z_]+).css");
          if (res) {
            if (gantt.skins[res[1]] || !skin) {
              skin = res[1];
              break;
            }
          }
        }
      }

      gantt.skin = skin || "terrace";
      var skinset = gantt.skins[gantt.skin] || gantt.skins["terrace"];

      //apply skin related settings
      _configure(this.config, skinset.config, force);

      var config = gantt.getGridColumns();
      if (config[1] && !gantt.defined(config[1].width))
        config[1].width = skinset._second_column_width;
      if (config[2] && !gantt.defined(config[2].width))
        config[2].width = skinset._third_column_width;

      for (var i = 0; i < config.length; i++) {
        var column = config[i];
        if (column.name == "add") {
          if (!column.width) {
            column.width = 44;
          }
          if (!(gantt.defined(column.min_width) && gantt.defined(column.max_width))) {
            column.min_width = column.min_width || column.width;
            column.max_width = column.max_width || column.width;
          }
          if (column.min_width)
            column.min_width = +column.min_width;
          if (column.max_width)
            column.max_width = +column.max_width;
          if (column.width) {
            column.width = +column.width;
            column.width = (column.min_width && column.min_width > column.width) ? column.min_width : column.width;
            column.width = (column.max_width && column.max_width < column.width) ? column.max_width : column.width;
          }
        }
      }

      if (skinset.config.task_height)
        this.config.task_height = skinset.config.task_height || "full";

      if (skinset._lightbox_template)
        gantt._lightbox_template = skinset._lightbox_template;

      if (skinset._redefine_lightbox_buttons) {
        this.config.buttons_right = skinset._redefine_lightbox_buttons["buttons_right"];
        this.config.buttons_left = skinset._redefine_lightbox_buttons["buttons_left"];
      }


      gantt.resetLightbox();
    }

    return function (gantt) {
      if (!gantt.resetSkin) {
        gantt.resetSkin = function () {
          this.skin = "";
          _get_skin(true, this);
        };
        gantt.skins = {};

        gantt.attachEvent("onGanttLayoutReady", function () {
          _get_skin(false, this);
        });
      }
    };

    /***/
  }


  tasks(gantt) {
    gantt.isReadonly = function (item) {
      if (item && item[this.config.editable_property]) {
        return false;
      } else {
        return (item && item[this.config.readonly_property]) || this.config.readonly;
      }
    };
  };


  touch(gantt) {

    this.config.touch_drag = 500; //nearly immediate dnd
    this.config.touch = true;
    this.config.touch_feedback = true;
    this.config.touch_feedback_duration = 1;
    gantt._prevent_touch_scroll = false;


    gantt._touch_feedback = function () {
      if (this.config.touch_feedback) {
        if (navigator.vibrate)
          navigator.vibrate(this.config.touch_feedback_duration);
      }
    };

    gantt.attachEvent("onGanttReady", gantt.bind(function () {
      if (this.config.touch != "force")
        this.config.touch = this.config.touch &&
          ((navigator.userAgent.indexOf("Mobile") != -1) ||
            (navigator.userAgent.indexOf("iPad") != -1) ||
            (navigator.userAgent.indexOf("Android") != -1) ||
            (navigator.userAgent.indexOf("Touch") != -1));

      if (this.config.touch) {

        var touchEventsSupported = true;
        try {
          document.createEvent("TouchEvent");
        } catch (e) {
          touchEventsSupported = false;
        }

        if (touchEventsSupported) {
          this._touch_events(["touchmove", "touchstart", "touchend"], function (ev) {
            if (ev.touches && ev.touches.length > 1) return null;
            if (ev.touches[0])
              return {
                target: ev.target,
                pageX: ev.touches[0].pageX,
                pageY: ev.touches[0].pageY,
                clientX: ev.touches[0].clientX,
                clientY: ev.touches[0].clientY
              };
            else
              return ev;
          }, function () {
            return false;
          });
        } else if (window.navigator.pointerEnabled) {
          this._touch_events(["pointermove", "pointerdown", "pointerup"], function (ev) {
            if (ev.pointerType == "mouse") return null;
            return ev;
          }, function (ev) {
            return (!ev || (ev.pointerType == "mouse"));
          });
        } else if (window.navigator.msPointerEnabled) {
          this._touch_events(["MSPointerMove", "MSPointerDown", "MSPointerUp"], function (ev) {
            if (ev.pointerType == ev.MSPOINTER_TYPE_MOUSE) return null;
            return ev;
          }, function (ev) {
            return (!ev || ev.pointerType == ev.MSPOINTER_TYPE_MOUSE);
          });
        }

      }
    }, gantt));


    function getTaskDND() {
      var _tasks_dnd;
      if (gantt.$ui.getView("timeline")) {
        _tasks_dnd = gantt.$ui.getView("timeline")._tasks_dnd;
      }
      return _tasks_dnd;
    }

    var touchHandlers = [];

    //we can't use native scrolling, as we need to sync momentum between different parts
    //so we will block native scroll and use the custom one
    //in future we can add custom momentum
    gantt._touch_events = function (names, accessor, ignore) {
      //webkit on android need to be handled separately
      var dblclicktime: any = 0;
      var action_mode = false;
      var scroll_mode = false;
      var action_start = null;
      var scroll_state;
      var long_tap_timer = null;
      var current_target = null;



      for (var i = 0; i < touchHandlers.length; i++) {
        gantt.eventRemove(touchHandlers[i][0], touchHandlers[i][1], touchHandlers[i][2]);
      }
      touchHandlers = [];

      //touch move
      touchHandlers.push([gantt.$container, names[0], function (e) {
        var _tasks_dnd = getTaskDND();

        if (ignore(e)) return;

        //ignore common and scrolling moves
        if (!action_mode) return;

        if (long_tap_timer) clearTimeout(long_tap_timer);

        var source = accessor(e);
        if (_tasks_dnd && (_tasks_dnd.drag.id || _tasks_dnd.drag.start_drag)) {
          _tasks_dnd.on_mouse_move(source);
          if (e.preventDefault)
            e.preventDefault();
          e.cancelBubble = true;
          return false;
        }
        if (!gantt._prevent_touch_scroll) {
          if (source && action_start) {
            var dx = action_start.pageX - source.pageX;
            var dy = action_start.pageY - source.pageY;
            if (!scroll_mode && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
              gantt._touch_scroll_active = scroll_mode = true;
              dblclicktime = 0;
              scroll_state = gantt.getScrollState();
            }

            if (scroll_mode) {
              gantt.scrollTo(scroll_state.x + dx, scroll_state.y + dy);
              var new_scroll_state = gantt.getScrollState();

              if ((scroll_state.x != new_scroll_state.x && dy > 2 * dx) ||
                (scroll_state.y != new_scroll_state.y && dx > 2 * dy)) {
                return block_action(e);
              }
            }
          }
          return block_action(e);
        }
        return true;
      }]);


      //block touch context menu in IE10
      touchHandlers.push([this.$container, "contextmenu", function (e) {
        if (action_mode)
          return block_action(e);
      }]);

      //touch start
      touchHandlers.push([this.$container, names[1], function (e) {
        if (ignore(e)) return;
        if (e.touches && e.touches.length > 1) {
          action_mode = false;
          return;
        }

        action_start = accessor(e);
        if (!gantt._locate_css(action_start, "gantt_hor_scroll") && !gantt._locate_css(action_start, "gantt_ver_scroll")) {
          action_mode = true;
        }
        var _tasks_dnd = getTaskDND();

        //long tap
        long_tap_timer = setTimeout(function () {
          var taskId = gantt.locate(action_start);
          if (_tasks_dnd && (taskId && !gantt._locate_css(action_start, "gantt_link_control") && !gantt._locate_css(action_start, "gantt_grid_data"))) {
            _tasks_dnd.on_mouse_down(action_start);

            if (_tasks_dnd.drag && _tasks_dnd.drag.start_drag) {
              cloneTaskRendered(taskId);
              _tasks_dnd._start_dnd(action_start);
              gantt._touch_drag = true;

              gantt.refreshTask(taskId);

              gantt._touch_feedback();
            }

          }

          long_tap_timer = null;
        }, this.config.touch_drag);
      }]);

      //touch end
      touchHandlers.push([this.$container, names[2], function (e) {
        if (ignore(e)) return;
        if (long_tap_timer) clearTimeout(long_tap_timer);
        gantt._touch_drag = false;
        action_mode = false;
        var source = accessor(e);

        var _tasks_dnd = getTaskDND();

        if (_tasks_dnd)
          _tasks_dnd.on_mouse_up(source);

        if (current_target) {
          gantt.refreshTask(gantt.locate(current_target));
          if (current_target.parentNode) {
            current_target.parentNode.removeChild(current_target);
            gantt._touch_feedback();
          }
        }

        gantt._touch_scroll_active = action_mode = scroll_mode = false;
        current_target = null;

        //dbl-tap handling
        if (action_start && dblclicktime) {
          var now: any = new Date();
          if ((now - dblclicktime) < 500) {

            var mouseEvents = gantt.$services.getService("mouseEvents");
            mouseEvents.onDoubleClick(action_start);
            block_action(e);
          } else
            dblclicktime = now;
        } else {
          dblclicktime = new Date();
        }
      }]);

      for (var i = 0; i < touchHandlers.length; i++) {
        gantt.event(touchHandlers[i][0], touchHandlers[i][1], touchHandlers[i][2]);
      }

      //common helper, prevents event
      function block_action(e) {
        if (e && e.preventDefault)
          e.preventDefault();
        (e || event).cancelBubble = true;
        return false;
      }

      function cloneTaskRendered(taskId) {
        var renders = gantt._getTaskLayers();
        var task = gantt.getTask(taskId);
        if (task && gantt.isTaskVisible(taskId)) {
          for (var i = 0; i < renders.length; i++) {
            task = renders[i].rendered[taskId];
            if (task && task.getAttribute(this.config.task_attribute) && task.getAttribute(this.config.task_attribute) == taskId) {
              var copy = task.cloneNode(true);
              current_target = task;
              renders[i].rendered[taskId] = copy;
              task.style.display = "none";
              copy.className += " gantt_drag_move ";
              task.parentNode.appendChild(copy);
              //return copy;
            }
          }
        }
      }
    };

  };


  waiAria(gantt) {
    // TODO: why eslint fails on regexp?
    // eslint-disable-next-line no-control-regex
    var htmlTags = new RegExp("<(?:.|\n)*?>", "gm");
    var extraSpaces = new RegExp(" +", "gm");

    function stripHTMLLite(htmlText) {
      return (htmlText + "")
        .replace(htmlTags, " ").
        replace(extraSpaces, " ");
    }

    var singleQuotes = new RegExp("'", "gm");
    function escapeQuotes(text) {
      return (text + "").replace(singleQuotes, "&#39;");
    }

    gantt._waiAria = {
      getAttributeString: function (attr) {
        var attributes = [" "];
        for (var i in attr) {
          var text = escapeQuotes(stripHTMLLite(attr[i]));
          attributes.push(i + "='" + text + "'");
        }
        attributes.push(" ");
        return attributes.join(" ");

      },

      getTimelineCellAttr: function (dateString) {

        return gantt._waiAria.getAttributeString({ "aria-label": dateString });
      },

      _taskCommonAttr: function (task, div) {

        if (!(task.start_date && task.end_date))
          return;

        div.setAttribute("aria-label", stripHTMLLite(gantt.templates.tooltip_text(task.start_date, task.end_date, task)));

        if (gantt.isReadonly(task)) {
          div.setAttribute("aria-readonly", true);
        }

        if (task.$dataprocessor_class) {
          div.setAttribute("aria-busy", true);
        }

        div.setAttribute("aria-selected", gantt.isSelectedTask(task.id) ? "true" : "false");
      },

      setTaskBarAttr: function (task, div) {
        this._taskCommonAttr(task, div);

        if (!gantt.isReadonly(task) && this.config.drag_move) {
          if (task.id != gantt.getState().drag_id) {
            div.setAttribute("aria-grabbed", false);
          } else {
            div.setAttribute("aria-grabbed", true);
          }
        }
      },

      taskRowAttr: function (task, div) {

        this._taskCommonAttr(task, div);

        if (!gantt.isReadonly(task) && this.config.order_branch) {
          div.setAttribute("aria-grabbed", false);
        }

        div.setAttribute("role", "row");

        div.setAttribute("aria-level", task.$level);

        if (gantt.hasChild(task.id)) {
          div.setAttribute("aria-expanded", task.$open ? "true" : "false");
        }
      },

      linkAttr: function (link, div) {

        var linkTypes = this.config.links;

        var toStart = link.type == linkTypes.finish_to_start || link.type == linkTypes.start_to_start;
        var fromStart = link.type == linkTypes.start_to_start || link.type == linkTypes.start_to_finish;

        var content = gantt.locale.labels.link + " " + gantt.templates.drag_link(link.source, fromStart, link.target, toStart);

        div.setAttribute("aria-label", stripHTMLLite(content));
        if (gantt.isReadonly(link)) {
          div.setAttribute("aria-readonly", true);
        }
      },

      gridSeparatorAttr: function (div) {
        div.setAttribute("role", "separator");
      },

      lightboxHiddenAttr: function (div) {
        div.setAttribute("aria-hidden", "true");
      },

      lightboxVisibleAttr: function (div) {
        div.setAttribute("aria-hidden", "false");
      },

      lightboxAttr: function (div) {
        div.setAttribute("role", "dialog");
        div.setAttribute("aria-hidden", "true");
        div.firstChild.setAttribute("role", "heading");
      },

      lightboxButtonAttrString: function (buttonName) {
        return this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels[buttonName], "tabindex": "0" });
      },

      lightboxHeader: function (div, headerText) {
        div.setAttribute("aria-label", headerText);
      },

      lightboxSelectAttrString: function (time_option) {
        var label = "";

        switch (time_option) {
          case "%Y":
            label = gantt.locale.labels.years;
            break;
          case "%m":
            label = gantt.locale.labels.months;
            break;
          case "%d":
            label = gantt.locale.labels.days;
            break;
          case "%H:%i":
            label = gantt.locale.labels.hours + gantt.locale.labels.minutes;
            break;
          default:
            break;
        }

        return gantt._waiAria.getAttributeString({ "aria-label": label });
      },

      lightboxDurationInputAttrString: function (section) {
        return this.getAttributeString({ "aria-label": gantt.locale.labels.column_duration, "aria-valuemin": "0" });
      },

      gridAttrString: function () {
        return [" role='treegrid'", this.config.multiselect ? "aria-multiselectable='true'" : "aria-multiselectable='false'", " "].join(" ");
      },


      gridScaleRowAttrString: function () {
        return "role='row'";
      },

      gridScaleCellAttrString: function (column, label) {
        var attrs = "";
        if (column.name == "add") {
          attrs = this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels.new_task });
        } else {

          var attributes = {
            "role": "columnheader",
            "aria-label": label
          };

          if (gantt._sort && gantt._sort.name == column.name) {
            if (gantt._sort.direction == "asc") {
              attributes["aria-sort"] = "ascending";
            } else {
              attributes["aria-sort"] = "descending";
            }
          }

          attrs = this.getAttributeString(attributes);
        }
        return attrs;
      },

      gridDataAttrString: function () {
        return "role='rowgroup'";
      },

      gridCellAttrString: function (column, textValue) {
        return this.getAttributeString({ "role": "gridcell", "aria-label": textValue });
      },

      gridAddButtonAttrString: function (column) {
        return this.getAttributeString({ "role": "button", "aria-label": gantt.locale.labels.new_task });
      },

      messageButtonAttrString: function (buttonLabel) {
        return "tabindex='0' role='button' aria-label='" + buttonLabel + "'";
      },

      messageInfoAttr: function (div) {
        div.setAttribute("role", "alert");
        //div.setAttribute("tabindex", "-1");
      },

      messageModalAttr: function (div, uid) {
        div.setAttribute("role", "dialog");
        if (uid) {
          div.setAttribute("aria-labelledby", uid);
        }

        //	div.setAttribute("tabindex", "-1");
      },

      quickInfoAttr: function (div) {
        div.setAttribute("role", "dialog");
      },

      quickInfoHeaderAttrString: function () {
        return " role='heading' ";
      },

      quickInfoHeader: function (div, header) {
        div.setAttribute("aria-label", header);
      },

      quickInfoButtonAttrString: function (label) {
        return gantt._waiAria.getAttributeString({ "role": "button", "aria-label": label, "tabindex": "0" });
      },

      tooltipAttr: function (div) {
        div.setAttribute("role", "tooltip");
      },

      tooltipVisibleAttr: function (div) {
        div.setAttribute("aria-hidden", "false");
      },

      tooltipHiddenAttr: function (div) {
        div.setAttribute("aria-hidden", "true");
      }
    };

    function isDisabled() {
      return !this.config.wai_aria_attributes;
    }

    for (var i in gantt._waiAria) {
      gantt._waiAria[i] = (function (payload) {
        return function () {
          if (isDisabled()) {
            return "";
          }
          return payload.apply(this, arguments);
        };
      })(gantt._waiAria[i]);
    }


  };

}

export class GanttCore {

  addResizeListener(gantt) {
    var containerStyles = window.getComputedStyle(gantt.$root);
    if (containerStyles.getPropertyValue("position") == "static") {
      gantt.$root.style.position = "relative";
    }

    var resizeWatcher = document.createElement('iframe');
    resizeWatcher.className = "gantt_container_resize_watcher";
    resizeWatcher.tabIndex = -1;

    // in some environments (namely, in SalesForce) iframe.contentWindow is not available
    gantt.$root.appendChild(resizeWatcher);
    if (resizeWatcher.contentWindow) {
      this.listenWindowResize(gantt, resizeWatcher.contentWindow);
    } else {
      // if so - ditch the iframe and fallback to listening the main window resize
      gantt.$root.removeChild(resizeWatcher);
      this.listenWindowResize(gantt, window);
    }
  }

  listenWindowResize(gantt, window) {
    var resizeDelay;
    gantt.event(window, "resize", function () {
      clearTimeout(resizeDelay);
      resizeDelay = setTimeout(function () {
        gantt.render();
      }, 300);
    });
  }

}

