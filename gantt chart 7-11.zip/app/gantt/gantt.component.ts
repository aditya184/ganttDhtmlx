import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
// import 'dhtmlx-gantt';
import { CoreService } from '../services/core/core.service';


@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css'],
})
export class GanttComponent implements OnInit {
  constructor(private datepipe: DatePipe, private coreService: CoreService) { }
  @ViewChild('gantt_here') ganttContainer: ElementRef;

  constants;
  templates;

  ngOnInit() {

    // gantt.init(this.ganttContainer.nativeElement);
    this.coreService.init(this.ganttContainer.nativeElement);
    // this.coreService.gantt();
  }

  // dhtmlxGantt() {
  //   var window: any = window;
  //   // var warnings = this.coreService.deprecatedWarnings();
  //   var base = this.coreService.gantt();
  //   var gantt = window.gantt = base;
  //   // warnings(gantt);
  //   return gantt = gantt;
  //   // return default = gantt;
  // }
}

