import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
// import 'dhtmlx-gantt';
// import { CoreService } from '../services/core/core.service';
import { Core } from '../services/gantt-object.service';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css'],

})
export class GanttComponent implements OnInit {
  constructor(private gantt: Core) { }
  @ViewChild('gantt_here') ganttContainer: ElementRef;


  ngOnInit() {
    // gantt.init(this.ganttContainer.nativeElement);
    this.gantt.gantt();
    this.gantt.init(this.ganttContainer.nativeElement);
  }
}

