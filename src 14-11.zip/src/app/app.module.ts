import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GanttComponent } from './gantt/gantt.component';
import { Core, CommonService , Datastore, DataStore, Ui} from './services/gantt-object.service';
import { SkinsService } from './services/css/skins/skins.service';
import { UtilsService, EventHost } from './services/utils/utils.service';

@NgModule({
  declarations: [
    AppComponent,
    GanttComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [Core, CommonService, Ui, Datastore, DataStore, SkinsService, UtilsService, EventHost],
  bootstrap: [AppComponent]
})
export class AppModule { }
