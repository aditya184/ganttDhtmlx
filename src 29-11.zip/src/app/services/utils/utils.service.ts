import { Injectable } from '@angular/core';
import { Promise } from '../../../../node_modules/bluebird/js/browser/bluebird.js';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {
  units: any = {
    "second": 1,
    "minute": 60,
    "hour": 60 * 60,
    "day": 60 * 60 * 24,
    "week": 60 * 60 * 24 * 7,
    "month": 60 * 60 * 24 * 30,
    "quarter": 60 * 60 * 24 * 30 * 3,
    "year": 60 * 60 * 24 * 365
  }
  window: any;
  // eventHost: EventHost;
  handlers = [];


  constructor(private eventHost: EventHost) { }
  getSecondsInUnit(unit) {
    return this.units[unit] || this.units.hour;
  }

  forEach(arr, callback) {
    if (arr.forEach) {
      arr.forEach(callback);
    } else {
      var workArray = arr.slice();
      for (var i = 0; i < workArray.length; i++) {
        callback(workArray[i], i);
      }
    }
  }

  arrayMap(arr, callback) {
    if (arr.map) {
      return arr.map(callback);
    } else {
      var workArray = arr.slice();
      var resArray = [];

      for (var i = 0; i < workArray.length; i++) {
        resArray.push(callback(workArray[i], i));
      }
      return resArray;
    }
  }

  arrayFind(arr, callback) {
    if (arr.find) {
      return arr.find(callback);
    } else {
      for (var i = 0; i < arr.length; i++) {
        if (callback(arr[i], i)) {
          return arr[i];
        }
      }
    }
  }

  // iframe-safe array type check instead of using instanceof
  isArray(obj) {
    if (Array.isArray) {
      return Array.isArray(obj);
    } else {
      // close enough
      return (obj && obj.length !== undefined && obj.pop && obj.push);
    }
  }

  // non-primitive string object, e.g. new String("abc")
  isStringObject(obj) {
    return obj && typeof obj === "object"
      && Function.prototype.toString.call(obj.constructor) === "function String() { [native code] }";
  }

  // non-primitive number object, e.g. new Number(5)
  isNumberObject(obj) {
    return obj && typeof obj === "object"
      && Function.prototype.toString.call(obj.constructor) === "function Number() { [native code] }";
  }

  // non-primitive number object, e.g. new Boolean(true)
  isBooleanObject(obj) {
    return obj && typeof obj === "object"
      && Function.prototype.toString.call(obj.constructor) === "function Boolean() { [native code] }";
  }

  isDate(obj) {
    if (obj && typeof obj === "object") {
      return !!(obj.getFullYear && obj.getMonth && obj.getDate);
    } else {
      return false;
    }
  }

  arrayFilter(arr, callback) {
    var result = [];

    if (arr.filter) {
      return arr.filter(callback);
    } else {
      for (var i = 0; i < arr.length; i++) {
        if (callback(arr[i], i)) {
          result[result.length] = arr[i];
        }
      }
      return result;
    }
  }

  hashToArray(hash) {
    var result = [];

    for (var key in hash) {
      if (hash.hasOwnProperty(key)) {
        result.push(hash[key]);
      }
    }

    return result;
  }

  arraySome(arr, callback) {
    if (arr.length === 0) return false;

    for (var i = 0; i < arr.length; i++) {
      if (callback(arr[i], i, arr)) {
        return true;
      }
    }
    return false;
  }

  arrayDifference(arr, callback) {
    return this.arrayFilter(arr, function (item, i) {
      return !callback(item, i);
    });
  }

  throttle(callback, timeout) {
    var wait = false;

    return function () {
      if (!wait) {
        callback.apply(null, arguments);
        wait = true;
        setTimeout(function () {
          wait = false;
        }, timeout);
      }
    };
  }

  delay(callback, timeout) {
    var timer;

    var result: any = function () {
      result.$cancelTimeout();
      callback.$pending = true;
      var args = Array.prototype.slice.call(arguments);
      timer = setTimeout(function () {
        callback.apply(this, args);
        result.$pending = false;
      }, timeout);
    };

    result.$pending = false;
    result.$cancelTimeout = function () {
      clearTimeout(timer);
      callback.$pending = false;
    };
    result.$execute = function () {
      callback();
      callback.$cancelTimeout();
    };

    return result;
  }

  sortArrayOfHash(arr, field, desc) {
    var compare = function (a, b) {
      return a < b;
    };

    arr.sort(function (a, b) {
      if (a[field] === b[field]) return 0;

      return desc ? compare(a[field], b[field]) : compare(b[field], a[field]);
    });
  }

  objectKeys(obj) {
    if (Object.keys) {
      return Object.keys(obj);
    }
    var result = [];
    var key;
    for (key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        result.push(key);
      }
    }
    return result;
  }

  requestAnimationFrame(callback) {
    var w: any = window;
    var foundRequestAnimationFrame = w.requestAnimationFrame
      || w.webkitRequestAnimationFrame
      || w.msRequestAnimationFrame
      || w.mozRequestAnimationFrame
      || w.oRequestAnimationFrame
      || function (cb) { setTimeout(cb, 1000 / 60); };
    return foundRequestAnimationFrame(callback);
  }

  isEventable(obj) {
    return obj.attachEvent && obj.detachEvent;
  }
  // }


  domEventScope(addEvent, removeEvent) {


    function createScope(addEvent, removeEvent) {
      addEvent = addEvent || this.event;
      removeEvent = removeEvent || this.eventRemove;

      var handlers = [];

      var eventScope = {
        attach(el, event, callback, capture) {
          handlers.push({ element: el, event: event, callback: callback, capture: capture });
          addEvent(el, event, callback, capture);
        },
        detach(el, event, callback, capture) {
          removeEvent(el, event, callback, capture);
          for (var i = 0; i < handlers.length; i++) {
            var handler = handlers[i];
            if (handler.element === el && handler.event === event && handler.callback === callback && handler.capture === capture) {
              handlers.splice(i, 1);
              i--;
            }
          }
        },
        detachAll() {
          var staticArray = handlers.slice();
          // original handlers array can be spliced on every iteration
          for (var i = 0; i < staticArray.length; i++) {
            var handler = staticArray[i];
            eventScope.detach(handler.element, handler.event, handler.callback, handler.capture);
            eventScope.detach(handler.element, handler.event, handler.callback, undefined);
            eventScope.detach(handler.element, handler.event, handler.callback, false);
            eventScope.detach(handler.element, handler.event, handler.callback, true);
          }
          handlers.splice(0, handlers.length);
        },
        extend() {
          return createScope(this.event, this.eventRemove);
        }
      };
      var w: any = window
      if (!w.scopes) {
        w.scopes = [];
      }
      w.scopes.push(handlers);
      return eventScope;
    }

    return createScope;

    /***/
  }

  attach(el, event, callback, capture) {
    this.handlers.push({ element: el, event: event, callback: callback, capture: capture });
    this.event(el, event, callback, capture);
  }

  detach(el, event, callback, capture) {
    this.eventRemove(el, event, callback, capture);
    for (var i = 0; i < this.handlers.length; i++) {
      var handler = this.handlers[i];
      if (handler.element === el && handler.event === event && handler.callback === callback && handler.capture === capture) {
        this.handlers.splice(i, 1);
        i--;
      }
    }
  }

  detachAll() {
    var staticArray = this.handlers.slice();
    // original handlers array can be spliced on every iteration
    for (var i = 0; i < staticArray.length; i++) {
      var handler = staticArray[i];
      this.detach(handler.element, handler.event, handler.callback, handler.capture);
      this.detach(handler.element, handler.event, handler.callback, undefined);
      this.detach(handler.element, handler.event, handler.callback, false);
      this.detach(handler.element, handler.event, handler.callback, true);
    }
    this.handlers.splice(0, this.handlers.length);
  }

  extend() {
    return this.domEventScope(this.event, this.eventRemove);
  }


  // domHelpers() {

  //returns position of html element on the page
  elementPosition(elem) {
    var top = 0, left = 0, right = 0, bottom = 0;
    if (elem.getBoundingClientRect) { //HTML5 method
      var box = elem.getBoundingClientRect();
      var body = document.body;
      var docElem: any = (document.documentElement ||
        document.body.parentNode ||
        document.body);

      var scrollTop = window.pageYOffset || docElem.scrollTop || body.scrollTop;
      var scrollLeft = window.pageXOffset || docElem.scrollLeft || body.scrollLeft;
      var clientTop = docElem.clientTop || body.clientTop || 0;
      var clientLeft = docElem.clientLeft || body.clientLeft || 0;
      top = box.top + scrollTop - clientTop;
      left = box.left + scrollLeft - clientLeft;

      right = document.body.offsetWidth - box.right;
      bottom = document.body.offsetHeight - box.bottom;
    } else { //fallback to naive approach
      while (elem) {
        top = top + parseInt(elem.offsetTop, 10);
        left = left + parseInt(elem.offsetLeft, 10);
        elem = elem.offsetParent;
      }

      right = document.body.offsetWidth - elem.offsetWidth - left;
      bottom = document.body.offsetHeight - elem.offsetHeight - top;
    }
    return { y: Math.round(top), x: Math.round(left), width: elem.offsetWidth, height: elem.offsetHeight, right: Math.round(right), bottom: Math.round(bottom) };
  }

  isVisible(node) {
    var display: any = false,
      visibility: any = false;
    if (window.getComputedStyle) {
      var style = window.getComputedStyle(node, null);
      display = style["display"];
      visibility = style["visibility"];
    } else if (node.currentStyle) {
      display = node.currentStyle["display"];
      visibility = node.currentStyle["visibility"];
    }
    return (display != "none" && visibility != "hidden");
  }

  hasNonNegativeTabIndex(node) {
    return !isNaN(node.getAttribute("tabindex")) && (node.getAttribute("tabindex") * 1 >= 0);
  }

  hasHref(node) {
    var canHaveHref = { "a": true, "area": true };
    if (canHaveHref[node.nodeName.loLowerCase()]) {
      return !!node.getAttribute("href");
    }
    return true;
  }

  isEnabled(node) {
    var canDisable = { "input": true, "select": true, "textarea": true, "button": true, "object": true };
    if (canDisable[node.nodeName.toLowerCase()]) {
      return !node.hasAttribute("disabled");
    }

    return true;
  }

  getFocusableNodes(root) {
    var nodes = root.querySelectorAll([
      "a[href]",
      "area[href]",
      "input",
      "select",
      "textarea",
      "button",
      "iframe",
      "object",
      "embed",
      "[tabindex]",
      "[contenteditable]"
    ].join(", "));

    var nodesArray = Array.prototype.slice.call(nodes, 0);
    for (var i = 0; i < nodesArray.length; i++) {
      var node = nodesArray[i];
      var isValid = (this.hasNonNegativeTabIndex(node) || this.isEnabled(node) || this.hasHref(node)) && this.isVisible(node);
      if (!isValid) {
        nodesArray.splice(i, 1);
        i--;
      }
    }
    return nodesArray;
  }

  getScrollSize() {
    var div = document.createElement("div");
    div.style.cssText = "visibility:hidden;position:absolute;left:-1000px;width:100px;padding:0px;margin:0px;height:110px;min-height:100px;overflow-y:scroll;";

    document.body.appendChild(div);
    var width = div.offsetWidth - div.clientWidth;
    document.body.removeChild(div);

    return width;
  }

  getClassName(node) {
    if (!node) return "";

    var className = node.className || "";
    if (className.baseVal) //'className' exist but not a string - IE svg element in DOM
      className = className.baseVal;

    if (!className.indexOf)
      className = "";

    return this._trimString(className);
  }

  addClassName(node, className) {
    if (className && node.className.indexOf(className) === -1) {
      node.className += " " + className;
    }
  }

  removeClassName(node, name) {
    name = name.split(" ");
    for (var i = 0; i < name.length; i++) {
      var regEx = new RegExp("\\s?\\b" + name[i] + "\\b(?![-_.])", "");
      node.className = node.className.replace(regEx, "");
    }
  }

  hasClass(element, className) {
    if ('classList' in element) {
      return element.classList.contains(className);
    } else {
      return new RegExp("\\b" + className + "\\b").test(element.className);
    }
  }

  toNode(node) {
    if (typeof node === "string") {
      return (document.getElementById(node) || document.querySelector(node) || document.body);
    }
    return node || document.body;
  }

  _slave = document.createElement("div");
  insert(node, newone) {
    this._slave.innerHTML = newone;
    var child = this._slave.firstChild;
    node.appendChild(child);
    return child;
  }

  remove(node) {
    if (node && node.parentNode) {
      node.parentNode.removeChild(node);
    }
  }

  getChildren(node, css) {
    var ch = node.childNodes;
    var len = ch.length;
    var out = [];
    for (var i = 0; i < len; i++) {
      var obj = ch[i];
      if (obj.className && obj.className.indexOf(css) !== -1) {
        out.push(obj);
      }
    }
    return out;
  }

  getTargetNode(e) {
    var trg;
    if (e.tagName)
      trg = e;
    else {
      e = e || window.event;
      trg = e.target || e.srcElement;
    }
    return trg;
  }

  locateAttribute(e, attribute) {
    if (!attribute) return;

    var trg = this.getTargetNode(e);

    while (trg) {
      if (trg.getAttribute) {	//text nodes has not getAttribute
        var test = trg.getAttribute(attribute);
        if (test) return trg;
      }
      trg = trg.parentNode;
    }
    return null;
  }

  _trimString(str) {
    var func = String.prototype.trim || function () { return this.replace(/^\s+|\s+$/g, ""); };
    return func.apply(str);
  }

  locateClassName(e, classname, strict?) {
    var trg = this.getTargetNode(e);
    var css = "";

    if (strict === undefined)
      strict = true;

    while (trg) {
      css = this.getClassName(trg);
      if (css) {
        var ind = css.indexOf(classname);
        if (ind >= 0) {
          if (!strict)
            return trg;

          //check that we have exact match
          var left = (ind === 0) || (!this._trimString(css.charAt(ind - 1)));
          var right = ((ind + classname.length >= css.length)) || (!this._trimString(css.charAt(ind + classname.length)));

          if (left && right)
            return trg;
        }
      }
      trg = trg.parentNode;
    }
    return null;
  }

  /*
  event position relatively to DOM element
   */
  getRelativeEventPosition(ev, node) {
    var d = document.documentElement;
    var box = this.elementPosition(node);

    return {
      x: ev.clientX + d.scrollLeft - d.clientLeft - box.x + node.scrollLeft,
      y: ev.clientY + d.scrollTop - d.clientTop - box.y + node.scrollTop
    };
  }

  isChildOf(child, parent) {
    if (!child || !parent) {
      return false;
    }

    while (child && child != parent) {
      child = child.parentNode;
    }

    return child === parent;
  }

  closest(element, selector) {
    if (element.closest) {
      return element.closest(selector);
    } else if (element.matches || element.msMatchesSelector || element.webkitMatchesSelector) {
      var el = element;
      if (!document.documentElement.contains(el)) return null;
      do {
        var method = el.matches || el.msMatchesSelector || el.webkitMatchesSelector;

        if (method.call(el, selector)) return el;
        el = el.parentElement || el.parentNode;
      } while (el !== null && el.nodeType === 1);
      return null;
    } else {
      // eslint-disable-next-line no-console
      console.error("Your browser is not supported");
      return null;
    }
  }

  // return {
  //   getNodePosition: elementPosition,
  //   getFocusableNodes: getFocusableNodes,
  //   getScrollSize: getScrollSize,
  //   getClassName: getClassName,
  //   addClassName: addClassName,
  //   removeClassName: removeClassName,
  //   insertNode: insert,
  //   removeNode: remove,
  //   getChildNodes: getChildren,
  //   toNode: toNode,
  //   locateClassName: locateClassName,
  //   locateAttribute: locateAttribute,
  //   getTargetNode: getTargetNode,
  //   getRelativeEventPosition: getRelativeEventPosition,
  //   isChildOf: isChildOf,
  //   hasClass: hasClass,
  //   closest: closest
  // };

  /***/

  env = {
    isIE: (navigator.userAgent.indexOf("MSIE") >= 0 || navigator.userAgent.indexOf("Trident") >= 0),
    // isIE6: (!this.window.XMLHttpRequest && navigator.userAgent.indexOf("MSIE") >= 0),
    isIE7: (navigator.userAgent.indexOf("MSIE 7.0") >= 0 && navigator.userAgent.indexOf("Trident") < 0),
    isIE8: (navigator.userAgent.indexOf("MSIE 8.0") >= 0 && navigator.userAgent.indexOf("Trident") >= 0),
    isOpera: (navigator.userAgent.indexOf("Opera") >= 0),
    isChrome: (navigator.userAgent.indexOf("Chrome") >= 0),
    isKHTML: (navigator.userAgent.indexOf("Safari") >= 0 || navigator.userAgent.indexOf("Konqueror") >= 0),
    isFF: (navigator.userAgent.indexOf("Firefox") >= 0),
    isIPad: (navigator.userAgent.search(/iPad/gi) >= 0),
    isEdge: (navigator.userAgent.indexOf("Edge") != -1)
  }

  eventable() {

    var createEventStorage = function (obj) {
      var dhx_catch = [];
      var z: any = function () {
        var res = true;
        for (var i = 0; i < dhx_catch.length; i++) {
          if (dhx_catch[i]) {
            var zr = dhx_catch[i].apply(obj, arguments);
            res = res && zr;
          }
        }
        return res;
      };
      z.addEvent = function (ev) {
        if (typeof (ev) == "function")
          return dhx_catch.push(ev) - 1;
        return false;
      };
      z.removeEvent = function (id) {
        dhx_catch[id] = null;
      };
      return z;
    };

    function makeEventable(obj) {

      obj.attachEvent = function (name, catcher, callObj) {
        name = 'ev_' + name.toLowerCase();
        if (!this.eventHost[name])
          this.eventHost[name] = createEventStorage(callObj || this);

        return (name + ':' + this.eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
      };
      obj.attachAll = function (callback, callObj) {
        this.attachEvent('listen_all', callback, callObj);
      };

      obj.callEvent = function (name, arg0, callObj) {
        if (this.eventHost._silent_mode) return true;

        var handlerName = 'ev_' + name.toLowerCase();

        if (this.eventHost['ev_listen_all']) {
          this.eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
        }

        if (this.eventHost[handlerName])
          return this.eventHost[handlerName].apply(callObj || this, arg0);
        return true;
      }

      obj.checkEvent = function (name) {
        return (!!this.eventHost['ev_' + name.toLowerCase()]);
      };
      obj.detachEvent = function (id) {
        if (id) {
          var list = id.split(':');//get EventName and ID
          var eventName = list[0];
          var eventId = list[1];

          if (this.eventHost[eventName]) {
            this.eventHost[eventName].removeEvent(eventId); //remove event
          }
        }
      };
      obj.detachAllEvents = function () {
        for (var name in this.eventHost) {
          if (name.indexOf("ev_") === 0)
            delete this.eventHost[name];
        }
      };

    }

    return makeEventable;

    /***/
  }

  createEventStorage(obj) {
    var dhx_catch = [];
    var z: any = function () {
      var res = true;
      for (var i = 0; i < dhx_catch.length; i++) {
        if (dhx_catch[i]) {
          var zr = dhx_catch[i].apply(obj, arguments);
          res = res && zr;
        }
      }
      return res;
    };
    z.addEvent = function (ev) {
      if (typeof (ev) == "function")
        return dhx_catch.push(ev) - 1;
      return false;
    };
    z.removeEvent = function (id) {
      dhx_catch[id] = null;
    };
    return z;
  }

  attachEvent(name, catcher, callObj) {
    name = 'ev_' + name.toLowerCase();
    if (!this.eventHost[name])
      this.eventHost[name] = this.createEventStorage(callObj || this);

    return (name + ':' + this.eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
  };

  attachAll(callback, callObj) {
    this.attachEvent('listen_all', callback, callObj);
  }

  checkEvent(name) {
    return (!!this.eventHost['ev_' + name.toLowerCase()]);
  }

  detachEvent(id) {
    if (id) {
      var list = id.split(':');//get EventName and ID
      var eventName = list[0];
      var eventId = list[1];

      if (this.eventHost[eventName]) {
        this.eventHost[eventName].removeEvent(eventId); //remove event
      }
    }
  }

  detachAllEvents() {
    for (var name in this.eventHost) {
      if (name.indexOf("ev_") === 0)
        delete this.eventHost[name];
    }
  }

  callEvent(name, arg0, callObj) {
    if (this.eventHost._silent_mode) return true;

    var handlerName = 'ev_' + name.toLowerCase();

    if (this.eventHost['ev_listen_all']) {
      this.eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
    }

    if (this.eventHost[handlerName])
      return this.eventHost[handlerName].apply(callObj || this, arg0);
    return true;
  }

  extends() {

    return function (d, b) {
      for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };

    /***/
  }


  getHtmlSelect(options, attributes, value?) {
    var innerHTML = "";
    var _this = this;

    options = options || [];

    this.forEach(options, function (entry) {
      var _attributes = [{ key: "value", value: entry.key }];

      if (value == entry.key) {
        _attributes[_attributes.length] = { key: "selected", value: "selected" };
      }
      if (entry.attributes) {
        _attributes = _attributes.concat(entry.attributes);
      }
      innerHTML += _this.getHtmlOption({ innerHTML: entry.label }, _attributes);
    });

    return this._getHtmlContainer("select", { innerHTML: innerHTML }, attributes);
  }
  getHtmlOption(options, attributes) { return this._getHtmlContainer("option", options, attributes); }
  getHtmlButton(options, attributes) { return this._getHtmlContainer("button", options, attributes); }
  getHtmlDiv(options, attributes) { return this._getHtmlContainer("div", options, attributes); }
  getHtmlLabel(options, attributes) { return this._getHtmlContainer("label", options, attributes); }
  getHtmlInput(attributes) {
    return "<input" + this._getHtmlAttributes(attributes || []) + ">";
  }

  _getHtmlContainer(tag, options, attributes) {
    var html;

    options = options || [];

    html = "<" + tag + this._getHtmlAttributes(attributes || []) + ">" + (options.innerHTML || "") + "</" + tag + ">";
    return html;

  }

  _getHtmlAttributes(attributes) {
    var html = "";

    this.forEach(attributes, function (entry) {
      html += " " + entry.key + "='" + entry.value + "'";
    });
    return html;
  }

  promise() {

    return Promise;

    /***/
  }


  copyLinkIdsArray(gantt, linkIds, targetHash) {
    for (var i = 0; i < linkIds.length; i++) {
      if (gantt.isLinkExists(linkIds[i])) {
        targetHash[linkIds[i]] = gantt.getLink(linkIds[i]);
      }
    }
  }

  copyLinkIds(gantt, task, targetHash) {
    this.copyLinkIdsArray(gantt, task.$source, targetHash);
    this.copyLinkIdsArray(gantt, task.$target, targetHash);
  }

  getSubtreeLinks(gantt, rootId) {
    var res = {};

    if (gantt.isTaskExists(rootId)) {
      this.copyLinkIds(gantt, gantt.getTask(rootId), res);
    }

    gantt.eachTask(function (child) {
      this.copyLinkIds(gantt, child, res);
    }, rootId);

    return res;
  }

  getSubtreeTasks(gantt, rootId) {
    var res = {};

    gantt.eachTask(function (child) {
      res[child.id] = child;
    }, rootId);

    return res;
  }

  // return {
  //   getSubtreeLinks: getSubtreeLinks,
  //   getSubtreeTasks: getSubtreeTasks
  // };

  /***/



  checkTimeout(host, updPerSecond) {
    if (!updPerSecond)
      return true;

    if (host._on_timeout)
      return false;

    var timeout = Math.ceil(1000 / updPerSecond);
    if (timeout < 2) return true;

    setTimeout(function () {
      delete host._on_timeout;
    }, timeout);

    host._on_timeout = true;
    return true;
  }

  copy(object) {
    var i, result; // iterator, types array, result

    if (object && typeof object == "object") {

      switch (true) {
        case (this.isDate(object)):
          result = new Date(object);
          break;
        case (this.isArray(object)):
          result = new Array(object.length);
          for (i = 0; i < object.length; i++) {
            result[i] = this.copy(object[i]);
          }
          break;
        case (this.isStringObject(object)):
          result = new String(object);
          break;
        case (this.isNumberObject(object)):
          result = new Number(object);
          break;
        case (this.isBooleanObject(object)):
          result = new Boolean(object);
          break;
        default:
          result = {};
          for (i in object) {
            if (Object.prototype.hasOwnProperty.apply(object, [i]))
              result[i] = this.copy(object[i]);
          }
          break;
      }
    }
    return result || object;
  }

  mixin(target, source, force?) {
    for (var f in source)
      if (((target[f] === undefined) || force)) target[f] = source[f];
    return target;
  }

  defined(obj) {
    return typeof (obj) != "undefined";
  }

  uid() {
    var seed;

    if (!seed)
      seed = (new Date()).valueOf();

    seed++;
    return seed;
  }

  //creates function with specified "this" pointer
  bind(functor, object) {
    if (functor.bind)
      return functor.bind(object);
    else
      return function () { return functor.apply(object, arguments); };
  }

  event(el, event, handler, capture) {
    if (el.addEventListener)
      el.addEventListener(event, handler, capture === undefined ? false : capture);

    else if (el.attachEvent)
      el.attachEvent("on" + event, handler);
  }

  eventRemove(el, event, handler, capture) {
    if (el.removeEventListener)
      el.removeEventListener(event, handler, capture === undefined ? false : capture);

    else if (el.detachEvent)
      el.detachEvent("on" + event, handler);
  }

}

@Injectable()
export class EventHost {
  _connected = [];
  _silent_mode;

  constructor() {
    this._silent_mode = false;
  }

  _silentStart() {
    this._silent_mode = true;
  }

  _silentEnd() {
    this._silent_mode = false;
  }
}

