import { TestBed } from '@angular/core/testing';

import { PublishHelpersService } from './publish-helpers.service';

describe('PublishHelpersService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PublishHelpersService = TestBed.get(PublishHelpersService);
    expect(service).toBeTruthy();
  });
});
