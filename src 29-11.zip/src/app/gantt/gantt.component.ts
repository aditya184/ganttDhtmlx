import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import 'dhtmlx-gantt';

// import '../ganttChart/codebase/dhtmlxgantt';
// import { Core, GanttObjectService } from '../services/gantt-object.service';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css']
})
export class GanttComponent implements OnInit {
  constructor(/*private gantt: Core*/) { }
  @ViewChild('gantt_here') ganttContainer: ElementRef;


  ngOnInit() {

    const zoomConfig = {
      levels: [
        {
          name: 'day',
          scale_height: 27,
          min_column_width: 80,
          scales: [
            { unit: 'day', step: 1, format: '%d %M' }
          ]
        },
        {
          name: 'week',
          scale_height: 50,
          min_column_width: 50,
          scales: [
            {
              unit: 'week', step: 1, format(date) {
                const dateToStr = gantt.date.date_to_str('%d %M');
                const endDate = gantt.date.add(date, -6, 'day');
                const weekNum = gantt.date.date_to_str('%W')(date);
                return '#' + weekNum + ', ' + dateToStr(date) + ' - ' + dateToStr(endDate);
              }
            },
            { unit: 'day', step: 1, format: '%j %D' }
          ]
        },
        {
          name: 'month',
          scale_height: 50,
          min_column_width: 120,
          scales: [
            { unit: 'month', format: '%F, %Y' },
            { unit: 'week', format: 'Week #%W' }
          ]
        },
        {
          name: 'quarter',
          height: 50,
          min_column_width: 90,
          scales: [
            { unit: 'month', step: 1, format: '%M' },
            {
              unit: 'quarter', step: 1, format(date) {
                const dateToStr = gantt.date.date_to_str('%M');
                const endDate = gantt.date.add(gantt.date.add(date, 3, 'month'), -1, 'day');
                return dateToStr(date) + ' - ' + dateToStr(endDate);
              }
            }
          ]
        },
        {
          name: 'year',
          scale_height: 50,
          min_column_width: 30,
          scales: [
            { unit: 'year', step: 1, format: '%Y' }
          ]
        }
      ]
    };

    gantt.ext.zoom.init(zoomConfig);

    console.log(new Date().toISOString())
    var tasks = {
      // data:[
      //     {id:1, text:"Project #1",    type:gantt.config.types.project,    open:true},   
      //     {id:2, text:"Task #1",       start_date:"12-04-2013", duration:3, parent:1},
      //     {id:3, text:"Alpha release", type:gantt.config.types.milestone,   parent:1, 
      //         start_date:"14-04-2013"},                                                
      //     {id:4, text:"Task #2",       start_date:"17-04-2013", duration:3, parent:1}],
      // links:[]
      "data": [
        { "id": "10", "text": "Project #1", "start_date": new Date()
        , "duration": 3, "order": 10, "progress": 0.4, "type": "project", "open": true },
        { "id": "1", "text": "Task #1", "start_date": new Date(), "duration": 2, "order": 10, "progress": 0.6, "parent": "10" },
        { "id": "2", "text": "Task #2", "start_date": new Date(), "duration": 2, "order": 20, "progress": 0.6, "parent": "10" },
        { "id": "20", "text": "Project #2", "start_date": new Date(), "duration": 3, "order": 10, "progress": 0.4, "type": "project", "open": true },
        { "id": "3", "text": "Task #3", "start_date": new Date(), "duration": 2, "order": 10, "progress": 0.6, "parent": "20" },
        { "id": "4", "text": "Task #4", "start_date": new Date(), "duration": 2, "order": 20, "progress": 0.6, "parent": "20" }
      ],
      "links": [
        { "id": 1, "source": 1, "target": 2, "type": "1" },
        { "id": 2, "source": 2, "target": 3, "type": "0" },
        { "id": 3, "source": 3, "target": 4, "type": "0" },
        { "id": 4, "source": 2, "target": 5, "type": "2" }
      ]
    };


    gantt.addLinkLayer(function (link) {
      var node: any = gantt.getLinkNode(link.id);
      if (node) {
        var el = document.createElement('div');
        el.className = 'link_layer';
        el.style.left = node.childNodes[2].offsetLeft + 'px'
        el.style.width = 25 + 'px'
        el.style.top = node.childNodes[2].offsetTop + 'px'
        el.style.height = 25 + 'px'
        return el;
      }
      return false;
    });
    gantt.init(this.ganttContainer.nativeElement);
    gantt.parse(tasks);
  }



}



