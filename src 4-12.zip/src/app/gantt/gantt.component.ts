import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation, HostListener } from '@angular/core';
import 'dhtmlx-gantt';

// import '../ganttChart/codebase/dhtmlxgantt';


@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css']
})
export class GanttComponent implements OnInit {
  constructor() { }
  @ViewChild('gantt_here') ganttContainer: ElementRef;

  @HostListener('mousewheel', ['$event'])
  onMousewheel(event) {
    if (event.wheelDelta > 0) {
      gantt.ext.zoom.zoomIn();
    } else {
      gantt.ext.zoom.zoomOut();
    }
  }

  scales = [];

  ngOnInit() {
    this.scales = [{ name: 'Minute Scale', value: 'minute' },
    { name: 'Day Scale', value: 'day' },
    { name: 'Week Scale', value: 'week' },
    { name: 'Month Scale', value: 'month' },
    { name: 'Quarter Scale', value: 'quarter' },
    { name: 'Year Scale', value: 'year' }]
    gantt.config.duration_unit = "minute";

    var zoomConfig = {
      levels: [
        {
          name: "minute",
          scale_height: 75,
          min_column_width: 60,
          // scale: [],
          scales: [
            { unit: "hour", step: 1, format: "%g %a" },
            { unit: "day", step: 1, format: "%j %F, %l" },
            { unit: "minute", step: 15, format: "%i" }
          ],
          // date_scale: "%j %F, %l",
          duration_unit: "minute",
          duration_step: 60,
        },
        {
          name: "day",
          scale_height: 27,
          min_column_width: 80,
          scales: [
            { unit: "day", step: 1, format: "%d %M" }
          ]
        },
        {
          name: "week",
          scale_height: 50,
          min_column_width: 50,
          scales: [
            {
              unit: "week", step: 1, format: function (date) {
                var dateToStr = gantt.date.date_to_str("%d %M");
                var endDate = gantt.date.add(date, -6, "day");
                var weekNum = gantt.date.date_to_str("%W")(date);
                return "#" + weekNum + ", " + dateToStr(date) + " - " + dateToStr(endDate);
              }
            },
            { unit: "day", step: 1, format: "%j %D" }
          ]
        },
        {
          name: "month",
          scale_height: 50,
          min_column_width: 120,
          scales: [
            { unit: "month", format: "%F, %Y" },
            { unit: "week", format: "Week #%W" }
          ]
        },
        {
          name: "quarter",
          height: 50,
          min_column_width: 90,
          scales: [
            { unit: "month", step: 1, format: "%M" },
            {
              unit: "quarter", step: 1, format: function (date) {
                var dateToStr = gantt.date.date_to_str("%M");
                var endDate = gantt.date.add(gantt.date.add(date, 3, "month"), -1, "day");
                return dateToStr(date) + " - " + dateToStr(endDate);
              }
            }
          ]
        },
        {
          name: "year",
          scale_height: 50,
          min_column_width: 30,
          scales: [
            { unit: "year", step: 1, format: "%Y" }
          ]
        }
      ]
    };


    gantt.ext.zoom.init(zoomConfig);

    gantt.init(this.ganttContainer.nativeElement);

    // function setScaleConfig(value) {
    //   switch (value) {
    //     case "minute":
    //       gantt.config.min_column_width = 20;
    //       gantt.config.duration_unit = "minute";
    //       gantt.config.duration_step = 60;
    //       gantt.config.scale_height = 75;

    //       gantt.config.scales = [
    //         { unit: "hour", step: 1, format: "%g %a" },
    //         { unit: "day", step: 1, format: "%j %F, %l" },
    //         { unit: "minute", step: 15, format: "%i" }
    //       ];
    //       break;
    //     case "day":
    //       gantt.config.scale_unit = "day";
    //       gantt.config.step = 1;
    //       gantt.config.date_scale = "%d %M";
    //       gantt.config.subscales = [];
    //       gantt.config.scale_height = 27;
    //       gantt.templates.date_scale = null;
    //       break;
    //     case "week":
    //       var weekScaleTemplate = function (date) {
    //         var dateToStr = gantt.date.date_to_str("%d %M");
    //         var startDate = gantt.date.week_start(new Date(date));
    //         var endDate = gantt.date.add(gantt.date.add(startDate, 1, "week"), -1, "day");
    //         return dateToStr(startDate) + " - " + dateToStr(endDate);
    //       };

    //       gantt.config.scale_unit = "week";
    //       gantt.config.step = 1;
    //       gantt.templates.date_scale = weekScaleTemplate;
    //       gantt.config.subscales = [
    //         { unit: "day", step: 1, date: "%D" }
    //       ];
    //       gantt.config.scale_height = 50;
    //       break;
    //     case "month":
    //       gantt.config.scale_unit = "month";
    //       gantt.config.date_scale = "%F, %Y";
    //       gantt.config.subscales = [
    //         { unit: "day", step: 1, date: "%j, %D" }
    //       ];
    //       gantt.config.scale_height = 50;
    //       gantt.templates.date_scale = null;
    //       break;
    //     case "quarter":
    //         gantt.config.scale_unit = "month";
    //         gantt.config.step = 1;
    //         gantt.config.date_scale = "%M";

    //         gantt.config.scale_height = 50;
    //         gantt.templates.date_scale = null;

    //         gantt.config.subscales = [
    //           {
    //             unit: "quarter", step: 1, date:"Q" ,
    //             // template: function (date) {
    //             //   var dateToStr = gantt.date.date_to_str("%M");
    //             //   var endDate = gantt.date.add(gantt.date.add(date, 3, "month"), -1, "day");
    //             //   return dateToStr(date) + " - " + dateToStr(endDate);
    //             // }
    //           }
    //         ];
    //       break;
    //     case "year":
    //       gantt.config.scale_unit = "year";
    //       gantt.config.step = 1;
    //       gantt.config.date_scale = "%Y";
    //       gantt.config.min_column_width = 50;

    //       gantt.config.scale_height = 90;
    //       gantt.templates.date_scale = null;


    //       gantt.config.subscales = [
    //         { unit: "month", step: 1, date: "%M" }
    //       ];
    //       break;
    //   }
    //   gantt.render();
    // }

    gantt.config.columns = [
      { name: "text", tree: true, width: "*", resize: true },
      { name: "start_date", align: "center", resize: true },
      { name: "end_date", align: "center" },
    ]


    var tasks = {
      "data": [
        {
          "id": "10", "text": "Project #1", "start_date": new Date("2019-11-27T07:00:11.592Z"), "end_date": new Date("2019-11-29T12:00:11.592Z")
          , "duration": 3, "order": 10, "progress": 0.4, "type": "project", "open": true, "user_id": 5
        },
        { "id": "1", "text": "Task #1", "start_date": new Date("2019-11-27T07:00:11.592Z"), "end_date": new Date("2019-11-28T12:00:11.592Z"), "duration": 2, "order": 10, "progress": 0.6, "parent": "10", "user_id": 5 },
        { "id": "2", "text": "Task #2", "start_date": new Date("2019-11-28T07:00:11.592Z"), "end_date": new Date("2019-11-29T12:00:11.592Z"), "duration": 2, "order": 20, "progress": 0.6, "parent": "10", "user_id": 5 },
        { "id": "20", "text": "Project #2", "start_date": new Date("2019-12-03T09:00:11.592Z"), "end_date": new Date("2019-12-06T08:00:11.592Z"), "duration": 3, "order": 10, "progress": 0.4, "type": "project", "open": true },
        { "id": "3", "text": "Task #3", "start_date": new Date("2019-12-03T08:00:11.592Z"), "end_date": new Date("2019-12-05T10:00:11.592Z"), "duration": 2, "order": 10, "progress": 0.6, "parent": "20" },
        { "id": "4", "text": "Task #4", "start_date": new Date("2019-12-05T11:00:11.592Z"), "end_date": new Date("2019-12-06T08:00:11.592Z"), "duration": 2, "order": 20, "progress": 0.6, "parent": "20" }
      ],
      "links": [
        { "id": 1, "source": 1, "target": 2, "type": "1" },
        { "id": 2, "source": 2, "target": 3, "type": "0" },
        { "id": 3, "source": 3, "target": 4, "type": "0" },
        { "id": 4, "source": 2, "target": 5, "type": "2" }
      ]
    };


    gantt.addLinkLayer(function (link) {
      var node: any = gantt.getLinkNode(link.id);
      if (node) {
        var el = document.createElement('div');
        el.className = 'link_layer';
        el.style.left = node.childNodes[2].offsetLeft + 'px';
        el.style.width = 25 + 'px';
        el.style.top = node.childNodes[2].offsetTop + 'px';
        el.style.height = 25 + 'px';
        return el;
      }
      return false;
    });

    this.setScaleConfig('minute');

    var func = function (e) {
      e = e || window.event;
      var el = e.target || e.srcElement;
      var value = el.value;
      this.setScaleConfig(value);
      gantt.render();
    };

    var els = document.getElementsByName("scale");
    for (var i = 0; i < els.length; i++) {
      els[i].onclick = func;
    }

    gantt.serverList("staff", [
      { key: 1, label: "John", backgroundColor: "#03A9F4", textColor: "#FFF" },
      { key: 2, label: "Mike", backgroundColor: "#f57730", textColor: "#FFF" },
      { key: 3, label: "Anna", backgroundColor: "#e157de", textColor: "#FFF" },
      { key: 4, label: "Bill", backgroundColor: "#78909C", textColor: "#FFF" },
      { key: 7, label: "Floe", backgroundColor: "#8D6E63", textColor: "#FFF" }
    ]);

    gantt.serverList("priority", [
      { key: 1, label: "High" },
      { key: 2, label: "Normal" },
      { key: 3, label: "Low" }
    ]);

    // end test data
    gantt.config.grid_width = 420;
    gantt.config.grid_resize = true;
    gantt.config.open_tree_initially = true;

    var labels: any = gantt.locale.labels;
    labels.column_priority = labels.section_priority = "Priority";
    labels.column_owner = labels.section_owner = "Owner";

    function byId(list, id) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].key == id)
          return list[i].label || "";
      }
      return "";
    }

    // gantt.config.columns = [
    //   {name: "owner", width: 80, align: "center", template: function (item) {
    //       return byId(gantt.serverList('staff'), item.owner_id)}},
    //   {name: "text", label: "Task name", tree: true, width: '*'},
    //   {name: "priority", width: 80, align: "center", template: function (item) {
    //       return byId(gantt.serverList('priority'), item.priority)}},
    //   {name: "add", width: 40}
    // ];

    gantt.config.lightbox.sections = [
      { name: "description", height: 38, map_to: "text", type: "textarea", focus: true },
      { name: "priority", height: 22, map_to: "priority", type: "select", options: gantt.serverList("priority") },
      { name: "owner", height: 22, map_to: "owner_id", type: "select", options: gantt.serverList("staff") },
      { name: "time", type: "duration", map_to: "auto" }
    ];

    this.zoomIn();
    gantt.parse(tasks);

  }

  // onChange(value) {
  //   this.setScaleConfig(value);
  // }

  setScaleConfig(value) {
    switch (value) {
      case "minute":
        gantt.config.min_column_width = 60;
        gantt.config.duration_unit = "minute";
        gantt.config.duration_step = 60;
        gantt.config.scale_height = 75;

        gantt.config.scales = [
          { unit: "hour", step: 1, format: "%g %a" },
          { unit: "day", step: 1, format: "%j %F, %l" },
          { unit: "minute", step: 15, format: "%i" }
        ];
        gantt.config.subscales = [];
        gantt.templates.date_scale = null;
        break;
      case "day":
        gantt.config.scale_unit = "day";
        gantt.config.step = 1;
        gantt.config.date_scale = "%d %M";
        gantt.config.subscales = [];
        gantt.config.scale_height = 27;
        gantt.templates.date_scale = null;
        break;
      case "week":
        var weekScaleTemplate = function (date) {
          var dateToStr = gantt.date.date_to_str("%d %M");
          var startDate = gantt.date.week_start(new Date(date));
          var endDate = gantt.date.add(gantt.date.add(startDate, 1, "week"), -1, "day");
          return dateToStr(startDate) + " - " + dateToStr(endDate);
        };

        gantt.config.scale_unit = "week";
        gantt.config.step = 1;
        gantt.templates.date_scale = weekScaleTemplate;
        gantt.config.subscales = [
          { unit: "day", step: 1, date: "%D" }
        ];
        gantt.config.scale_height = 50;
        break;
      case "month":
        gantt.config.scale_unit = "month";
        gantt.config.date_scale = "%F, %Y";
        gantt.config.subscales = [
          { unit: "day", step: 1, date: "%j, %D" }
        ];
        gantt.config.scale_height = 50;
        gantt.templates.date_scale = null;
        break;
      case "quarter":
        gantt.config.scale_unit = "month";
        gantt.config.step = 1;
        gantt.config.date_scale = "%M";

        gantt.config.scale_height = 50;
        gantt.templates.date_scale = null;

        gantt.config.subscales = [
          {
            unit: "quarter", step: 1, date: "Q",
            // template: function (date) {
            //   var dateToStr = gantt.date.date_to_str("%M");
            //   var endDate = gantt.date.add(gantt.date.add(date, 3, "month"), -1, "day");
            //   return dateToStr(date) + " - " + dateToStr(endDate);
            // }
          }
        ];
        break;
      case "year":
        gantt.config.scale_unit = "year";
        gantt.config.step = 1;
        gantt.config.date_scale = "%Y";
        gantt.config.min_column_width = 50;

        gantt.config.scale_height = 90;
        gantt.templates.date_scale = null;


        gantt.config.subscales = [
          { unit: "month", step: 1, date: "%M" }
        ];
        break;
    }
    gantt.render();
  }


  zoomIn() {
    gantt.ext.zoom.zoomIn();
  }

  zoomOut() {
    gantt.ext.zoom.zoomOut();
  }


}



