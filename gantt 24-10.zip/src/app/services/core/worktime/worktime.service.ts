import { Injectable } from '@angular/core';
import { FacadesService } from '../facades/facades.service';
import { UtilsService } from '../../utils/utils.service';
import { StrategyService , CalendarWorkTimeStrategy, CalendarDisabledTimeStrategy} from './strategy/strategy.service';

@Injectable({
  providedIn: 'root'
})
export class WorktimeService {

  constructor(private facadeService: FacadesService, private utilsService: UtilsService) { }

  // workTime() {

  workTime(gantt) {
    // var CalendarManager = new CalendarManager(gantt),
      // TimeCalculator = this.timeCalculator(),
      // tslint:disable-next-line: no-use-before-declare
      var manager = new CalendarManager(gantt);
     var worktimeFacadeFactory = this.facadeService.worktimeCalendars(),
      utils = this.utilsService;
      var timeCalculator = new TimeCalculator(manager);
    var facade = worktimeFacadeFactory.create(manager, timeCalculator);
    this.utilsService.mixin(gantt, facade);
  }


  /***/
  // }
}
class IsWorkTimeArgument {
  date: any;
  unit: any;
  task: any;
  id: any;
  calendar: any;
constructor(date, unit, task, id, calendar) {
  this.date = date;
  this.unit = unit;
  this.task = task;
  this.id = id;
  this.calendar = calendar;
}
}

class ClosestWorkTimeArgument {
  date: any;
  unit: any;
  task: any;
  id: any;
  calendar: any;
  dir: any;
  constructor(date, dir?, unit?, task?, id?, calendar?) {
    this.date = date;
    this.dir = dir;
    this.unit = unit;
    this.task = task;
    this.id = id;
    this.calendar = calendar;
  }
}

class CalculateEndDateArgument {
  start_date: any;
  duration: any;
  unit: any;
  step: any;
  task: any;
  id: any;
  calendar: any;
  constructor(start_date, duration, unit, step, task, id, calendar) {
    this.start_date = start_date;
    this.duration = duration;
    this.unit = unit;
    this.step = step;
    this.task = task;
    this.id = id;
    this.calendar = calendar;
  }
}

class GetDurationArgument {
  start_date: any;
  end_date: any;
  task: any;
  calendar: any;
  unit: any;
  step: any;

  constructor(start, end, task, calendar) {
    this.start_date = start;
    this.end_date = end;
    this.task = task;
    this.calendar = calendar;
    this.unit = null;
    this.step = null;
  }
}

class CalendarArgumentsHelper {

  constructor(private utilService : UtilsService) {  }
    getWorkHoursArguments() {
      var config = arguments[0];
      if (this.utilService.isDate(config)) {
        config = {
          date: config
        };
      } else {
        config = this.utilService.mixin({}, config);
      }
      return config;
    }

    setWorkTimeArguments() {
      return arguments[0];
    }

    unsetWorkTimeArguments() {
      return arguments[0];
    }

    isWorkTimeArguments() {
      var config = arguments[0];
      if (config instanceof IsWorkTimeArgument) {
        return config;
      }

      var processedConfig;
      if (!config.date) {
        //IsWorkTimeArgument(date, unit, task, id, calendar)
        processedConfig = new IsWorkTimeArgument(arguments[0], arguments[1], arguments[2], null, arguments[3]);
      } else {
        processedConfig = new IsWorkTimeArgument(config.date, config.unit, config.task, null, config.calendar);
      }

      processedConfig.unit = processedConfig.unit || gantt.config.duration_unit;

      return processedConfig;
    }

    getClosestWorkTimeArguments(arg) {
      var config = arguments[0];
      if (config instanceof ClosestWorkTimeArgument)
        return config;

      var processedConfig;
      if (this.utilService.isDate(config)) {
        // processedConfig = ClosestWorkTimeArgument(config);
        processedConfig = new ClosestWorkTimeArgument(config);
      } else {
        processedConfig = new ClosestWorkTimeArgument(
          config.date,
          config.dir,
          config.unit,
          config.task,
          null,//config.id,
          config.calendar
        );
      }

      if (config.id) {
        processedConfig.task = config;
      }
      processedConfig.dir = config.dir || 'any';
      processedConfig.unit = config.unit || gantt.config.duration_unit;

      return processedConfig;
    }

    _getStartEndConfig(param) {
      var argumentType = GetDurationArgument;
      var config;
      if (param instanceof argumentType)
        return param;

      if (this.utilService.isDate(param)) {
        config = new argumentType(arguments[0], arguments[1], arguments[2], arguments[3]);
      } else {
        config = new argumentType(param.start_date, param.end_date, param.task, null);
        if (param.id) {
          config.task = param;
        }
      }

      config.unit = config.unit || gantt.config.duration_unit;
      config.step = config.step || gantt.config.duration_step;
      config.start_date = config.start_date || config.start || config.date;

      return config;
    }

    getDurationArguments(start, end, unit, step) {
      return this._getStartEndConfig.apply(this, arguments);
    }

    hasDurationArguments(start, end, unit, step) {
      return this._getStartEndConfig.apply(this, arguments);
    }

    calculateEndDateArguments(start, duration, unit, step) {
      var config = arguments[0];
      if (config instanceof CalculateEndDateArgument)
        return config;

      var processedConfig;
      //CalculateEndDateArgument(start_date, duration, unit, step, task, id, calendar)
      if (this.utilService.isDate(config)) {
        processedConfig = new CalculateEndDateArgument(
          arguments[0],
          arguments[1],
          arguments[2],
          undefined,
          arguments[3],
          undefined,
          arguments[4]
        );

      } else {
        processedConfig = new CalculateEndDateArgument(
          config.start_date,
          config.duration,
          config.unit,
          config.step,
          config.task,
          null,//config.id,
          config.calendar
        );
      }
      if (config.id) {
        processedConfig.task = config;
      }

      processedConfig.unit = processedConfig.unit || gantt.config.duration_unit;
      processedConfig.step = processedConfig.step || gantt.config.duration_step;

      return processedConfig;
    }
  
}

class CalendarManager {
  _calendars: {}
  $gantt;
  utilsService: UtilsService

  constructor(gantt) {
    this.$gantt = gantt;
    this._calendars = {};
  }

  defaults: {
    global: {
      id: "global",
      worktime: {
        hours: [8, 17],
        days: [0, 1, 1, 1, 1, 1, 0]
      }
    },
    fulltime: {
      id: "fulltime",
      worktime: {
        hours: [0, 24],
        days: [1, 1, 1, 1, 1, 1, 1]
      }
    }
  }

  _getDayHoursForMultiple(calendars, date) {
    var units: any = [],
      tick = true,
      currPos = 0,
      is_work_hour = false,
      start = this.$gantt.date.day_start(new Date(date));
    for (var hour = 0; hour < 24; hour++) {
      is_work_hour = calendars.reduce(function (acc, calendar) {
        return acc && calendar._is_work_hour(start);
      }, true);
      if (is_work_hour) {
        if (tick) {
          units[currPos] = hour;
          units[currPos + 1] = (hour + 1);
          currPos += 2;
        } else {
          units[currPos - 1] += 1;
        }
        tick = false;
      } else if (!tick) {
        tick = true;
      }
      start = this.$gantt.date.add(start, 1, "hour");
    }
    if (!units.length)
      units = false;
    return units;
  }

  mergeCalendars() {
    var newCalendar = this.createCalendar(),
      day,
      units = [];
    var calendars = Array.prototype.slice.call(arguments, 0);
    newCalendar.worktime.hours = [0, 24];
    newCalendar.worktime.dates = {};
    var start = this.$gantt.date.day_start(new Date(259200000)); // 1970 day=0
    for (day = 0; day < 7; day++) {
      units = this._getDayHoursForMultiple(calendars, start);
      newCalendar.worktime.dates[day] = units;
      start = this.$gantt.date.add(start, 1, "day");
    }
    for (var i = 0; i < calendars.length; i++) {
      for (var value in calendars[i].worktime.dates) if (+value > 10000) {
        units = this._getDayHoursForMultiple(calendars, new Date(+value));
        newCalendar.worktime.dates[value] = units;
      }
    }
    return newCalendar;
  }

  _convertWorktimeSettings(settings) {
    var days = settings.days;
    if (days) {
      settings.dates = settings.dates || {};
      for (var i = 0; i < days.length; i++) {
        settings.dates[i] = days[i];
        if (!(days[i] instanceof Array)) {
          settings.dates[i] = !!days[i];
        }
      }
      delete settings.days;
    }
    return settings;
  }

  createCalendar(parentCalendar?) {
    var settings;

    if (!parentCalendar) {
      parentCalendar = {};
    }

    if (parentCalendar.worktime) {
      settings = this.utilsService.copy(parentCalendar.worktime);
    } else {
      settings = this.utilsService.copy(parentCalendar);
    }

    var defaults = this.utilsService.copy(this.defaults.fulltime.worktime);
    this.utilsService.mixin(settings, defaults);

    var id = this.utilsService.uid();
    var calendar = {
      id: id + "",
      worktime: this._convertWorktimeSettings(settings)
    };

    var apiCore = new CalendarWorkTimeStrategy(this.$gantt, new CalendarArgumentsHelper(this.$gantt));
    this.utilsService.mixin(apiCore, calendar);

    // validate/check if empty calendar
    if (!apiCore._tryChangeCalendarSettings(function () {
    })) {
      return null;
    } else {
      return apiCore;
    }
  }

  getCalendar(id?) {
    id = id || "global";
    this.createDefaultCalendars();
    return this._calendars[id];
  }

  getCalendars() {
    var res = [];
    for (var i in this._calendars) {
      res.push(this.getCalendar(i));
    }
    return res;
  }

  _getOwnCalendar(task) {
    var config = this.$gantt.config;
    if (task[config.calendar_property]) {
      return this.getCalendar(task[config.calendar_property]);
    }

    if (config.resource_calendars) {
      for (var field in config.resource_calendars) {
        var resource = config.resource_calendars[field];
        if (task[field]) {
          var calendarId = resource[task[field]];
          if (calendarId) {
            return this.getCalendar(calendarId);
          }
        }
      }
    }
    return null;
  }

  getTaskCalendar(task) {
    if (!task) {
      return this.getCalendar();
    }

    var calendar = this._getOwnCalendar(task);
    var gantt = this.$gantt;
    if (!calendar && gantt.config.inherit_calendar && gantt.isTaskExists(task.parent)) {
      var stop = false;
      gantt.eachParent(function (parent) {
        if (stop) return;
        if (gantt.isSummaryTask(parent)) {
          calendar = this._getOwnCalendar(parent);
          if (calendar) {
            stop = true;
          }
        }
      }, task.id, this);
    }

    return calendar || this.getCalendar();
  }

  addCalendar(calendar) { // puts new calendar to Global Storage - gantt.calendarManager._calendars {}
    if (!(calendar instanceof CalendarWorkTimeStrategy)) {
      var id = calendar.id;
      calendar = this.createCalendar(calendar);
      calendar.id = id;
    }
    var config = this.$gantt.config;

    calendar.id = calendar.id || this.utilsService.uid();
    this._calendars[calendar.id] = calendar;
    if (!config.worktimes)
      config.worktimes = {};
    config.worktimes[calendar.id] = calendar.worktime;
    return calendar.id;
  }

  deleteCalendar(calendar) {
    var config = this.$gantt.config;
    if (!calendar) return false;
    if (this._calendars[calendar]) {
      delete this._calendars[calendar];
      if (config.worktimes && config.worktimes[calendar])
        delete config.worktimes[calendar];
      return true;
    } else {
      return false;
    }
  }

  restoreConfigCalendars(configs) {
    for (var i in configs) {
      if (this._calendars[i])
        continue;

      var settings = configs[i];
      var calendar: any = this.createCalendar(settings);
      calendar.id = i;
      this.addCalendar(calendar);
    }
  }

  createDefaultCalendars() {
    var config = this.$gantt.config;
    this.restoreConfigCalendars(this.defaults);
    this.restoreConfigCalendars(config.worktimes);
  }

}


class TimeCalculator {
  $gantt: any;
  argumentsHelper: any;
  calendarManager: any;
  $disabledCalendar: any;
  constructor(calendarManager) {

    this.$gantt = calendarManager.$gantt;
    this.argumentsHelper = new CalendarArgumentsHelper(this.$gantt);
    this.calendarManager = calendarManager;
    this.$disabledCalendar = new CalendarDisabledTimeStrategy(this.$gantt, this.argumentsHelper);
  }
    _getCalendar(config) {
      var calendar;
      if (!this.$gantt.$services.config().work_time) {
        calendar = this.$disabledCalendar;
      } else {
        var manager = this.calendarManager;
        if (config.task) {
          calendar = manager.getTaskCalendar(config.task);
        } else if (config.id) {
          calendar = manager.getTaskCalendar(config);
        } else if (config.calendar) {
          calendar = config.calendar;
        }
        if (!calendar) {
          calendar = manager.getTaskCalendar();
        }
      }
      return calendar;
    }
  
    getWorkHours(config) {
      config = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);
  
      var calendar = this._getCalendar(config);
  
      return calendar.getWorkHours(config.date);
    }
  
    setWorkTime(config, calendar) {
      config = this.argumentsHelper.setWorkTimeArguments.apply(this.argumentsHelper, arguments);
  
      if (!calendar)
        calendar = this.calendarManager.getCalendar(); // Global
      return calendar.setWorkTime(config);
    }
  
    unsetWorkTime(config, calendar) {
      config = this.argumentsHelper.unsetWorkTimeArguments.apply(this.argumentsHelper, arguments);
  
      if (!calendar)
        calendar = this.calendarManager.getCalendar(); // Global
      return calendar.unsetWorkTime(config);
    }
    isWorkTime(date, unit, task, calendar) {
      var config = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);
  
      calendar = this._getCalendar(config);
      return calendar.isWorkTime(config);
    }
    getClosestWorkTime(config) {
      config = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);
  
      var calendar = this._getCalendar(config);
  
      return calendar.getClosestWorkTime(config);
    }
  
    calculateDuration() { // start_date_date, end_date, task
      var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);
  
  
      var calendar = this._getCalendar(config);
      return calendar.calculateDuration(config);
    }
    hasDuration() {
      var config = this.argumentsHelper.hasDurationArguments.apply(this.argumentsHelper, arguments);
  
      var calendar = this._getCalendar(config);
  
      return calendar.hasDuration(config);
    }
    calculateEndDate(config) { // start_date, duration, unit, task
      var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);
  
      var calendar = this._getCalendar(config);
      return calendar.calculateEndDate(config);
    }
}
