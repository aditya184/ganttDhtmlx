import { Injectable } from '@angular/core';
import { UtilsService } from 'src/app/services/utils/utils.service';
import { GanttObjectService } from 'src/app/services/gantt-object.service';

@Injectable({
  providedIn: 'root'
})
export class ControlsService {
  window:any;
  constructor(private utilsService: UtilsService) { }

  baseControl(gantt) {

    function dummy() {
      // eslint-disable-next-line
      console.log("Method is not implemented.");
    }
    function BaseControl() {
    }

    // base methods will be runned in gantt context
    BaseControl.prototype.render = dummy; // arguments: sns
    BaseControl.prototype.set_value = dummy; // arguments: node, value, ev, sns(config)
    BaseControl.prototype.get_value = dummy; // arguments node, ev, sns(config)
    BaseControl.prototype.focus = dummy; // arguments: node

    return function (gantt) { // we could send current instance of gantt to module
      return BaseControl;
    };

    /***/
  }

  checkboxControl() {
    var outerThis: ControlsService
    var helpers = this.utilsService;
    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function CheckboxControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(CheckboxControl, _super);

      CheckboxControl.prototype.render = function (sns) {
        var height = (sns.height || "23") + "px";
        var html = "<div class='gantt_cal_ltext' style='height:" + height + ";'>";

        if (sns.options && sns.options.length) {
          for (var i = 0; i < sns.options.length; i++) {
            html += "<label><input type='checkbox' value='" + sns.options[i].key + "' name='" + sns.name + "'>" + sns.options[i].label + "</label>";
          }
        }
        html += "</div>";
        return html;
      };

      CheckboxControl.prototype.set_value = function (node, value, ev, sns) {
        var checkboxes = Array.prototype.slice.call(node.querySelectorAll("input[type=checkbox]"));

        if (!node._dhx_onchange && sns.onchange) {
          node.onchange = sns.onchange;
          node._dhx_onchange = true;
        }

        helpers.forEach(checkboxes, function (entry) {
          entry.checked = value ? value.indexOf(entry.value) >= 0 : false;
        });
      };

      CheckboxControl.prototype.get_value = function (node) {
        return helpers.arrayMap(Array.prototype.slice.call(node.querySelectorAll("input[type=checkbox]:checked")), function (entry) {
          return entry.value;
        });
      };

      CheckboxControl.prototype.focus = function (node) {
        gantt._focus(node.querySelector("input[type=checkbox]"));
      };

      return CheckboxControl;
    };

    /***/
  }

  constraintControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();
    var htmlHelpers = this.utilsService;

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function ConstraintControl() {
        var self = _super.apply(this, arguments) || this;
        return self;
      }

      __extends(ConstraintControl, _super);

      function isNonTimedConstraint(value) {
        if (!value || value === gantt.config.constraint_types.ASAP || value === gantt.config.constraint_types.ALAP) {
          return true;
        } else {
          return false;
        }
      }

      function toggleTimeSelect(timeSelects, typeValue) {
        var isNonTimed = isNonTimedConstraint(typeValue);
        for (var i = 0; i < timeSelects.length; i++) {
          timeSelects[i].disabled = isNonTimed;
        }
      }

      ConstraintControl.prototype.render = function (sns) {
        var height = (sns.height || 30) + "px";
        var html = "<div class='gantt_cal_ltext gantt_section_" + sns.name + "' style='height:" + height + ";'>";

        var options = [];
        for (var i in gantt.config.constraint_types) {
          options.push({ key: gantt.config.constraint_types[i], label: gantt.locale.labels[gantt.config.constraint_types[i]] });
        }

        sns.options = sns.options || options;

        html += "<span data-constraint-type-select>" + htmlHelpers.getHtmlSelect(sns.options, [{ key: "data-type", value: "constraint-type" }]) + "</span>";

        var timeLabel = gantt.locale.labels["constraint_date"] || "Constraint date";
        html += "<label data-constraint-time-select>" + timeLabel + ": " + gantt.form_blocks.getTimePicker.call(this, sns) + "</label>";

        html += "</div>";
        return html;
      };

      ConstraintControl.prototype.set_value = function (node, value, task, config) {
        var typeSelect = node.querySelector("[data-constraint-type-select] select");
        var timeSelects = node.querySelectorAll("[data-constraint-time-select] select");
        var map = config._time_format_order;

        var mapping = gantt._resolve_default_mapping(config);

        if (!typeSelect._eventsInitialized) {
          typeSelect.addEventListener("change", function (e) {
            toggleTimeSelect(timeSelects, e.target.value);
          });
          typeSelect._eventsInitialized = true;
        }

        var constraintDate = task[mapping.constraint_date] || new Date();
        gantt.form_blocks._fill_lightbox_select(timeSelects, 0, constraintDate, map, config);

        var constraintType = task[mapping.constraint_type] || gantt.getConstraintType(task);
        typeSelect.value = constraintType;
        toggleTimeSelect(timeSelects, constraintType);
      };

      ConstraintControl.prototype.get_value = function (node, task, config) {
        var typeSelect = node.querySelector("[data-constraint-type-select] select");
        var timeSelects = node.querySelectorAll("[data-constraint-time-select] select");

        var constraintType = typeSelect.value;
        var constraintDate = null;
        if (!isNonTimedConstraint(constraintType)) {
          constraintDate = gantt.form_blocks.getTimePickerValue(timeSelects, config);
        }

        return {
          constraint_type: constraintType,
          constraint_date: constraintDate
        };
      };

      ConstraintControl.prototype.focus = function (node) {
        gantt._focus(node.querySelector("select"));
      };

      return ConstraintControl;
    };

    /***/
  }

  durationControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function DurationControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(DurationControl, _super);

      DurationControl.prototype.render = function (sns) {
        var time = "<div class='gantt_time_selects'>" + gantt.form_blocks.getTimePicker.call(this, sns) + "</div>";
        var label = gantt.locale.labels[gantt.config.duration_unit + "s"];
        var singleDate = sns.single_date ? " style='display:none'" : "";
        var readonly = sns.readonly ? " disabled='disabled'" : "";
        var ariaAttr = gantt._waiAria.lightboxDurationInputAttrString(sns);
        var duration = "<div class='gantt_duration' " + singleDate + ">" +
          "<input type='button' class='gantt_duration_dec' value='−'" + readonly + ">" +
          "<input type='text' value='5' class='gantt_duration_value'" + readonly + " " + ariaAttr + ">" +
          "<input type='button' class='gantt_duration_inc' value='+'" + readonly + "> " + label + " <span></span>" +
          "</div>";
        var html = "<div style='height:" + (sns.height || 30) + "px;padding-top:0px;font-size:inherit;' class='gantt_section_time'>" + time + " " + duration + "</div>";
        return html;
      };

      DurationControl.prototype.set_value = function (node, value, ev, config) {
        var cfg = config;
        var s = node.getElementsByTagName("select");
        var inps = node.getElementsByTagName("input");
        var duration = inps[1];
        var btns = [inps[0], inps[2]];
        var endspan = node.getElementsByTagName("span")[0];
        var map = config._time_format_order;
        var mapping;
        var start_date;
        var end_date;
        var duration_val;

        function _calc_date() {
          var start_date = _getStartDate.call(gantt, node, config);
          var duration = _getDuration.call(gantt, node, config);
          var end_date = gantt.calculateEndDate({ start_date: start_date, duration: duration, task: ev });

          endspan.innerHTML = gantt.templates.task_date(end_date);
        }

        function _change_duration(step) {
          var value = duration.value;

          value = parseInt(value, 10);
          if (this.window.isNaN(value))
            value = 0;
          value += step;
          if (value < 1) value = 1;
          duration.value = value;
          _calc_date();
        }

        btns[0].onclick = gantt.bind(function () {
          _change_duration(-1 * gantt.config.duration_step);
        }, this);
        btns[1].onclick = gantt.bind(function () {
          _change_duration(1 * gantt.config.duration_step);
        }, this);
        s[0].onchange = _calc_date;
        s[1].onchange = _calc_date;
        s[2].onchange = _calc_date;
        if (s[3]) s[3].onchange = _calc_date;

        duration.onkeydown = gantt.bind(function (e) {
          var code;

          e = e || window.event;
          code = (e.charCode || e.keyCode || e.which);

          if (code == gantt.constants.KEY_CODES.DOWN) {
            _change_duration(-1 * gantt.config.duration_step);
            return false;
          }

          if (code == gantt.constants.KEY_CODES.UP) {
            _change_duration(1 * gantt.config.duration_step);
            return false;
          }
          window.setTimeout(_calc_date, 1);
        }, this);

        duration.onchange = gantt.bind(_calc_date, this);

        mapping = gantt._resolve_default_mapping(config);
        if (typeof (mapping) === "string") mapping = { start_date: mapping };

        start_date = ev[mapping.start_date] || new Date();
        end_date = ev[mapping.end_date] || gantt.calculateEndDate({
          start_date: start_date,
          duration: 1,
          task: ev
        });
        duration_val = Math.round(ev[mapping.duration]) || gantt.calculateDuration({
          start_date: start_date,
          end_date: end_date,
          task: ev
        });

        gantt.form_blocks._fill_lightbox_select(s, 0, start_date, map, cfg);
        duration.value = duration_val;
        _calc_date();
      };

      DurationControl.prototype.get_value = function (node, ev, config) {
        var startDate = _getStartDate(node, config);
        // var duration = _getDuration(node, config);
        var duration = _getDuration(node);

        var endDate = gantt.calculateEndDate({ start_date: startDate, duration: duration, task: ev });

        if (typeof gantt._resolve_default_mapping(config) == "string") {
          return startDate;
        }

        return {
          start_date: startDate,
          end_date: endDate,
          duration: duration
        };
      };

      DurationControl.prototype.focus = function (node) {
        gantt._focus(node.getElementsByTagName("select")[0]);
      };


      function _getStartDate(node, config) {
        var s = node.getElementsByTagName("select");
        var map = config._time_format_order;
        var hours = 0;
        var minutes = 0;

        if (gantt.defined(map[3])) {
          var input = s[map[3]];
          var time = parseInt(input.value, 10);
          if (isNaN(time) && input.hasAttribute("data-value")) {
            time = parseInt(input.getAttribute("data-value"), 10);
          }

          hours = Math.floor(time / 60);
          minutes = time % 60;
        }
        return new Date(s[map[2]].value, s[map[1]].value, s[map[0]].value, hours, minutes);
      }

      function _getDuration(node) {
        var duration = node.getElementsByTagName("input")[1];

        duration = parseInt(duration.value, 10);
        if (!duration || this.window.isNaN(duration)) duration = 1;
        if (duration < 0) duration *= -1;
        return duration;
      }


      return DurationControl;
    };

    /***/
  }

  parentControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.selectControl(gantt);

      function ParentControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(ParentControl, _super);


      ParentControl.prototype.render = function (sns) {
        return _display(sns, false);
      };

      ParentControl.prototype.set_value = function (node, value, ev, config) {
        var tmpDom = document.createElement("div");
        tmpDom.innerHTML = _display(config, ev.id);
        var newOptions = tmpDom.removeChild(tmpDom.firstChild);
        node.onselect = null;
        node.parentNode.replaceChild(newOptions, node);

        return gantt.form_blocks.select.set_value.apply(gantt, [newOptions, value, ev, config]);
      };

      function _display(config, item_id) {
        var tasks = [],
          options = [];
        if (item_id) {
          tasks = gantt.getTaskByTime();
          if (config.allow_root) {
            tasks.unshift({ id: gantt.config.root_id, text: config.root_label || "" });
          }
          tasks = _filter(tasks, config, item_id);
          if (config.sort) {
            tasks.sort(config.sort);
          }
        }
        var text = config.template || gantt.templates.task_text;
        for (var i = 0; i < tasks.length; i++) {
          var label = text.apply(gantt, [tasks[i].start_date, tasks[i].end_date, tasks[i]]);
          if (label === undefined) {
            label = "";
          }
          options.push({
            key: tasks[i].id,
            label: label
          });
        }
        config.options = options;
        config.map_to = config.map_to || "parent";
        return gantt.form_blocks.select.render.apply(this, arguments);
      }

      function _filter(options, config, item_id) {
        var filter = config.filter || function () {
          return true;
        };

        options = options.slice(0);

        for (var i = 0; i < options.length; i++) {
          var task = options[i];
          if (task.id == item_id || gantt.isChildOf(task.id, item_id) || filter(task.id, task) === false) {
            options.splice(i, 1);
            i--;
          }
        }
        return options;
      }
      return ParentControl;
    };

    /***/
  }

  radioControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function RadioControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(RadioControl, _super);

      RadioControl.prototype.render = function (sns) {
        var height = (sns.height || "23") + "px";
        var html = "<div class='gantt_cal_ltext' style='height:" + height + ";'>";

        if (sns.options && sns.options.length) {
          for (var i = 0; i < sns.options.length; i++) {
            html += "<label><input type='radio' value='" + sns.options[i].key + "' name='" + sns.name + "'>" + sns.options[i].label + "</label>";
          }
        }

        html += "</div>";
        return html;
      };

      RadioControl.prototype.set_value = function (node, value, ev, sns) {
        var radio;

        if (!sns.options || !sns.options.length) return;

        radio = node.querySelector("input[type=radio][value='" + value + "']") ||
          node.querySelector("input[type=radio][value='" + sns.default_value + "']");

        if (!radio) return;

        if (!node._dhx_onchange && sns.onchange) {
          node.onchange = sns.onchange;
          node._dhx_onchange = true;
        }

        radio.checked = true;
      };

      RadioControl.prototype.get_value = function (node, ev) {
        var result = node.querySelector("input[type=radio]:checked");

        return result ? result.value : "";
      };

      RadioControl.prototype.focus = function (node) {
        gantt._focus(node.querySelector("input[type=radio]"));
      };

      return RadioControl;
    };

    /***/
  }

  selectControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();
    var htmlHelpers = this.utilsService;

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function SelectControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(SelectControl, _super);

      SelectControl.prototype.render = function (sns) {
        var height = (sns.height || "23") + "px";
        var html = "<div class='gantt_cal_ltext' style='height:" + height + ";'>";

        html += htmlHelpers.getHtmlSelect(sns.options, [{ key: "style", value: "width:100%;" }]);
        html += "</div>";
        return html;
      };

      SelectControl.prototype.set_value = function (node, value, ev, sns) {
        var select = node.firstChild;
        if (!select._dhx_onchange && sns.onchange) {
          select.onchange = sns.onchange;
          select._dhx_onchange = true;
        }
        if (typeof value === "undefined")
          value = (select.options[0] || {}).value;
        select.value = value || "";
      };

      SelectControl.prototype.get_value = function (node) {
        return node.firstChild.value;
      };

      SelectControl.prototype.focus = function (node) {
        var a = node.firstChild;
        gantt._focus(a, true);
      };

      return SelectControl;
    };

    /***/
  }

  templateControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function TemplateControl() {
        var self = _super.apply(this, arguments) || this;
        return self;
      }

      __extends(TemplateControl, _super);


      TemplateControl.prototype.render = function (sns) {
        var height = (sns.height || "30") + "px";
        return "<div class='gantt_cal_ltext gantt_cal_template' style='height:" + height + ";'></div>";
      };

      TemplateControl.prototype.set_value = function (node, value) {
        node.innerHTML = value || "";
      };

      TemplateControl.prototype.get_value = function (node) {
        return node.innerHTML || "";
      };

      TemplateControl.prototype.focus = function () { };

      return TemplateControl;
    };

    /***/
  }

  textareaControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

      function TextareaControl() {
        var self = _super.apply(this, arguments) || this;

        return self;
      }

      __extends(TextareaControl, _super);

      TextareaControl.prototype.render = function (sns) {
        var height = (sns.height || "130") + "px";
        return "<div class='gantt_cal_ltext' style='height:" + height + ";'><textarea></textarea></div>";
      };

      TextareaControl.prototype.set_value = function (node, value) {
        gantt.form_blocks.textarea._get_input(node).value = value || "";
      };

      TextareaControl.prototype.get_value = function (node) {
        return gantt.form_blocks.textarea._get_input(node).value;
      };

      TextareaControl.prototype.focus = function (node) {
        var a = gantt.form_blocks.textarea._get_input(node);
        gantt._focus(a, true);
      };

      TextareaControl.prototype._get_input = function (node) {
        return node.querySelector("textarea");
      };

      return TextareaControl;
    };

    /***/
  }

  timeControl(outerThis?: ControlsService) {

    var __extends = this.utilsService.extends();

    return function (gantt) {
      var _super = outerThis.baseControl(gantt);

     

      return TimeControl;
    };

    /***/
  }

}

class TimeControl {
  ganttObject: GanttObjectService
  utilsService: UtilsService
  constructor() {
  var self = _super.apply(this, arguments) || this;

  return self;
}


// __extends(TimeControl, _super);

render(sns) {
  var time = this.ganttObject.gantt.form_blocks.getTimePicker.call(this, sns);
  var html = "<div style='height:" + (sns.height || 30) + "px;padding-top:0px;font-size:inherit;text-align:center;' class='this.ganttObject.gantt_section_time'>";
  html += time;

  if (sns.single_date) {
    time = this.ganttObject.gantt.form_blocks.getTimePicker.call(this, sns, true);
    html += "<span></span>";
  } else {
    html += "<span style='font-weight:normal; font-size:10pt;'> &nbsp;&ndash;&nbsp; </span>";
  }

  html += time;
  html += "</div>";
  return html;
}

set_value(node, value, ev, config) {
  var cfg = config;
  var s = node.getElementsByTagName("select");
  var map = config._time_format_order;

  if (cfg.auto_end_date) {
    var _update_lightbox_select = function () {
      start_date = new Date(s[map[2]].value, s[map[1]].value, s[map[0]].value, 0, 0);
      end_date = this.ganttObject.gantt.calculateEndDate({ start_date: start_date, duration: 1, task: ev });
      this.ganttObject.gantt.form_blocks._fill_lightbox_select(s, map.size, end_date, map, cfg);
    };
    for (var i = 0; i < 4; i++) {
      s[i].onchange = _update_lightbox_select;
    }
  }

  var mapping = this.ganttObject.gantt._resolve_default_mapping(config);

  if (typeof (mapping) === "string") mapping = { start_date: mapping };

  var start_date = ev[mapping.start_date] || new Date();
  var end_date = ev[mapping.end_date] || this.ganttObject.gantt.calculateEndDate({
    start_date: start_date,
    duration: 1,
    task: ev
  });

  this.ganttObject.gantt.form_blocks._fill_lightbox_select(s, 0, start_date, map, cfg);
  this.ganttObject.gantt.form_blocks._fill_lightbox_select(s, map.size, end_date, map, cfg);
}

get_value(node, ev, config) {
  var selects = node.getElementsByTagName("select");
  var startDate;
  var map = config._time_format_order;
  function _getEndDate(selects, map, startDate) {
    var endDate = this.ganttObject.gantt.form_blocks.getTimePickerValue(selects, config, map.size);

    if (endDate <= startDate) {
      return this.ganttObject.gantt.date.add(startDate, this.ganttObject.gantt._get_timepicker_step(), "minute");
    }
    return endDate;
  }

  startDate = this.ganttObject.gantt.form_blocks.getTimePickerValue(selects, config);

  if (typeof this.ganttObject.gantt._resolve_default_mapping(config) === "string") {
    return startDate;
  }

  return {
    start_date: startDate,
    end_date: _getEndDate(selects, map, startDate)
  };
}

focus(node) {
  this.ganttObject.gantt._focus(node.getElementsByTagName("select")[0]);
}

}
