import { TestBed } from '@angular/core/testing';

import { KeyboardMappingService } from './keyboard-mapping.service';

describe('KeyboardMappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: KeyboardMappingService = TestBed.get(KeyboardMappingService);
    expect(service).toBeTruthy();
  });
});
