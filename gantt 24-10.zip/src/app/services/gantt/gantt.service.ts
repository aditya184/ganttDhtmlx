import { Injectable } from '@angular/core';
import { CoreService } from '../core/core.service';

@Injectable({
	providedIn: 'root'
})
export class GanttService {

	constructor() { }

	// init(container: string | HTMLElement, from?: Date, to?: Date): void {
	// 	this.coreService.init(container, from, to)
	// }

	config(): any {
		var result: any = {
			layout: {
				css: "gantt_container",
				rows: [
					{
						cols: [
							{ view: "grid", scrollX: "scrollHor", scrollY: "scrollVer" },
							{ resizer: true, width: 1 },
							{ view: "timeline", scrollX: "scrollHor", scrollY: "scrollVer" },
							{ view: "scrollbar", id: "scrollVer" }
						]
					},
					{ view: "scrollbar", id: "scrollHor", height: 20 }
				]
			},
			links: {
				finish_to_start: "0",
				start_to_start: "1",
				finish_to_finish: "2",
				start_to_finish: "3"
			},
			types: {
				task: "task",
				project: "project",
				milestone: "milestone"
			},
			auto_types: false,
			duration_unit: "day",
			work_time: false,
			correct_work_time: false,
			skip_off_time: false,
			cascade_delete: true,
			autosize: false,
			autosize_min_width: 0,
			autoscroll: true,
			autoscroll_speed: 30,
			show_links: true,
			show_task_cells: true,
			scroll_size: 0,
			// replace backgroung of the task area with a canvas img
			static_background: false,
			static_background_cells: true,
			branch_loading: false,
			branch_loading_property: "$has_child",
			show_loading: false,
			show_chart: true,
			show_grid: true,
			min_duration: 60 * 60 * 1000,
			date_format: "%d-%m-%Y %H:%i",
			xml_date: undefined,
			start_on_monday: true,
			server_utc: false,
			show_progress: true,
			fit_tasks: false,
			select_task: true,
			scroll_on_click: true,
			smart_rendering: true,
			preserve_scroll: true,
			readonly: false,
			/*grid */
			date_grid: "%Y-%m-%d",
			drag_links: true,
			drag_progress: true,
			drag_resize: true,
			drag_project: false,
			drag_move: true,
			drag_mode: {
				resize: "resize",
				progress: "progress",
				move: "move",
				ignore: "ignore"
			},
			round_dnd_dates: true,
			link_wrapper_width: 20,
			root_id: 0,
			autofit: false,
			columns: [
				{ name: "text", tree: true, width: "*", resize: true },
				{ name: "start_date", align: "center", resize: true },
				{ name: "duration", align: "center" },
				{ name: "add", width: 44 }
			],
			/*scale*/
			scale_offset_minimal: true,
			inherit_scale_class: false,
			scales: [
				{
					unit: "day",
					step: 1,
					date: "%d %M"
				}
			],
			// 		date_scale: "%d %M",
			time_step: 60,
			duration_step: 1,
			task_date: "%d %F %Y",
			time_picker: "%H:%i",
			task_attribute: "task_id",
			link_attribute: "link_id",
			layer_attribute: "data-layer",
			_last_move_event: '',
			buttons_left: [
				"gantt_save_btn",
				"gantt_cancel_btn"
			],
			_migrate_buttons: {
				dhx_save_btn: "gantt_save_btn",
				dhx_cancel_btn: "gantt_cancel_btn",
				dhx_delete_btn: "gantt_delete_btn"
			},
			buttons_right: [
				"gantt_delete_btn"
			],
			lightbox: {
				sections: [
					{ name: "description", height: 70, map_to: "text", type: "textarea", focus: true },
					{ name: "time", type: "duration", map_to: "auto" }
				],
				project_sections: [
					{ name: "description", height: 70, map_to: "text", type: "textarea", focus: true },
					{ name: "type", type: "typeselect", map_to: "type" },
					{ name: "time", type: "duration", readonly: true, map_to: "auto" }
				],
				milestone_sections: [
					{ name: "description", height: 70, map_to: "text", type: "textarea", focus: true },
					{ name: "type", type: "typeselect", map_to: "type" },
					{ name: "time", type: "duration", single_date: true, map_to: "auto" }
				]
			},
			drag_lightbox: true,
			sort: false,
			details_on_create: true,
			details_on_dblclick: true,
			initial_scroll: true,
			task_scroll_offset: 100,
			order_branch: false,
			order_branch_free: false,
			task_height: "full",
			min_column_width: 70,
			// min width for grid column (when resizing)
			min_grid_column_width: 70,
			// name of the attribute with column index for resize element
			grid_resizer_column_attribute: "column_index",
			// name of the attribute with column index for resize element
			grid_resizer_attribute: "grid_resizer",
			// grid width can be increased after the column has been resized
			keep_grid_width: false,
			// grid width can be adjusted
			grid_resize: false,
			show_unscheduled: true,
			//
			readonly_property: "readonly",
			editable_property: "editable",
			calendar_property: "calendar_id",
			resource_calendars: {},
			inherit_calendar: false,
			type_renderers: {},
			open_tree_initially: false,
			optimize_render: true,
			prevent_default_scroll: false,
			show_errors: true,
			wai_aria_attributes: true,
			smart_scales: true,
			rtl: false,
			placeholder_task: false
		};
		return result;
	}
	// config = {

	// 	$root: '',

	// 	auto_scheduling: false,

	// 	/**
	// 	 * allows or forbids creating links from parent tasks (projects) to their children
	// 	*/
	// 	auto_scheduling_descendant_links: false,

	// 	/**
	// 	 * defines whether gantt will do autoscheduling on data loading
	// 	*/
	// 	auto_scheduling_initial: false,

	// 	/**
	// 	 * defines whether the whole project will be moved (see the details below)
	// 	*/
	// 	auto_scheduling_move_projects: false,

	// 	/**
	// 	 * enables the auto scheduling mode, in which tasks will always be rescheduled to the earliest possible date
	// 	*/
	// 	auto_scheduling_strict: false,

	// 	/**
	// 	 * automatically converts tasks with subtasks to projects and projects without subtasks back to tasks
	// 	*/
	// 	auto_types: false,

	// 	/**
	// 	 * enables automatic adjusting of the grid's columns to the grid's width
	// 	*/
	// 	autofit: false,

	// 	/**
	// 	 * enables autoscrolling while dragging a task or link out of the current browser screen
	// 	*/
	// 	autoscroll: false,

	// 	/**
	// 	 * defines the speed of autoscrolling (in ms) while dragging a task or link out of the current browser screen
	// 	*/
	// 	autoscroll_speed: 0,

	// 	/**
	// 	 * forces the Gantt chart to automatically change its size to show all tasks without scrolling
	// 	*/
	// 	autosize: false,

	// 	/**
	// 	 * sets the minimum width (in pixels) that the Gantt chart can take in the horizontal 'autosize' mode
	// 	*/
	// 	autosize_min_width: 0,

	// 	/**
	// 	 * enables dynamic loading in the Gantt chart
	// 	*/
	// 	branch_loading: false,

	// 	/**
	// 	 * specifies that the task has children that are not yet loaded from the backend
	// 	*/
	// 	branch_loading_property: '',

	// 	/**
	// 	 * stores a collection of buttons resided in the left bottom corner of the lightbox
	// 	*/
	// 	buttons_left: [],

	// 	/**
	// 	 * stores a collection of buttons resided in the right bottom corner of the lightbox
	// 	*/
	// 	buttons_right: [],

	// 	/**
	// 	 * changes the name of the property that affects binding of a calendar to a task/group of tasks
	// 	*/
	// 	calendar_property: '',

	// 	/**
	// 	 * enables cascade deleting of nested tasks and links
	// 	*/
	// 	cascade_delete: false,

	// 	/**
	// 	 * configures the columns of the table
	// 	*/
	// 	columns: [],

	// 	/**
	// 	 * contains all available constraint types
	// 	*/
	// 	constraint_types: '',

	// 	/**
	// 	 * enables adjusting the task's start and end dates to the work time (while dragging)
	// 	*/
	// 	correct_work_time: false,

	// 	/**
	// 	 * sets the format of dates in the "Start time" column of the table
	// 	*/
	// 	date_grid: '',

	// 	/**
	// 	 * sets the format of the time scale (X-Axis)
	// 	*/
	// 	date_scale: '',

	// 	/**
	// 	 * 'says' to open the lightbox while creating new events by clicking the '+' button
	// 	*/
	// 	details_on_create: false,

	// 	/**
	// 	 * 'says' to open the lightbox after double clicking on a task
	// 	*/
	// 	details_on_dblclick: false,

	// 	/**
	// 	 * enables the possibility to drag the lightbox by the header
	// 	*/
	// 	drag_lightbox: false,

	// 	/**
	// 	 * enables creating dependency links by drag-and-drop
	// 	*/
	// 	drag_links: false,

	// 	/**
	// 	 * stores the types of available drag-and-drop modes
	// 	*/
	// 	drag_mode: '',

	// 	/**
	// 	 * enables the possibility to move tasks by drag-and-drop
	// 	*/
	// 	drag_move: false,

	// 	/**
	// 	 * enables the possibility to change the task progress by dragging the progress knob
	// 	*/
	// 	drag_progress: false,

	// 	/**
	// 	 * enables drag and drop of items of the project type
	// 	*/
	// 	drag_project: false,

	// 	/**
	// 	 * enables the possibility to resize tasks by drag-and-drop
	// 	*/
	// 	drag_resize: false,

	// 	/**
	// 	 * sets the number of 'gantt.config.duration_unit' units that will correspond to one  unit of the 'duration' data property.
	// 	*/
	// 	duration_step: 0,

	// 	/**
	// 	 * sets the duration unit
	// 	*/
	// 	duration_unit: '',

	// 	/**
	// 	 * changes the name of a property that affects the editing ability  of tasks/links in the read-only Gantt chart
	// 	*/
	// 	editable_property: '',

	// 	/**
	// 	 * an object that contains definitions of inline editors
	// 	*/
	// 	editor_types: '',

	// 	/**
	// 	 * sets the end value of the time scale
	// 	*/
	// 	end_date: Date,

	// 	/**
	// 	 * 'says' the Gantt chart to automatically extend the time scale in order to fit all displayed tasks
	// 	*/
	// 	fit_tasks: false,

	// 	/**
	// 	 * makes the grid resizable by dragging the right grid's border
	// 	*/
	// 	grid_resize: false,

	// 	/**
	// 	 * sets the name of the attribute  of the grid resizer's  DOM element
	// 	*/
	// 	grid_resizer_attribute: '',

	// 	/**
	// 	 * sets the name of the attribute  of the column resizer's  DOM element. The attribute presents the column's index
	// 	*/
	// 	grid_resizer_column_attribute: '',

	// 	/**
	// 	 * sets the width of the grid
	// 	*/
	// 	grid_width: 0,

	// 	/**
	// 	 * shows the critical path in the chart
	// 	*/
	// 	highlight_critical_path: false,

	// 	/**
	// 	 * defines whether tasks should inherit work calendars from their summary parents
	// 	*/
	// 	inherit_calendar: false,

	// 	/**
	// 	 * specifies whether sub-scales shall use the scale_cell_class template by default
	// 	*/
	// 	inherit_scale_class: false,

	// 	/**
	// 	 * sets whether the timeline area will be initially scrolled to display the earliest task
	// 	*/
	// 	initial_scroll: false,

	// 	/**
	// 	 * 'says' to preserve the initial grid's width while resizing columns within
	// 	*/
	// 	keep_grid_width: false,

	// 	/**
	// 	 * enables keyboard navigation in gantt
	// 	*/
	// 	keyboard_navigation: false,

	// 	/**
	// 	 * enables keyboard navigation by cells
	// 	*/
	// 	keyboard_navigation_cells: false,

	// 	/**
	// 	 * sets the name of the attribute of the task layer's DOM element
	// 	*/
	// 	layer_attribute: '',

	// 	/**
	// 	 * specifies the layout object
	// 	*/
	// 	layout: '',

	// 	/**
	// 	 * specifies the lightbox object
	// 	*/
	// 	lightbox: '',

	// 	/**
	// 	 * increases the height of the lightbox
	// 	*/
	// 	lightbox_additional_height: 0,

	// 	/**
	// 	 * sets the size of the link arrow
	// 	*/
	// 	link_arrow_size: 0,

	// 	/**
	// 	 * sets the name of the attribute that will specify the id of the link's HTML element
	// 	*/
	// 	link_attribute: '',

	// 	/**
	// 	 * sets the width of dependency links in the timeline area
	// 	*/
	// 	link_line_width: 0,

	// 	/**
	// 	 * sets the width of the area (over the link) sensitive to clicks
	// 	*/
	// 	link_wrapper_width: 0,

	// 	/**
	// 	 * stores the types of links dependencies
	// 	*/
	// 	links: '',

	// 	/**
	// 	 * sets the minimum width for a column in the timeline area
	// 	*/
	// 	min_column_width: 0,

	// 	/**
	// 	 * Sets the minimum duration (in milliseconds) that can be set for a task during resizing.
	// 	*/
	// 	min_duration: 0,

	// 	/**
	// 	 * sets the minumum width for the grid (in pixels) while being resized
	// 	*/
	// 	min_grid_column_width: 0,

	// 	/**
	// 	 * enables/disables multi-task selection in the Gantt chart
	// 	*/
	// 	multiselect: false,

	// 	/**
	// 	 * specifies whether multi-task selection will be available within one or any level
	// 	*/
	// 	multiselect_one_level: false,

	// 	/**
	// 	 * openes all branches initially
	// 	*/
	// 	open_tree_initially: false,

	// 	/**
	// 	 * activates the 'branch' mode that allows reordering tasks within the same nesting level
	// 	*/
	// 	order_branch: '',

	// 	/**
	// 	 * activates the 'branch' mode that allows reordering tasks within the whole gantt
	// 	*/
	// 	order_branch_free: false,

	// 	/**
	// 	 * adds an empty row into the end of the list of tasks to simplify tasks editing via keyboard
	// 	*/
	// 	placeholder_task: false,

	// 	/**
	// 	 * preserves the current position of the vertical and horizontal scrolls while re-drawing the gantt chart
	// 	*/
	// 	preserve_scroll: false,

	// 	/**
	// 	 * specifies whether the gantt container should block the mousewheel event, or should it be propagated up to the window element
	// 	*/
	// 	prevent_default_scroll: false,

	// 	/**
	// 	 * specifies the end date of the project
	// 	*/
	// 	project_end: Date,

	// 	/**
	// 	 * specifies the start date of the project
	// 	*/
	// 	project_start: Date,

	// 	/**
	// 	 * defines whether the task form will appear from the left/right side of the screen or near the selected task
	// 	*/
	// 	quick_info_detached: false,

	// 	/**
	// 	 * stores a collection of buttons resided in the pop-up task's details form
	// 	*/
	// 	quickinfo_buttons: [],

	// 	/**
	// 	 * activates the read-only mode for the Gantt chart
	// 	*/
	// 	readonly: false,

	// 	/**
	// 	 * changes the name of a property that affects the read-only behaviour of tasks/links
	// 	*/
	// 	readonly_property: '',

	// 	/**
	// 	 * enables the Redo functionality for the gantt
	// 	*/
	// 	redo: false,

	// 	/**
	// 	 * defines a set of working calendars that can be assigned to a specific resource, e.g. a user
	// 	*/
	// 	resource_calendars: '',

	// 	/**
	// 	 * defines the property of a task object that stores a resource id associated with resourceGrid/Timeline/Histogram
	// 	*/
	// 	resource_property: '',

	// 	/**
	// 	 * tells the resource timeline to render elements and call templates for non-allocated cells
	// 	*/
	// 	resource_render_empty_cells: false,

	// 	/**
	// 	 * specifies the name of the dataStore connected to the resourceGrid/resourceTimeline/resourceHistogram views
	// 	*/
	// 	resource_store: '',

	// 	/**
	// 	 * sets the id of the virtual root element
	// 	*/
	// 	root_id: '',

	// 	/**
	// 	 * enables rounding the task's start and end dates to the nearest scale marks
	// 	*/
	// 	round_dnd_dates: false,

	// 	/**
	// 	 * sets the default height for rows of the table
	// 	*/
	// 	row_height: 0,

	// 	/**
	// 	 * switches gantt to the right-to-left mode
	// 	*/
	// 	rtl: false,

	// 	/**
	// 	 * sets the height of the time scale and the header of the grid
	// 	*/
	// 	scale_height: 0,

	// 	/**
	// 	 * sets the minimal scale unit (in case multiple scales are used) as the interval of leading/closing empty space
	// 	*/
	// 	scale_offset_minimal: false,

	// 	/**
	// 	 * sets the unit of the time scale (X-Axis)
	// 	*/
	// 	scale_unit: '',

	// 	/**
	// 	 * enables backwards scheduling
	// 	*/
	// 	schedule_from_end: false,

	// 	/**
	// 	 * specifies whether the timeline area shall be scrolled while selecting to display the selected task
	// 	*/
	// 	scroll_on_click: false,

	// 	/**
	// 	 * set the sizes of the vertical (width) and horizontal (height) scrolls
	// 	*/
	// 	scroll_size: 0,

	// 	/**
	// 	 * enables selection of tasks in the Gantt chart
	// 	*/
	// 	select_task: false,

	// 	/**
	// 	 * enables converting server-side dates from UTC to a local time zone (and backward) while sending data to the server
	// 	*/
	// 	server_utc: false,

	// 	/**
	// 	 * shows the chart (timeline) area of the Gantt chart
	// 	*/
	// 	show_chart: false,

	// 	/**
	// 	 * enables showing error alerts in case of unexpected behavior
	// 	*/
	// 	show_errors: false,

	// 	/**
	// 	 * shows the grid area of the Gantt chart
	// 	*/
	// 	show_grid: false,

	// 	/**
	// 	 * enables/disables displaying links in the Gantt chart
	// 	*/
	// 	show_links: false,

	// 	/**
	// 	 * shows/hides markers on the page
	// 	*/
	// 	show_markers: false,

	// 	/**
	// 	 * enables displaying of the progress inside the task bars
	// 	*/
	// 	show_progress: false,

	// 	/**
	// 	 * activates/disables the 'quick_info' extension (pop-up task's details form)
	// 	*/
	// 	show_quick_info: false,

	// 	/**
	// 	 * enables/disables displaying column borders in the chart area
	// 	*/
	// 	show_task_cells: false,

	// 	/**
	// 	 * enables showing unscheduled tasks
	// 	*/
	// 	show_unscheduled: false,

	// 	/**
	// 	 * hides non-working time from the time scale
	// 	*/
	// 	skip_off_time: false,

	// 	/**
	// 	 * enables the smart rendering mode for gantt's tasks and links rendering
	// 	*/
	// 	smart_rendering: false,

	// 	/**
	// 	 * specifies that only visible part of the time scale is rendered on the screen
	// 	*/
	// 	smart_scales: false,

	// 	/**
	// 	 * enables sorting in the table
	// 	*/
	// 	sort: false,

	// 	/**
	// 	 * sets the start value of the time scale
	// 	*/
	// 	start_date: Date,

	// 	/**
	// 	 * sets the starting day of the week
	// 	*/
	// 	start_on_monday: false,

	// 	/**
	// 	 * generates a background image for the timeline area instead of rendering actual columns' and rows' lines
	// 	*/
	// 	static_background: false,

	// 	/**
	// 	 * sets the step of the time scale (X-Axis)
	// 	*/
	// 	step: 0,

	// 	/**
	// 	 * specifies the second time scale(s)
	// 	*/
	// 	subscales: [],

	// 	/**
	// 	 * sets the name of the attribute that will specify the id of the task's HTML element
	// 	*/
	// 	task_attribute: '',

	// 	/**
	// 	 * sets the format of the date label in the 'Time period' section of the lightbox
	// 	*/
	// 	task_date: '',

	// 	/**
	// 	 * sets the height of task bars in the timeline area
	// 	*/
	// 	task_height: '',

	// 	/**
	// 	 * sets the offset (in pixels) of the nearest task from the left border in the timeline
	// 	*/
	// 	task_scroll_offset: 0,

	// 	/**
	// 	 * sets the format of the time drop-down selector in the lightbox
	// 	*/
	// 	time_picker: '',

	// 	/**
	// 	 * sets the minimum step (in minutes) for the task's time values
	// 	*/
	// 	time_step: 0,

	// 	/**
	// 	 * sets the length of time, in milliseconds, before the tooltip hides
	// 	*/
	// 	tooltip_hide_timeout: 0,

	// 	/**
	// 	 * sets the right (if positive) offset of the tooltip's position
	// 	*/
	// 	tooltip_offset_x: 0,

	// 	/**
	// 	 * sets the top (if positive) offset of the tooltip's position
	// 	*/
	// 	tooltip_offset_y: 0,

	// 	/**
	// 	 * sets the timeout in milliseconds before the tooltip is displayed for a task
	// 	*/
	// 	tooltip_timeout: 0,

	// 	/**
	// 	 * enables/disables the touch support for the Gantt chart
	// 	*/
	// 	touch: '',

	// 	/**
	// 	 * defines the time period in milliseconds that is used to differ the long touch gesture from the scroll gesture
	// 	*/
	// 	touch_drag: 0,

	// 	/**
	// 	 * returns vibration feedback before/after drag and drop on touch devices
	// 	*/
	// 	touch_feedback: false,

	// 	/**
	// 	 * defines the duration of vibration feedback before/after drag and drop on touch devices (in milliseconds)
	// 	*/
	// 	touch_feedback_duration: 0,

	// 	/**
	// 	 * redefines functions responsible for displaying different types of tasks
	// 	*/
	// 	type_renderers: '',

	// 	/**
	// 	 * stores the names of lightbox's structures (used for different types of tasks)
	// 	*/
	// 	types: '',

	// 	/**
	// 	 * enables the Undo functionality for the gantt
	// 	*/
	// 	undo: false,

	// 	/**
	// 	 * sets the actions that the Undo operation will revert
	// 	*/
	// 	undo_actions: '',

	// 	/**
	// 	 * sets the number of steps that should be reverted by the undo method
	// 	*/
	// 	undo_steps: 0,

	// 	/**
	// 	 * sets the types of entities for which the Undo operation will be applied
	// 	*/
	// 	undo_types: '',

	// 	/**
	// 	 * enables WAI-ARIA support to make the component recognizable for screen readers
	// 	*/
	// 	wai_aria_attributes: false,

	// 	/**
	// 	 * enables calculating the duration of tasks in working time instead of calendar time
	// 	*/
	// 	work_time: false,

	// 	/**
	// 	 * defines date formats that are used to parse data from a data set and to send data to a server
	// 	*/
	// 	xml_date: '',

	// 	edit_save: 0,

	// 	edit_cancel: 0,

	// 	month_full: [],

	// 	month_short: [],

	// 	day_full: [],

	// 	day_short: [],

	// 	month_short_hash: 0,

	// 	month_full_hash: 0,

	// 	new_task: '',

	// 	icon_save: '',

	// 	icon_cancel: '',

	// 	icon_details: '',

	// 	icon_edit: '',

	// 	icon_delete: '',

	// 	confirm_closing: '',

	// 	confirm_deleting: '',

	// 	section_description: '',

	// 	section_time: '',

	// 	confirm_link_deleting: '',

	// 	link_from: '',

	// 	link_to: '',

	// 	link_start: '',

	// 	link_end: '',

	// 	minutes: '',

	// 	hours: '',

	// 	days: '',

	// 	weeks: '',

	// 	months: '',

	// 	years: '',


	// }	

}

